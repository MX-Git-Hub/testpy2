#ifndef ERROR_CBS_H
#define ERROR_CBS_H

#include <confd_lib.h>

int register_error_callback(struct confd_daemon_ctx *dctx);

#endif