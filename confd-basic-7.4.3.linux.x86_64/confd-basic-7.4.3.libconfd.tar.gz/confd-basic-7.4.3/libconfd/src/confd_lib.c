 /*
 * Copyright 2005-2007 Tail-F Systems AB
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>
#include <arpa/inet.h>
#include <signal.h>
#include <syslog.h>
#include <math.h>
#ifdef __sun__
/* finite() on Solaris needs this */
#include <ieeefp.h>
#endif
#if defined(__QNX__) || defined(__APPLE__)
/* Use isfinite() to avoid 'deprecated' warning for finite() */
/* (should use it always but "too hard" on Linux and Solaris) */
#define finite isfinite
#endif
#if defined(__GLIBC_PREREQ)
#if !__GLIBC_PREREQ(2, 3)
/* probably uClibc */
/* There is no finite(), should use isfinite(), but see above */
#define finite __finite
#endif
#endif

#include "erl_interface.h"
#include "ei.h"

#include "confd_lib.h"
#include "confd_dp.h"
#include "confd_events.h"
#include "confd_ha.h"
#include "confd_internal.h"
#include "confd_util.h"
#include "confd_type.h"
#include "confd_maapi.h"
#include "confd_proto.h"
#include "confd_errcode.h"
#include "confd_ipc_access.h"

#include "hash/hashtable.h"

/* For actions, we need something unique (per daemon) that can't clash
   with a transaction handle - those run from -epsilon to +infinity... */
#define USID2TID(usid) (-(usid) - 10)
#define TID2USID(tid)  (-(tid) - 10)

/* Increment when growing data/validation/action callback arrays */
#define CB_INCREMENT 16

/* Increment when growing transaction pointer array */
#define TRANS_INCREMENT 256

/* Action state - needed to deal with abort cases */
#define ACT_STATE_NONE    0
#define ACT_STATE_INIT    1
#define ACT_STATE_ACTION  2
#define ACT_STATE_DELAYED 3
#define ACT_STATE_ABORTED 4

/* Action state diagram:

        --------
   ---> | NONE |
   |    --------
   |       | init()
   |       |               init()
   |       |<-------------------------
   |       V                         |
   |    -------- abort() ----------- |
   |    | INIT |-------->| ABORTED |--
   |    --------         -----------
   |       | action()
   |       |
   |       V
   |   ---------- DELAYED_RESPONSE -----------
   |   | ACTION |----------------->| DELAYED |
   |   ----------                  -----------
   |       | !DELAYED_RESPONSE          | delayed reply
   |       V                            |
   ---------<----------------------------

 */


#define CHECK_REG_OK(dctx) do {                                         \
        if ((dctx)->ctl_sock < 0) {                                     \
            return ret_err(CONFD_ERR_PROTOUSAGE,                        \
                           "Control socket must be connected first");   \
        }                                                               \
        if ((dctx)->flags & CONFD_DAEMON_FLAG_REG_DONE) {               \
            return ret_err(CONFD_ERR_PROTOUSAGE,                        \
                           "Not allowed after confd_register_done()");  \
        }                                                               \
    } while (0)


#define SET_SEEN_REPLY(_tctx) if (_tctx->seen_reply == 1) {     \
        return ret_err(CONFD_ERR_PROTOUSAGE,                    \
                       "Cannot reply twice on the same call");  \
    } else { _tctx->seen_reply = 1;}

#define SETERR(error) do {                                              \
        va_list args;                                                   \
        va_start(args, fmt);                                            \
        _confd_vset_error((error), CONFD_ERRCODE_APPLICATION, 0, 0,     \
                          NULL, 0, 0, fmt, args);                       \
        va_end(args);                                                   \
    } while (0)

#define SETERR_EXTENDED(error) do {                                     \
        va_list args;                                                   \
        va_start(args, fmt);                                            \
        _confd_vset_error((error), code, apptag_ns, apptag_tag,         \
                          NULL, 0, 0, fmt, args);                       \
        va_end(args);                                                   \
    } while (0)

#define SETERR_EXTENDED_INFO(error, flags) do {                         \
        va_list args;                                                   \
        int ret;                                                        \
        va_start(args, fmt);                                            \
        ret = _confd_vset_error((error), code, apptag_ns, apptag_tag,   \
                                error_info, n, flags, fmt, args);       \
        va_end(args);                                                   \
        return ret;                                                     \
    } while (0)

#define INC_CONFD_SNPRINTF(buf, n, tot, ...)    \
        do { \
            int _k = confd_snprintf((buf), (n), __VA_ARGS__); \
            (n) -= _k; (buf) += _k; (tot) += _k; \
        } while(0)

/* useful for "strings <file> | grep 'CONFD_LIB.*VSN'" */
char *confd_lib_vsn = "CONFD_LIB_VSN=" CONFD_LIB_VSN_STR;
char *confd_lib_api_vsn = "CONFD_LIB_API_VSN=" CONFD_LIB_API_VSN_STR;
char *confd_lib_proto_vsn = "CONFD_LIB_PROTO_VSN=" CONFD_LIB_PROTO_VSN_STR;

static int confd_is_initialized = 0;

int confd_lib_use_syslog = 0;

static PTHREAD_KEY_T errno_key;
static PTHREAD_KEY_T lasterr_key;
static PTHREAD_KEY_T last_apptag_key;
PTHREAD_KEY_T confd_syslog_buf_key;/* used to accumulate data upto a newline */

struct confd_crypto_keys confd_crypto_keys;

struct lasterr {
    int len;
    char str[1];
};

void (*confd_user_log_hook)(int syslogprio, const char *fmt, va_list ap) =NULL;

int *confd_errno_location(void)
{
    int *r;

    if ((r = (int*) PTHREAD_GETSPECIFIC(errno_key)) == NULL) {
        r = (int*) malloc(sizeof(int));
        *r = 0;
        PTHREAD_SETSPECIFIC(errno_key, (void*) r);
    }
    return r;
}


static struct lasterr *get_lasterr(int len)
{
    struct lasterr *r, *r2;

    if ((r = PTHREAD_GETSPECIFIC(lasterr_key)) == NULL || r->len < len) {
        if (r == NULL && len < 512) {
            /* min alloc */
            len = 512;
        }
        if ((r2 = realloc(r, sizeof(struct lasterr) + len)) != NULL) {
            r = r2;
            r->len = len;
            r->str[0] = 0;
            PTHREAD_SETSPECIFIC(lasterr_key, r);
        }
    }
    return r;
}

char *confd_lasterr(void)
{
    struct lasterr *r = get_lasterr(0);
    return &r->str[0];
}

void confd_set_lasterr(const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    confd_vset_lasterr(fmt, args);
    va_end(args);
}

void confd_vset_lasterr(const char *fmt, va_list args)
{
    struct lasterr *r = get_lasterr(0);
    int len;
    va_list args2;

    va_copy(args2, args);
    if ((len = vsnprintf(&r->str[0], r->len, fmt, args)) >= r->len) {
        r = get_lasterr(len + 1);
        vsnprintf(&r->str[0], r->len, fmt, args2);
    }
}

struct xml_tag *confd_last_error_apptag(void)
{
    struct xml_tag *r;

    if ((r = PTHREAD_GETSPECIFIC(last_apptag_key)) == NULL) {
        r = calloc(1, sizeof(struct xml_tag));
        PTHREAD_SETSPECIFIC(last_apptag_key, (void*) r);
    }
    return r;
}



void confd_set_errno(int ecode)
{
    int *errnop = confd_errno_location();
    *errnop = ecode;
}

void clr_confd_err(void)
{
    int *eptr = confd_errno_location();
    char *lasterr = confd_lasterr();
    *eptr = 0;
    lasterr[0] = 0;
}



static unsigned int usess_hashfromkey(void *ky)
{
    return (uintptr_t)ky;
}

static int usess_equalkeys(void *k1, void *k2)
{
    return (k1 == k2);
}


static void free_cs_choices(struct confd_cs_choice *choice)
{
    struct confd_cs_choice *next_choice;
    struct confd_cs_case *case0, *next_case;

    while (choice != NULL) {
        next_choice = choice->next;
        case0 = choice->cases;
        while (case0 != NULL) {
            free_cs_choices(case0->choices);
            next_case = case0->next;
            free(case0);
            case0 = next_case;
        }
        free(choice);
        choice = next_choice;
    }
}

static void free_meta_data(struct confd_cs_meta_data *md)
{
    if (md != NULL) {
        int i = 0;
        while (md[i].key != NULL || md[i].value != NULL) {
            if (md[i].key)
                free(md[i].key);
            if (md[i].value)
                free(md[i].value);
            i++;
        }
        free(md);
    }
}

static void free_cs_node(struct confd_cs_node *node)
{
    if (node != NULL) {
        free_cs_node(node->children);
        free_cs_node(node->next);
        if (node->info.keys != NULL)
            free(node->info.keys);
        if (node->info.defval != NULL)
            confd_free_dup_value(node->info.defval);
        free_cs_choices(node->info.choices);
        free_meta_data(node->info.meta_data);
        free(node);
    }
}

static void free_dh_spec(struct confd_type_display_hint *dh) {
    if (dh->next)
        free_dh_spec(dh->next);
    free(dh);
}

static void free_cs_types(struct named_type *types, int num_types)
{
    int i, j;

    for (i = 0; i < num_types; i++) {
        /* see maapi.c/load_type() */
        if (types[i].type->validate == confd_enum_validate) {
            struct confd_type_enums *enums = types[i].type->opaque;
            for (j = 0; j < enums->enm_len; j++)
                free((char *)enums->enm[j].name);
            free(enums->enm);
            free(types[i].type->opaque);
        } else if (types[i].type->validate == confd_idref_validate) {
            struct confd_type_idrefs *idrefs = types[i].type->opaque;
            for (j = 0; j < idrefs->idr_len; j++)
                free((char *)idrefs->idr[j].qname);
            free(idrefs->idr);
            free(types[i].type->opaque);
        } else if (types[i].type->validate == confd_bits_validate) {
            struct confd_type_bits *bits = types[i].type->opaque;
            for (j = 0; j < bits->bit_len; j++)
                free((char *)bits->bit[j].name);
            free(bits->bit);
            free(types[i].type->opaque);
        } else if (types[i].type->validate == confd_decimal64_validate) {
            struct confd_type_decimal64 *d = types[i].type->opaque;
            if (d->nr.range_len > 0)
                free(d->nr.range);
            free(types[i].type->opaque);
        } else if (types[i].type->validate == confd_union_validate) {
            struct confd_type_union *uni = types[i].type->opaque;
            free(uni->member_type);
            free(types[i].type->opaque);
        } else if (types[i].type->validate == confd_list_validate) {
            free(types[i].type->opaque);
        } else if (types[i].type->validate ==
                   confd_type_validate_number_restriction) {
            struct confd_type_number_restriction *number =
                types[i].type->opaque;
            free(number->range);
            free(types[i].type->opaque);
        } else if (types[i].type->validate ==
                   confd_type_validate_string_restriction) {
            struct confd_type_string_restriction *string =
                types[i].type->opaque;
            if (string->length_len > 0)
                free(string->length);
            if (string->has_pattern == 2)
                free(string->pattern.text);
            free(types[i].type->opaque);
        } else if (types[i].type->validate ==
                   confd_type_validate_list_restriction) {
            struct confd_type_list_restriction *list = types[i].type->opaque;
            free(list->length);
            free(types[i].type->opaque);
        } else if (types[i].type->validate ==
                    confd_type_validate_display_hint) {
            struct confd_type_display_hint *dh = types[i].type->opaque;
            free_dh_spec(dh);
        }
        free(types[i].name);
        free(types[i].type);
    }
    if (num_types > 0)
        free(types);
}

static struct schema *schemas = NULL;
static int nschemas = 0;
static struct mns_map *mns_maps = NULL;
static int nmns_maps = 0;
static int schemas_mmapped = 0;

/* the subset provided by confd_get_nslist()
   - maintained here so the user doesn't need to free(). */
static struct confd_nsinfo *nslist = NULL;
static int nschemas_listed = 0;

static struct schema *find_schema(u_int32_t ns)
{
    int i;
    for (i=0; i<nschemas; i++) {
        if (schemas[i].nshash == ns)
            return &schemas[i];
    }
    return NULL;
}

static struct schema *find_schema_prefix(char *prefix)
{
    int i;
    for (i=0; i<nschemas; i++) {
        if (strcmp(schemas[i].prefix, prefix) == 0)
            return &schemas[i];
    }
    return NULL;
}

/* Return schema (and optionally cs_node) of unique matching top-level tag */
static struct schema *find_schema_top_tag(char *tag,
                                          const struct confd_cs_node **cs)
{
    int i;
    u_int32_t htag = confd_str2hash(tag);
    struct schema *sfound = NULL;
    struct confd_cs_node *pfound = NULL;

    if (htag != 0) {
        for (i=0; i<nschemas; i++) {
            struct confd_cs_node *p;
            for (p = schemas[i].root; p; p = p->next) {
                if (htag == p->tag) {
                    if (sfound) {
                        ret_err(CONFD_ERR_BADPATH,
                                "top level tag is not unique: %s", tag);
                        return NULL;
                    }
                    sfound = &schemas[i];
                    pfound = p;
                }
            }
        }
        if (sfound) {
            if (cs) { *cs = pfound; }
            return sfound;
        }
    }
    ret_err(CONFD_ERR_BADPATH, "no such top level tag: %s", tag);
    return NULL;
}

void confd_register_schemas(struct schema *new, int num_new, int num_loaded,
                            struct mns_map *new_mns_maps, int num_new_gms,
                            int mmapped)
{
    int i, li;
    struct schema *old_schemas, *old;
    struct mns_map *old_mns_maps, *old_mm;
    int old_nschemas, new_nschemas_listed, old_nmns_maps, old_mmapped;
    struct confd_nsinfo *old_nslist, *new_nslist;

    if (num_loaded > 0) {
        new_nslist = malloc(num_loaded * sizeof(struct confd_nsinfo));
    } else {
        new_nslist = NULL;
    }
    if (new_nslist != NULL) {
        li = 0;
        for (i = 0; i < num_new && li < num_loaded; i++) {
            if (new[i].loaded) {
                new_nslist[li].uri = new[i].uri;
                new_nslist[li].prefix = new[i].prefix;
                new_nslist[li].hash = new[i].nshash;
                new_nslist[li].revision = new[i].revision;
                new_nslist[li].module = new[i].module;
                li++;
            }
        }
        new_nschemas_listed = li;
    } else {
        new_nschemas_listed = 0;
    }

    old_schemas = schemas;
    schemas = new;
    old_nschemas = nschemas;
    nschemas = num_new;
    old_nslist = nslist;
    nslist = new_nslist;
    nschemas_listed = new_nschemas_listed;
    old_mns_maps = mns_maps;
    mns_maps = new_mns_maps;
    old_nmns_maps = nmns_maps;
    nmns_maps = num_new_gms;
    old_mmapped = schemas_mmapped;
    schemas_mmapped = mmapped;

    if (old_mmapped == 0) {
        if (old_nschemas > 0) {
            for (i = 0; i < old_nschemas; i++) {
                old = &old_schemas[i];
                free_cs_node(old->root);
                free((char *)old->uri);
                free((char *)old->prefix);
                if (old->revision != NULL)
                    free((char *)old->revision);
                if (old->module != NULL)
                    free((char *)old->module);
                free_cs_types(old->types, old->num_types);
            }
            free(old_schemas);
        }
        if (old_nmns_maps > 0) {
            for (i = 0; i < old_nmns_maps; i++) {
                old_mm = &old_mns_maps[i];
                hashtable_destroy(old_mm->nshash2prefix, 1);
                hashtable_destroy(old_mm->prefix2nshash, 0);
            }
            free(old_mns_maps);
        }
    }
    if (old_nslist != NULL)
        free(old_nslist);
}

static struct schema *find_val_schema(const confd_value_t *v)
{
    switch (v->type) {
    case C_XMLTAG:
    case C_XMLBEGIN:
    case C_XMLEND:
    case C_XMLMOVEFIRST:
    case C_XMLMOVEAFTER:
        return find_schema(CONFD_GET_XML_NS(v));
        break;
    default:
        return NULL;
    }
}

static struct mns_map *find_mns_map(mount_id_t *mount_id)
{
    int i;

    for (i = 0; i < nmns_maps; i++) {
        if (mns_maps[i].mount_id.ns == mount_id->ns &&
            mns_maps[i].mount_id.tag == mount_id->tag) {
            return &mns_maps[i];
        }
    }
    return NULL;
}

char *_confd_mns_nshash2prefix(mount_id_t *mount_ids, int n,
                               u_int32_t nshash)
{
    int i;
    struct mns_map *map;
    char *prefix;

    for (i = 0; i < n; i++) {
        map = find_mns_map(&mount_ids[i]);
        if (map) {
            prefix = hashtable_search(map->nshash2prefix, INT2VOID(nshash));
            if (prefix) {
                return prefix;
            }
        }
    }
    return NULL;
}

u_int32_t _confd_mns_prefix2nshash(mount_id_t *mount_ids, int n,
                                   const char *prefix)
{
    int i;
    struct mns_map *map;
    void *val;

    for (i = 0; i < n; i++) {
        map = find_mns_map(&mount_ids[i]);
        if (map) {
            val = hashtable_search(map->prefix2nshash, (void *)prefix);
            if (val) {
                return (uintptr_t)val;
            }
        }
    }
    return 0;
}

int confd_get_nslist(struct confd_nsinfo **listp)
{
    if (nschemas_listed != 0) {
        if (nslist == NULL) {
            confd_set_errno(CONFD_ERR_MALLOC);
            return CONFD_ERR;
        }
        *listp = nslist;
    }
    return nschemas_listed;
}

char *confd_ns2prefix(u_int32_t ns)
{
    struct schema *schema = find_schema(ns);

    if (schema != NULL)
        return (char *)schema->prefix;
    return NULL;
}

char *confd_hash2str(u_int32_t hash)
{
    if (hash2str_tab == NULL)
        return NULL;
    return hashtable_search(hash2str_tab, INT2VOID(hash));
}

u_int32_t confd_str2hash(const char *str)
{
    void *val;
    if (str2hash_tab == NULL)
        return 0;
    val = hashtable_search(str2hash_tab, (void *)str);
    return val == NULL ? 0 : (uintptr_t)val;
}


struct confd_cs_node *confd_find_cs_root(int ns)
{
    struct schema *schema = find_schema(ns);
    if (schema != NULL)
        return schema->root;
    return NULL;
}

struct confd_cs_node *confd_find_cs_node_child(
    const struct confd_cs_node *parent,
    struct xml_tag xmltag)
{
    struct confd_cs_node *p = parent->children;

    while (p && p->tag != 0 &&
           !(p->tag == xmltag.tag &&
             (p->ns == 0 || p->ns == xmltag.ns))) {
        p = p->next;
    }
    return p;
}

struct confd_cs_node *confd_find_cs_node(
    const confd_hkeypath_t *hkeypath,
    int len)
{
    struct schema *schema;
    int i = hkeypath->len - 1;
    int istop = hkeypath->len - len;
    struct confd_cs_node *p;

    if (len > hkeypath->len)
        return NULL;

    if ((schema = find_val_schema(hkeypath->v[i])) == NULL) {
        return NULL;
    }

    p = schema->root;

    while (1) {
        /* skip non-matching nodes */
        while (p && p->tag != 0 &&
               !(p->tag == hkeypath->v[i]->val.xmltag.tag &&
                 (p->ns == 0 || p->ns == hkeypath->v[i]->val.xmltag.ns))) {
            p = p->next;
        }
        if (p == NULL)
            return NULL;
        /* if there are no more tags in the hkeypath, we're done */
        if (i == istop)
            return p;
        i--;
        /* ignore non-tags, i.e. keys */
        if (hkeypath->v[i]->type != C_XMLTAG) {
            while (i >= istop && hkeypath->v[i]->type != C_XMLTAG)
                i--;
            /* if there are no more tags, we're done */
            if (i < istop)
                return p;
        }
        p = p->children;
    }
}

/* Always returns CONFD_OK if below_mount_points > 0 - no attempt
   to find the corresponding nshash/schema for a found prefix is done.
   Otherwise:
   Returns CONFD_ERR if a prefix was found, but no corresponding
   nshash/schema was found, else returns CONFD_OK.                  */
static int find_tag(char **start, char **prefix, char **slash,
                    int below_mount_points,
                    u_int32_t *nshash, struct schema **schema)
{
    char *p;
    int in_key = 0, in_quotes = 0;
    mount_id_t root_mount_id;
    u_int32_t nsh = 0;
    struct schema *sch = NULL;

    *prefix = *slash = NULL;
    for (p = *start; *p != '\0' && *slash == NULL; p++) {
        if (in_quotes) {
            switch (*p) {
            case '\\':
                if (*(p+1) != '\0')
                    p++;
                break;
            case '"':
                in_quotes = 0;
                break;
            }
        } else if (in_key) {
            switch (*p) {
            case '"':
                in_quotes++;
                break;
            case '}':
                in_key = 0;
                break;
            }
        } else {
            switch (*p) {
            case '[':
                *p = '\0';
                break;
            case '{':
                *p = '\0';
                in_key++;
                break;
            case ':':
                *p = '\0';
                *prefix = *start;
                if (!below_mount_points) {
                    if (nmns_maps > 0) {
                        root_mount_id = ROOT_MOUNT_ID;
                        nsh = _confd_mns_prefix2nshash(&root_mount_id, 1,
                                                       *prefix);
                    } else if ((sch = find_schema_prefix(*prefix)) != NULL) {
                        nsh = sch->nshash;
                    }
                    if (nsh == 0) {
                        return ret_err(CONFD_ERR_BADPATH,
                                       "no such prefix: %s", *prefix);
                    } else if (schema != NULL && sch == NULL &&
                               (sch = find_schema(nsh)) == NULL) {
                        return ret_err(CONFD_ERR_BADPATH,
                                       "no schema for prefix: %s", *prefix);
                    }
                }
                *start = p + 1;
                break;
            case '/':
                *p = '\0';
                *slash = p + 1;
            }
        }
    }
    if (nshash != NULL) {
        *nshash = nsh;
    }
    if (schema != NULL) {
        *schema = sch;
    }
    return CONFD_OK;
}

static struct confd_cs_node *cd_find_node(char *prefix, char *tag,
                                          int below_mount_points, u_int32_t ns,
                                          struct confd_cs_node *cs)
{
    u_int32_t hash = confd_str2hash(tag);
    struct confd_cs_node *found = NULL;

    while (cs) {
        if (cs->tag == hash) {
            if (ns != 0) {
                if (cs->ns == ns) {
                    found = cs;
                    break;
                }
            } else if (found) {
                if (below_mount_points) {
                    if (prefix) {
                        ret_err(CONFD_ERR_NO_MOUNT_ID,
                                "can't resolve %s:%s without mount-id",
                                prefix, tag);
                    } else {
                        ret_err(CONFD_ERR_NO_MOUNT_ID,
                                "can't resolve %s without mount-id",
                                tag);
                    }
                } else {
                    ret_err(CONFD_ERR_BADPATH,
                            "tag is not unique: %s", tag);
                }
                return NULL;
            } else {
                found = cs;
            }
        }
        cs = cs->next;
    }
    if (!found) {
        if (prefix) {
            ret_err(CONFD_ERR_BADPATH, "no such tag: %s:%s", prefix, tag);
        } else {
            ret_err(CONFD_ERR_BADPATH, "no such tag: %s", tag);
        }
    }
    return found;
}

/* used by confd_type:instance_id_str_to_val(() -
   - no substitute_percent(), may write into dst */
struct confd_cs_node *_confd_cs_node_do_cd(
    const struct confd_cs_node *start, char *dst)
{
    char *p = dst, *sp, *pp;
    u_int32_t pns;
    struct schema *schema;
    const struct confd_cs_node *cs = NULL;
    int below_mount_points = 0;

    if (*p == '/') {
        /* absolute path, ignore 'start' */
        while (*p == '/')
            p++;
        if (find_tag(&p, &pp, &sp,
                     below_mount_points, NULL, &schema) != CONFD_OK) {
            return NULL;
        }
        if (schema != NULL) {
            if ((cs = cd_find_node(pp, p, below_mount_points,
                                   schema->nshash, schema->root)) == NULL) {
                return NULL;
            }
        } else {
            if ((schema = find_schema_top_tag(p, &cs)) == NULL) {
                return NULL;
            }
        }
        p = sp;
    } else if (start == NULL) {
        ret_err(CONFD_ERR_BADPATH, "path must be absolute when start is NULL");
        return NULL;
    } else {
        for (cs = start; cs != NULL; cs = cs->parent) {
            if (cs->info.flags & CS_NODE_HAS_MOUNT_POINT) {
                below_mount_points++;
            }
        }
        cs = start;
    }

    while (p) {
        if (find_tag(&p, &pp, &sp,
                     below_mount_points, &pns, NULL) != CONFD_OK) {
            return NULL;
        }
        if (!pp &&
            (*p == '\0' || strcmp(p, ".") == 0)) { /* stay at this node */
            ;
        } else if (!pp && strcmp(p, "..") == 0) { /* up one level */
            if (cs->parent == NULL) {
                ret_err(CONFD_ERR_BADPATH, "'..' above toplevel element");
                return NULL;
            }
            if (cs->info.flags & CS_NODE_HAS_MOUNT_POINT) {
                below_mount_points--;
            }
            cs = cs->parent;
        } else {                /* find child node */
            if (pp && !below_mount_points && pns == 0) {
                return NULL;
            }
            if ((cs = cd_find_node(pp, p, below_mount_points,
                                   pns, cs->children)) == NULL) {
                return NULL;
            }
            if (cs->info.flags & CS_NODE_HAS_MOUNT_POINT) {
                below_mount_points++;
            }
        }
        p = sp;
    }
    return (struct confd_cs_node *)cs;
}

/* "official" interface */
struct confd_cs_node *confd_cs_node_cd(
    const struct confd_cs_node *start, const char *fmt, ...)
{
    va_list args;
    char dst[BUFSIZ];
    int ret;

    va_start(args, fmt);
    ret = substitute_percent(fmt, dst, sizeof(dst), args, 1);
    va_end(args);
    if (ret >= BUFSIZ) {
        return NULL;
    }
    return _confd_cs_node_do_cd(start, dst);
}


/* macro to traverse an "object" */
#define SKIP_NODE(cur) (cur->info.flags & (CS_NODE_IS_ACTION|CS_NODE_IS_NOTIF))
#define NEXT_OBJECT_NODE(start, cur, descend_cond)                      \
    do {                                                                \
        if (cur) {                                                      \
            if (cur->children && !SKIP_NODE(cur) && (descend_cond)) {   \
                cur = cur->children;                                    \
            } else if (cur->next) {                                     \
                cur = cur->next;                                        \
            } else {                                                    \
                /* wind up to first parent that has a next ptr */       \
                for (cur = cur->parent;                                 \
                     cur && cur != (start) && cur->next == NULL;        \
                     cur = cur->parent) ;                               \
                if (cur) {                                              \
                    if (cur == (start)) {                               \
                        cur = NULL;                                     \
                    } else {                                            \
                        cur = cur->next;                                \
                    }                                                   \
                }                                                       \
            }                                                           \
        }                                                               \
    } while (cur && SKIP_NODE(cur))

enum confd_vtype confd_get_base_type(struct confd_cs_node *node)
{
    if (node->info.flags & CS_NODE_IS_STRING_AS_BINARY) {
        return C_BUF;
    }
    switch (node->info.shallow_type) {
    case C_DOUBLE:
    case C_IPV4:
    case C_IPV6:
    case C_QNAME:
    case C_DATETIME:
    case C_DATE:
    case C_TIME:
    case C_DURATION:
    case C_OID:
    case C_DQUAD:
    case C_HEXSTR:
    case C_IPV4PREFIX:
    case C_IPV6PREFIX:
    case C_IPV4_AND_PLEN:
    case C_IPV6_AND_PLEN:
        return C_BUF;
    default:
        return node->info.shallow_type;
    }
}

int confd_max_object_size(struct confd_cs_node *object)
{
    struct confd_cs_node *cur = object->children;
    int n;

    for (n = 0; cur != NULL; n++) {
        NEXT_OBJECT_NODE(object, cur, !(cur->info.flags & CS_NODE_IS_LIST));
    }
    return n;
}

struct confd_cs_node *confd_next_object_node(struct confd_cs_node *object,
                                             struct confd_cs_node *cur,
                                             confd_value_t *value)
{
    /* Mustn't descend for a list node nor a non-existing presence container */
    NEXT_OBJECT_NODE(object, cur, value->type != C_NOEXISTS);
    return cur;
}


static struct named_type *find_named_type(u_int32_t nshash, const char *name)
{
    struct schema *schema;
    int i;

    if ((schema = find_schema(nshash)) != NULL) {
        for (i = 0; i < schema->num_types; i++) {
            if (strcmp(name, schema->types[i].name) == 0)
                return &schema->types[i];
        }
    }
    return NULL;
}

struct confd_type *confd_find_ns_type(u_int32_t nshash, const char *name)
{
    struct named_type *ntype;

    if (nshash == 0)
        return confd_find_type(name);

    if ((ntype = find_named_type(nshash, name)) != NULL)
        return ntype->type;

    return NULL;
}

static int register_type(struct confd_type *otype, struct confd_type *type)
{

    if (type->str_to_val == NULL || type->val_to_str == NULL ||
        type->validate == NULL) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "All functions must be registered");
    }

    /* find base type in case of auto-generated derivation or leaf-list */
    while (otype->opaque != (void *)CONFD_TYPE_USER) {
        if (otype->parent != NULL) {
            otype = otype->parent;
        } else if (otype->validate == confd_list_validate) {
            struct confd_type_list *list = otype->opaque;
            otype = list->type;
        } else {
            return ret_err(CONFD_ERR_PROTOUSAGE,
                           "Not a user-defined type");
        }
    }

    otype->parent = type;
    return CONFD_OK;
}

int confd_register_ns_type(u_int32_t nshash, const char *name,
                           struct confd_type *type)
{
    struct named_type *ntype;

    if ((ntype = find_named_type(nshash, name)) == NULL)
        return ret_err(CONFD_ERR_NOEXISTS, "Type doesn't exist");
    return register_type(ntype->type, type);
}

int confd_register_node_type(struct confd_cs_node *node,
                             struct confd_type *type)
{
    if (node->info.type == NULL)
        return ret_err(CONFD_ERR_PROTOUSAGE, "Node does not have a type");
    return register_type(node->info.type, type);
}

static void set_type_err(struct confd_type_ctx *ctx, char *str)
{
    if (ctx->errstr != NULL) {
        ret_err(CONFD_ERR_BADTYPE, "%s", ctx->errstr);
        free(ctx->errstr);
    } else if (confd_errno != 0) {
        return;
    } else {
        ret_err(CONFD_ERR_BADTYPE, "%s", str);
    }
}

int confd_val2str(struct confd_type *type, const confd_value_t *val,
                  char *buf, int bufsiz)
{
    struct confd_type_ctx ctx = {NULL, 0, NULL};
    int ret;

    clr_confd_err();
    if (type == NULL)
        return ret_err(CONFD_ERR_BADTYPE, "Invalid type reference");
    ret = type->val_to_str(type, &ctx, val, buf, bufsiz < 0 ? 0 : bufsiz, NULL);
    if (ret < 0) {
        set_type_err(&ctx, "Invalid value for type");
        return CONFD_ERR;
    }
    return ret;
}

int confd_str2val(struct confd_type *type, const char *str,
                  confd_value_t *val)
{
    struct confd_type_ctx ctx = {NULL, 0, NULL};

    clr_confd_err();
    if (type == NULL)
        return ret_err(CONFD_ERR_BADTYPE, "Invalid type reference");
    if (!type->str_to_val(type, &ctx, str, strlen(str), val)) {
        set_type_err(&ctx,  "Invalid string for type");
        return CONFD_ERR;
    }
    return CONFD_OK;
}

char *confd_val2str_ptr(struct confd_type *type, const confd_value_t *val)
{
    struct confd_type_ctx ctx = {NULL, 0, NULL};
    int ret;
    char dummy;
    const char *ptr = NULL;

    clr_confd_err();
    if (type == NULL) {
        ret_err(CONFD_ERR_BADTYPE, "Invalid type reference");
        return NULL;
    }
    ret = type->val_to_str(type, &ctx, val, &dummy, 0, &ptr);
    if (ret < 0) {
        set_type_err(&ctx, "Invalid value for type");
        return NULL;
    }
    return (char *)ptr;
}


/* deprecated - use confd_hash2str() */
char *confd_xmltag2str(u_int32_t ns, u_int32_t xmltag)
{
    return confd_hash2str(xmltag);
}


static char *tzstring2(int zone, int minutes, char *buf, int bufsiz, int is_dt)
{
    char *sign="";

    if (zone == CONFD_TIMEZONE_UNDEF) {
        confd_strlcpy(buf, "", bufsiz);
        return buf;
    }
    if (zone == 0) {
        if (!is_dt && minutes == 0) {
            confd_strlcpy(buf, "Z", bufsiz);
            return buf;
        } else if (minutes < 0) {
            sign = "-";
        } else {
            sign = "+";
        }
    } else {
        if (zone < 0) {
            sign = "-";
        } else {
            sign = "+";
        }
    }

    snprintf(buf, bufsiz, "%s%02d:%02d", sign, abs(zone), abs(minutes));
    return buf;
}

static char *tzstring(int zone, int minutes, char *buf, int bufsiz)
{
    return tzstring2(zone, minutes, buf, bufsiz, 0);
}

static char *micro_str(int micros, char *buf, int bufsiz)
{
    if (micros == 0) {
        confd_strlcpy(buf, "", bufsiz);
    } else {
        snprintf(buf, bufsiz, ".%06u", micros);
    }
    return buf;
}

/* deprecated - use confd_pp_vaue() or confd_val2str() */
int confd_ns_pp_value(char *buf, int n, const confd_value_t *v, int ns)
{
    return confd_pp_value(buf, n, v);
}


/* pp one value to a buf */
/* returns int as snprinf() */
int confd_pp_value(char *buf, int n, const confd_value_t *v)
{
    char *str;
    char tmpbuf[128];
    char microbuf[32];

    if (n < 0)
        n = 0;

    switch (v->type) {
    case C_XMLTAG:
    case C_XMLBEGIN:
    case C_XMLBEGINDEL:
    case C_XMLEND:
    case C_XMLMOVEFIRST:
    case C_XMLMOVEAFTER: {
        str = confd_hash2str(CONFD_GET_XML(v));
        if (str != NULL)
            return confd_snprintf(buf, n, "%s", str);
        else
            return confd_snprintf(buf, n, "tag<%d>", CONFD_GET_XML(v));
    }
    case C_STR:
        return confd_snprintf(buf, n, "\"%s\"", v->val.s);
    case C_BUF: {
        int sz = CONFD_GET_BUFSIZE(v);
        if (sz < n) {
            memcpy(buf, (char *)CONFD_GET_BUFPTR(v), sz);
            buf[sz] = 0;
            return sz;
        }
        else { /* not enough space */
            if (n > 0) {
                memcpy(buf, (char *)CONFD_GET_BUFPTR(v), n);
                buf[n-1] = 0;
            }
            return sz;
        }
    }
    case C_BINARY: {
        unsigned char *ptr = CONFD_GET_BINARY_PTR(v);
        int sz = CONFD_GET_BINARY_SIZE(v);
        int i, pos = 0;
        if (sz == 0) {
            if (n > 0)
                buf[pos] = '\0';
            return 0;
        }
        for (i = 0; i < sz && pos < n; i++)
            pos += confd_snprintf(buf + pos, n-pos,
                                  "%.02x", ptr[i]);
        return 2*sz;
    }
    case C_INT8:
        return confd_snprintf(buf, n, "%d", CONFD_GET_INT8(v));
    case C_INT16:
        return confd_snprintf(buf, n, "%d", CONFD_GET_INT16(v));
    case C_INT32:
        return confd_snprintf(buf, n, "%d", CONFD_GET_INT32(v));
    case C_INT64:
        return confd_snprintf(buf, n, "%" PRId64, CONFD_GET_INT64(v));
    case C_UINT8:
        return confd_snprintf(buf, n, "%u", CONFD_GET_UINT8(v));
    case C_UINT16:
        return confd_snprintf(buf, n, "%u", CONFD_GET_UINT16(v));
    case C_UINT32:
        return confd_snprintf(buf, n, "%u", CONFD_GET_UINT32(v));
    case C_UINT64:
        return confd_snprintf(buf, n, "%" PRIu64, CONFD_GET_UINT64(v));
    case C_DOUBLE:
        return  confd_snprintf(buf, n, "%f", CONFD_GET_DOUBLE(v));
    case C_IPV4: {
        struct in_addr ip4 = CONFD_GET_IPV4(v);
        if (inet_ntop(AF_INET, &ip4, tmpbuf, sizeof(tmpbuf)) == NULL)
            return 0;
        return confd_snprintf(buf, n, "%s", tmpbuf);
    }
    case C_IPV6: {
        struct in6_addr ip6 = CONFD_GET_IPV6(v);
        if (inet_ntop(AF_INET6,&ip6, tmpbuf, sizeof(tmpbuf)) == NULL)
            return 0;
        return confd_snprintf(buf, n,"%s", tmpbuf);
    }
    case C_BOOL:
        if (CONFD_GET_BOOL(v))
            return confd_snprintf(buf,n,"true");
        return confd_snprintf(buf,n,"false");
    case C_QNAME:
        return confd_snprintf(buf, n, "%.*s%s%.*s",
                              CONFD_GET_QNAME_PREFIX_SIZE(v),
                              CONFD_GET_QNAME_PREFIX_PTR(v),
                              CONFD_GET_QNAME_PREFIX_SIZE(v) > 0 ? ":" : "",
                              CONFD_GET_QNAME_NAME_SIZE(v),
                              CONFD_GET_QNAME_NAME_PTR(v));
    case C_DATETIME: {
        struct confd_datetime dt = CONFD_GET_DATETIME(v);
        char *tz = tzstring2(dt.timezone, dt.timezone_minutes, tmpbuf,
                             sizeof(tmpbuf), 1);
        char *microstr = micro_str(dt.micro, microbuf, sizeof(microbuf));
        return (confd_snprintf(buf, n,
                               "%d-%02d-%02dT%02d:%02d:%02d%s%s",
                               dt.year, dt.month, dt.day,
                               dt.hour, dt.min, dt.sec,
                               microstr, tz));
    }
    case C_DATE: {
        struct confd_date dt = CONFD_GET_DATE(v);
        char *tz = tzstring(dt.timezone, dt.timezone_minutes, tmpbuf,
                            sizeof(tmpbuf));
        return (confd_snprintf(buf, n,
                               "%d-%02d-%02d%s",
                               dt.year, dt.month, dt.day, tz));
    }
    case C_TIME: {
        struct confd_time dt = CONFD_GET_TIME(v);
        char *tz = tzstring(dt.timezone,dt.timezone_minutes, tmpbuf,
                            sizeof(tmpbuf));
        char *microstr = micro_str(dt.micro, microbuf, sizeof(microbuf));
        return (confd_snprintf(buf, n,
                               "%02d:%02d:%02d%s%s",
                               dt.hour, dt.min, dt.sec, microstr, tz));
    }
    case C_DURATION: {
        int printing = 0;
        int tot = 0;
        char *T = "T";
        struct confd_duration dt = CONFD_GET_DURATION(v);

        INC_CONFD_SNPRINTF(buf, n, tot, "P");
        if (dt.years > 0) {
            printing = 1;
            INC_CONFD_SNPRINTF(buf, n, tot, "%dY", dt.years);
        }
        if (dt.months > 0 || printing) {
            printing = 1;
            INC_CONFD_SNPRINTF(buf, n, tot, "%dM", dt.months);
        }
        if (dt.days > 0 || printing) {
            printing = 1;
            INC_CONFD_SNPRINTF(buf, n, tot, "%dD", dt.days);
        }
        if (dt.hours > 0 || printing) {
            printing = 1;
            INC_CONFD_SNPRINTF(buf, n, tot, "%s%dH", T,dt.hours);
            T = "";
        }
        if (dt.mins > 0 || printing) {
            printing = 1;
            INC_CONFD_SNPRINTF(buf, n, tot, "%s%dM", T,dt.mins);
            T = "";
        }
        if (dt.secs > 0 || printing) {
            printing = 1;
            INC_CONFD_SNPRINTF(buf, n, tot, "%s%dS", T,dt.secs);
            T = "";
        }
        if (dt.micros > 0 || printing) {
            printing = 1;
            INC_CONFD_SNPRINTF(buf, n, tot, "%s.%d", T,dt.micros);
        }
        return tot;
    }
    case C_ENUM_HASH:
        return confd_snprintf(buf, n, "enum<%d>", CONFD_GET_ENUM_HASH(v));
    case C_BIT32:
        return confd_snprintf(buf, n, "bits<0x%x>", CONFD_GET_BIT32(v));
    case C_BIT64:
        return confd_snprintf(buf, n, "bits<0x%" PRIx64 ">",CONFD_GET_BIT64(v));
    case C_BITBIG: {
        char *prefix = "bits<0x", *suffix = ">";
        unsigned char *ptr = CONFD_GET_BITBIG_PTR(v);
        int sz = CONFD_GET_BITBIG_SIZE(v);
        int i, pos = 0, len;
        pos += confd_snprintf(buf, n, "%s", prefix);
        for (i = sz - 1; i >= 0 && ptr[i] == 0; i--)
            ;
        if (i >= 0) {
            len = 2 * (i + 1);
            for (; i >= 0 && pos < n; i--)
                pos += confd_snprintf(buf + pos, n-pos,  "%.02x", ptr[i]);
        } else {
            len = 1;
            pos += confd_snprintf(buf + pos, n-pos, "0");
        }
        confd_snprintf(buf + pos, n - pos, "%s", suffix);
        return strlen(prefix) + len + strlen(suffix);
    }
    case C_LIST: {
        int i; int pos = 0;
        int n2 = n;
        if (v->val.list.size == 0) {
            if (n2 > 0)
                buf[pos] = '\0';
            return 0;
        }
        for(i=0; i < v->val.list.size-1; i++) {
            pos += confd_pp_value(buf+pos, n2, &v->val.list.ptr[i]);
            n2 = n - pos;
            pos += confd_snprintf(buf+pos, n2, " ");
            n2 = n - pos;
        }
        pos += confd_pp_value(buf+pos, n2,
                              &v->val.list.ptr[v->val.list.size-1]);
        return pos;
    }
    case C_NOEXISTS:
        return confd_snprintf(buf, n, "%s","NOEXISTS");
    case C_DEFAULT:
        return confd_snprintf(buf, n, "%s","DEFAULT");
    case C_OBJECTREF: {
        confd_hkeypath_t *hkp = CONFD_GET_OBJECTREF(v);
        return confd_xpath_pp_kpath(buf, n, 0, hkp);
    }
    case C_OID: {
        struct confd_snmp_oid *oidp = CONFD_GET_OID(v);
        int i, pos = 0;
        if (oidp->len == 0) {
            if (n > 0)
                buf[pos] = '\0';
            return 0;
        }
        for (i = 0; i < oidp->len; i++)
            pos += confd_snprintf(buf + pos, n - pos,
                                  i > 0 ? ".%u" : "%u", oidp->oid[i]);
        return pos;
    }
    case C_IPV4PREFIX: {
        struct confd_ipv4_prefix ipv4prefix = CONFD_GET_IPV4PREFIX(v);
        if (inet_ntop(AF_INET, &ipv4prefix.ip, tmpbuf, sizeof(tmpbuf)) == NULL)
            return 0;
        return confd_snprintf(buf, n, "%s/%d", tmpbuf, ipv4prefix.len);
    }
    case C_IPV6PREFIX: {
        struct confd_ipv6_prefix ipv6prefix = CONFD_GET_IPV6PREFIX(v);
        if (inet_ntop(AF_INET6, &ipv6prefix.ip6,
                      tmpbuf, sizeof(tmpbuf)) == NULL) {
            return 0;
        }
        return confd_snprintf(buf, n,"%s/%d", tmpbuf, ipv6prefix.len);
    }
    case C_DECIMAL64: {
        struct confd_decimal64 d64 = CONFD_GET_DECIMAL64(v);
        if (d64.fraction_digits < 1 || d64.fraction_digits > 18)
            return confd_snprintf(buf, n, "invalid64<%" PRId64 ">", d64.value);
        return confd_pp_decimal64_value(&d64, buf, n >= 0 ? n : 0);
    }
    case C_IDENTITYREF: {
        struct confd_identityref idref = CONFD_GET_IDENTITYREF(v);
        str = confd_hash2str(idref.id);
        if (str != NULL)
            return confd_snprintf(buf, n, "%s", str);
        else
            return confd_snprintf(buf, n, "idref<%d>", idref.id);
    }
    case C_IPV4_AND_PLEN: {
        struct confd_ipv4_prefix ipv4prefix = CONFD_GET_IPV4_AND_PLEN(v);
        if (inet_ntop(AF_INET, &ipv4prefix.ip, tmpbuf, sizeof(tmpbuf)) == NULL)
            return 0;
        return confd_snprintf(buf, n, "%s/%d", tmpbuf, ipv4prefix.len);
    }
    case C_IPV6_AND_PLEN: {
        struct confd_ipv6_prefix ipv6prefix = CONFD_GET_IPV6_AND_PLEN(v);
        if (inet_ntop(AF_INET6, &ipv6prefix.ip6,
                      tmpbuf, sizeof(tmpbuf)) == NULL) {
            return 0;
        }
        return confd_snprintf(buf, n,"%s/%d", tmpbuf, ipv6prefix.len);
    }
    case C_DQUAD: {
        struct confd_dotted_quad dquad = CONFD_GET_DQUAD(v);
        return confd_snprintf(buf, n, "%d.%d.%d.%d", dquad.quad[0],
                              dquad.quad[1], dquad.quad[2], dquad.quad[3]);
    }
    case C_HEXSTR: {
        unsigned char *ptr = CONFD_GET_HEXSTR_PTR(v);
        int sz = CONFD_GET_HEXSTR_SIZE(v);
        int i, pos = 0;
        if (sz == 0) {
            if (n > 0)
                buf[pos] = '\0';
            return 0;
        }
        pos += confd_snprintf(buf, n, "%.02x", ptr[0]);
        for (i = 1; i < sz && pos < n; i++)
            pos += confd_snprintf(buf + pos, n-pos,
                                  ":%.02x", ptr[i]);
        return 3 * sz - 1;
    }
    case C_SYMBOL:
    case C_UNION:
    case C_CDBBEGIN:
    case C_PTR:
    case C_MAXTYPE:
        return confd_snprintf(buf,n,"badval");
    }

    return confd_snprintf(buf,n,"badval");
}

/* returns int as snprinf() */
int confd_format_keypath(char *buf, int bufsiz, const char *fmt, ...)
{
    int rval;
    va_list args;

    va_start(args,fmt);
    rval = confd_vformat_keypath(buf, bufsiz, fmt, args);
    va_end(args);
    return rval;
}


/* pretty-print a hkeypath to buf */
int confd_pp_kpath(char *buf, int n, const confd_hkeypath_t *hkeypath)
{
    return confd_pp_kpath_len(buf, n, hkeypath, hkeypath->len);
}


int confd_fpp_kpath(FILE *stream, const confd_hkeypath_t *hkeypath)
{
    int ret;
    char tmpbuf[BUFSIZ];
    ret = confd_pp_kpath(tmpbuf, BUFSIZ, hkeypath);
    if (stream) fprintf(stream, "%s", tmpbuf);
    return ret;
}

/* general purpose function to match tags and hkeypaths */
int confd_hkp_tagmatch(struct xml_tag tags[], int tagslen,
                       confd_hkeypath_t *hkp)
{
    int tpos = 0;
    int hpos;
    confd_value_t *vp;

    /* walk backwards in the hkp and forwards in the tags array */
    for (hpos = hkp->len-1; hpos >= 0; hpos--) {
        if (tpos == tagslen)
            return CONFD_HKP_MATCH_TAGS;
        vp = &hkp->v[hpos][0];
        if (vp->type != C_XMLTAG) {  /* skip this key field */
            continue;
        }
        if (!((vp->val.xmltag.tag == tags[tpos].tag) &&
              (vp->val.xmltag.ns == tags[tpos].ns))) {
            return CONFD_HKP_MATCH_NONE;
        }
        tpos++;
    }
    if (tpos == tagslen)
        return CONFD_HKP_MATCH_FULL;
    return CONFD_HKP_MATCH_HKP;
}

/* general purpose function to match prefixes in hkeypaths */
int confd_hkp_prefix_tagmatch(struct xml_tag tags[], int tagslen,
                              confd_hkeypath_t *hkp)
{
    if (tagslen > hkp->len)
        return 0;
    if (confd_hkp_tagmatch(tags, tagslen, hkp) & CONFD_HKP_MATCH_TAGS)
        return 1;
    return 0;
}


/* debug functions to be used from gdb */

void ppp(const confd_hkeypath_t *hkeypath)
{
    confd_fpp_kpath(stderr, hkeypath);
}

void pv(const confd_value_t *v)
{
    char buf[BUFSIZ];
    confd_pp_value(buf, BUFSIZ, v);
    fprintf(stderr, "%s\n", buf);
}

void pt(const ETERM *t)
{
    erl_print_term(stderr, t);
    fprintf(stderr, "\n");
}

void perr(void)
{
    printf("%s\n", confd_lasterr());
}


/* *************************** */

static void reply_trace(const confd_value_t *vp)
{
    if (confd_debug_level >= CONFD_TRACE) {
        char tbuf[BUFSIZ];

        confd_pp_value(tbuf, BUFSIZ, vp);
        confd_trace_printf(" (%s) ", tbuf);
    }
}


static void kp_trace(const struct confd_trans_ctx *tctx, const char *func,
                     const confd_hkeypath_t *keypath)
{
    if (confd_debug_level >= CONFD_TRACE) {
        char tbuf[BUFSIZ];
        confd_pp_kpath(tbuf, BUFSIZ, keypath);
        confd_trace_printf("TRACE CALL data %s(thandle=%d,%s)",
                           func, tctx->thandle,tbuf);
    }
}

static void kp_trace2(const struct confd_trans_ctx *tctx, const char *func,
                      const confd_hkeypath_t *keypath,
                      const confd_value_t *v)
{
    if (confd_debug_level >= CONFD_TRACE) {
        char tbuf[BUFSIZ];
        char vbuf[BUFSIZ];
        confd_pp_kpath(tbuf, BUFSIZ, keypath);
        confd_pp_value(vbuf, BUFSIZ, v);
        confd_trace_printf("TRACE CALL data %s(thandle=%d, %s, %s)", func,
                           tctx->thandle, tbuf, vbuf);
    }
}

static void kp_trace_find(const struct confd_trans_ctx *tctx, const char *func,
                          const confd_hkeypath_t *keypath,
                          enum confd_find_next_type type,
                          const confd_value_t *keys, int nkeys)
{
    if (confd_debug_level >= CONFD_TRACE) {
        char tbuf[BUFSIZ];
        char vbuf[BUFSIZ];
        char *vp = vbuf;
        int i;
        confd_pp_kpath(tbuf, BUFSIZ, keypath);
        *vp = '\0';
        for (i = 0; i < nkeys; i++) {
            vp += pp_keyval(vp, BUFSIZ - (vp - vbuf), &keys[i], 0);
            if (i < nkeys - 1)
                vp += confd_snprintf(vp, BUFSIZ - (vp - vbuf), " ");
        }
        confd_trace_printf("TRACE CALL data %s(thandle=%d, %s, %s, {%s})",
                           func, tctx->thandle, tbuf,
                           type == CONFD_FIND_NEXT ? "next" : "same_or_next",
                           vbuf);
    }
}

static void kp_trace_choice_case(const struct confd_trans_ctx *tctx,
                                 const char *func,
                                 const confd_hkeypath_t *keypath,
                                 const confd_value_t *cpath, int cp_len,
                                 const confd_value_t *casev)
{
    if (confd_debug_level >= CONFD_TRACE) {
        char tbuf[BUFSIZ];
        char vbuf[BUFSIZ];
        char *vp = vbuf;
        int i;
        confd_pp_kpath(tbuf, BUFSIZ, keypath);
        *vp = '\0';
        for (i = cp_len - 1; i >= 0; i--) {
            vp += confd_pp_value(vp, BUFSIZ - (vp - vbuf), &cpath[i]);
            if (i > 0)
                vp += confd_snprintf(vp, BUFSIZ - (vp - vbuf), "/");
        }
        if (casev != NULL) {
            vp += snprintf(vp, BUFSIZ - (vp - vbuf), ", ");
            confd_pp_value(vp, BUFSIZ - (vp - vbuf), casev);
        }
        confd_trace_printf("TRACE CALL data %s(thandle=%d, %s, %s)", func,
                           tctx->thandle, tbuf, vbuf);
    }
}

static void kp_trace_service(const struct confd_trans_ctx *tctx,
                             const char *func,
                             const confd_hkeypath_t *keypath)
{
    if (confd_debug_level >= CONFD_TRACE) {
        char tbuf[BUFSIZ];
        confd_pp_kpath(tbuf, BUFSIZ, keypath);
        confd_trace_printf("TRACE CALL service %s(thandle=%d, %s)",
                           func, tctx->thandle,tbuf);
    }
}


/* returns positive value if v1 and v2 are equal, and 0 otherwise */
int confd_val_eq(const confd_value_t *v1, const confd_value_t *v2)
{
    if (v1->type != v2->type)
        return 0;
    switch (v1->type) {
    case C_STR:
        return (strcmp(v1->val.s, v2->val.s) == 0);
    case C_BUF:
    case C_BINARY:
    case C_HEXSTR:
        if (v1->val.buf.size != v2->val.buf.size)
            return 0;
        return memcmp(v1->val.buf.ptr, v2->val.buf.ptr, v1->val.buf.size) == 0;
    case C_QNAME:
        if (v1->val.qname.prefix.size != v2->val.qname.prefix.size)
            return 0;
        if (v1->val.qname.prefix.size > 0) {
            if (memcmp(v1->val.qname.prefix.ptr, v2->val.qname.prefix.ptr,
                       v1->val.qname.prefix.size) != 0) {
                return 0;
            }
        }
        /* now compare name */
        if (v1->val.qname.name.size != v2->val.qname.name.size)
            return 0;
        return (memcmp(v1->val.qname.name.ptr, v2->val.qname.name.ptr,
                       v1->val.qname.name.size) == 0);
    case C_NOEXISTS:
    case C_DEFAULT:
        return 1;
#define IS_EQUAL(ELEM) (v1->val.ELEM == v2->val.ELEM)
    case C_XMLTAG:
    case C_XMLBEGIN:
    case C_XMLBEGINDEL:
    case C_XMLEND:
    case C_XMLMOVEFIRST:
    case C_XMLMOVEAFTER:
        return (IS_EQUAL(xmltag.tag)) && (IS_EQUAL(xmltag.ns));
    case C_CDBBEGIN:
        return IS_EQUAL(i32);
    case C_SYMBOL:
        return IS_EQUAL(symbol);
    case C_INT8:
        return IS_EQUAL(i8);
    case C_INT16:
        return IS_EQUAL(i16);
    case C_INT32:
        return IS_EQUAL(i32);
    case C_INT64:
        return IS_EQUAL(i64);
    case C_UINT8:
        return IS_EQUAL(u8);
    case C_UINT16:
        return IS_EQUAL(u16);
    case C_UINT32:
        return IS_EQUAL(u32);
    case C_UINT64:
        return IS_EQUAL(u64);
    case C_DOUBLE:
        return IS_EQUAL(d);
    case C_IPV4:
        return IS_EQUAL(ip.s_addr);
    case C_IPV6:
        return (IS_EQUAL(ip6.s6_addr[0])) && (IS_EQUAL(ip6.s6_addr[1])) &&
            (IS_EQUAL(ip6.s6_addr[2])) && (IS_EQUAL(ip6.s6_addr[3])) &&
            (IS_EQUAL(ip6.s6_addr[4])) && (IS_EQUAL(ip6.s6_addr[5])) &&
            (IS_EQUAL(ip6.s6_addr[6])) && (IS_EQUAL(ip6.s6_addr[7])) &&
            (IS_EQUAL(ip6.s6_addr[8])) && (IS_EQUAL(ip6.s6_addr[9])) &&
            (IS_EQUAL(ip6.s6_addr[10])) && (IS_EQUAL(ip6.s6_addr[11])) &&
            (IS_EQUAL(ip6.s6_addr[12])) && (IS_EQUAL(ip6.s6_addr[13])) &&
            (IS_EQUAL(ip6.s6_addr[14])) && (IS_EQUAL(ip6.s6_addr[15]));
    case C_BOOL:
        return IS_EQUAL(boolean);
    case C_DATETIME:
        return (IS_EQUAL(datetime.year)) && (IS_EQUAL(datetime.month)) &&
            (IS_EQUAL(datetime.day)) && (IS_EQUAL(datetime.hour)) &&
            (IS_EQUAL(datetime.min)) && (IS_EQUAL(datetime.sec)) &&
            (IS_EQUAL(datetime.micro)) &&
            (IS_EQUAL(datetime.timezone)) &&
            (IS_EQUAL(datetime.timezone_minutes));
    case C_DATE:
        return (IS_EQUAL(date.year)) && (IS_EQUAL(date.month)) &&
            (IS_EQUAL(date.day)) && (IS_EQUAL(date.timezone)) &&
            (IS_EQUAL(date.timezone_minutes));
    case C_TIME:
        return (IS_EQUAL(time.hour)) && (IS_EQUAL(time.min)) &&
            (IS_EQUAL(time.sec)) && (IS_EQUAL(time.micro)) &&
            (IS_EQUAL(time.timezone)) && (IS_EQUAL(time.timezone_minutes));
    case C_DURATION:
        return (IS_EQUAL(duration.years)) && (IS_EQUAL(duration.months)) &&
            (IS_EQUAL(duration.days)) && (IS_EQUAL(duration.hours)) &&
            (IS_EQUAL(duration.mins)) && (IS_EQUAL(duration.secs)) &&
            (IS_EQUAL(duration.micros));
    case C_ENUM_HASH:
        return IS_EQUAL(enumhash);
    case C_BIT32:
        return IS_EQUAL(b32);
    case C_BIT64:
        return IS_EQUAL(b64);
    case C_BITBIG: {
        int sz1 = v1->val.buf.size, sz2 = v2->val.buf.size;
        /* ignore "upper" bytes without bits set */
        while (sz1 > 0 && v1->val.buf.ptr[sz1 - 1] == 0)
            sz1--;
        while (sz2 > 0 && v2->val.buf.ptr[sz2 - 1] == 0)
            sz2--;
        if (sz1 != sz2)
            return 0;
        return memcmp(v1->val.buf.ptr, v2->val.buf.ptr, sz1) == 0;
    }
    case C_LIST: {
        int i;
        if (v1->val.list.size != v2->val.list.size) return 0;
        for (i=0;i<v1->val.list.size;i++) {
            if (confd_val_eq(&v1->val.list.ptr[i], &v2->val.list.ptr[i]) == 0)
                return 0;
        }
        return 1;
    }
    case C_OBJECTREF: {
        int i, j;
        if (v1->val.hkp->len != v2->val.hkp->len)
            return 0;
        for (i=0; i<v1->val.hkp->len; i++) {
            for (j=0; j<MAXKEYLEN; j++) {
                if (confd_val_eq(&v1->val.hkp->v[i][j],
                                 &v2->val.hkp->v[i][j]) == 0)
                    return 0;
                if (v1->val.hkp->v[i][j].type == C_NOEXISTS ||
                    v1->val.hkp->v[i][j].type == C_XMLTAG)
                    break;
            }
        }
        return 1;
    }
    case C_OID: {
        int i;
        if (v1->val.oidp->len != v2->val.oidp->len) return 0;
        for (i = 0; i < v1->val.oidp->len; i++) {
            if (v1->val.oidp->oid[i] != v2->val.oidp->oid[i])
                return 0;
        }
        return 1;
    }
    case C_IPV4PREFIX:
    case C_IPV4_AND_PLEN:
        return (IS_EQUAL(ipv4prefix.ip.s_addr)) &&
            (IS_EQUAL(ipv4prefix.len));
    case C_IPV6PREFIX:
    case C_IPV6_AND_PLEN:
        return (IS_EQUAL(ipv6prefix.ip6.s6_addr[0])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[1])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[2])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[3])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[4])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[5])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[6])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[7])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[8])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[9])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[10])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[11])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[12])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[13])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[14])) &&
            (IS_EQUAL(ipv6prefix.ip6.s6_addr[15])) &&
            (IS_EQUAL(ipv6prefix.len));
    case C_DECIMAL64:
        return (IS_EQUAL(d64.value)) && (IS_EQUAL(d64.fraction_digits));
    case C_IDENTITYREF:
        return (IS_EQUAL(idref.id)) && (IS_EQUAL(idref.ns));
    case C_DQUAD:
        return memcmp(v1->val.dquad.quad, v2->val.dquad.quad, 4) == 0;
    case C_UNION:
        return 0;
    case C_PTR:
        /* Compare type and pointed-to value?
           No, doesn't make sense, it's just for get_values() */
        return 0;
    case C_MAXTYPE:     /* enum end marker */
        return 0;
#undef IS_EQUAL
    }
    return 0;
}




struct confd_trans_ctx *alloc_transaction(struct confd_daemon_ctx *dx,
                                          int thandle)
{
    int i = 0;
    struct confd_trans_ctx *cx;
    int attempts;
    struct confd_trans_ctx **new_trans;

    if (dx) { /* NULL when we're allocating from NOTIF */
        PTHREAD_MUTEX_LOCK(dx->slock);
        i = dx->index_pos;
        for (attempts = 0; attempts < dx->trans_len; attempts++) {
            if (dx->transactions[i] == NULL)
                break;
            if (++i == dx->trans_len)
                i = 0;
        }
        if (attempts == dx->trans_len) {
            if ((new_trans = realloc(
                     dx->transactions,
                     (dx->trans_len + TRANS_INCREMENT) *
                     sizeof(struct confd_trans_ctx *))) == NULL) {
                PTHREAD_MUTEX_UNLOCK(dx->slock);
                return NULL;
            }
            memset(&new_trans[dx->trans_len], 0,
                   TRANS_INCREMENT * sizeof(struct confd_trans_ctx *));
            dx->transactions = new_trans;
            i = dx->trans_len;
            dx->trans_len += TRANS_INCREMENT;
        }
        if ((dx->transactions[i] =
             calloc(1, sizeof(struct confd_trans_ctx))) == NULL) {
            PTHREAD_MUTEX_UNLOCK(dx->slock);
            return NULL;
        }
        cx = dx->transactions[i];
    }
    else {
        cx = calloc(1, sizeof(struct confd_trans_ctx));
    }
    cx->index = i;
    cx->fd = -1;
    cx->vfd = -1;
    cx->dx = dx;
    cx->thandle = thandle;
    if (dx) {
        cx->refc = 1;
        if (++i == dx->trans_len)
            i = 0;
        dx->index_pos  = i;
        PTHREAD_MUTEX_UNLOCK(dx->slock);
    }
    return cx;
}



static struct confd_trans_ctx *tid_to_trans_refc(struct confd_daemon_ctx *dx,
                                                 int thandle, int do_refc)
{
    int i, j;
    struct confd_trans_ctx *s = NULL;

    PTHREAD_MUTEX_LOCK(dx->slock);
    if (dx->index_pos > 0)
        i = dx->index_pos - 1;
    else
        i = dx->trans_len - 1;
    for (j = 0; j < dx->trans_len; j++) {
        if (dx->transactions[i] && dx->transactions[i]->thandle == thandle) {
            s = dx->transactions[i];
            if (do_refc)
                s->refc++;
            break;
        }
        if (++i == dx->trans_len)
            i = 0;
    }
    PTHREAD_MUTEX_UNLOCK(dx->slock);
    return s;
}

static struct confd_trans_ctx *tid_to_trans(struct confd_daemon_ctx *dx,
                                            int thandle)
{
    return tid_to_trans_refc(dx, thandle, 0);
}

static struct confd_trans_ctx *get_transaction(struct confd_daemon_ctx *dx,
                                               int thandle)
{
    return tid_to_trans_refc(dx, thandle, 1);
}

/* return 1 if tctx should be freed, 0 if not */
static int put_transaction(struct confd_trans_ctx *tctx)
{
    struct confd_daemon_ctx *dx = tctx->dx;
    int ret = 0;

    PTHREAD_MUTEX_LOCK(dx->slock);
    tctx->refc--;
    if (tctx->refc == 0) {
        dx->transactions[tctx->index] = NULL;
        ret = 1;
    }
    PTHREAD_MUTEX_UNLOCK(dx->slock);
    return ret;
}

static void free_error(struct confd_error *error);

static void put_user_session(struct confd_daemon_ctx *dx,
                             struct confd_user_info *uinfo);

static void tctx_free(struct confd_trans_ctx *tctx)
{
    if (tctx->dx != NULL && tctx->uinfo != NULL) {
        put_user_session(tctx->dx, tctx->uinfo);
    }
    free_error(&tctx->error);
    free(tctx);
}


#if 0

/* Extract a string from an ETERM and */
/* write it into *ptr, we're not using strings */
/* but when (if) we do this function is good */

static int et_get_string(const ETERM* ep, char* ptr)
{
    int sz = 0;

    while (ERL_IS_CONS(ep)) {
        int c = ERL_INT_VALUE(ERL_CONS_HEAD(ep));
        *ptr++ = c;
        sz++;
        ep = ERL_CONS_TAIL(ep);
    }
    *ptr = 0;
    return sz;
}

#endif


static struct confd_data_cbs *tag_to_datacbs(
    struct confd_daemon_ctx* dx,
    const ETERM *callpoint, int index)
{
    if (index <= dx->num_data_cbs &&
        bin_eq(callpoint, dx->data_cbs[index-1].callpoint)) /* sanity check */
        return &dx->data_cbs[index-1];
    return NULL;
}


static struct ncs_service_cbs *tag_to_servcbs(
    struct confd_daemon_ctx* dx,
    const ETERM *callpoint, int index)
{
    if (index <= dx->num_service_cbs &&
        bin_eq(callpoint, dx->service_cbs[index-1].servicepoint)) /* sanity */
        return &dx->service_cbs[index-1];
    return NULL;
}

static struct ncs_nano_service_cbs *tag_to_nanoservcbs(
    struct confd_daemon_ctx* dx,
    const ETERM *callpoint, int index)
{
    if (index <= dx->num_nano_service_cbs &&
        bin_eq(callpoint,
               dx->nano_service_cbs[index-1].servicepoint)) /* sanity */
        return &dx->nano_service_cbs[index-1];
    return NULL;
}


static struct confd_valpoint_cb *tag_to_valcbs(
    struct confd_daemon_ctx* dx,
    const ETERM *valpoint, int index)
{
    if (index <= dx->num_validation_cbs &&
        bin_eq(valpoint, dx->valp_cbs[index-1].valpoint)) /* sanity check */
        return &dx->valp_cbs[index-1];
    return NULL;
}


static struct confd_action_cbs *tag_to_actcbs(
    struct confd_daemon_ctx* dx,
    const ETERM *actionpoint, int index)
{
    if (index <= dx->num_action_cbs &&
        bin_eq(actionpoint, dx->action_cbs[index-1].actionpoint)) /* sanity */
        return &dx->action_cbs[index-1];
    return NULL;
}


static struct confd_notification_stream_cbs *tag_to_notifcbs(
    struct confd_daemon_ctx* dx,
    const ETERM *streamname, int index)
{
    if (index <= dx->num_notif_cbs &&
        bin_eq(streamname, dx->notif_cbs[index-1].streamname)) /* sanity chk */
        return &dx->notif_cbs[index-1];
    return NULL;
}

static struct confd_notification_snmp_inform_cbs *tag_to_snmp_informcbs(
    struct confd_daemon_ctx* dx,
    const ETERM *sub_id, int index)
{
    if (index <= dx->num_notif_snmp_inform_cbs &&
        bin_eq(sub_id, dx->notif_snmp_inform_cbs[index-1].cb_id))
        return &dx->notif_snmp_inform_cbs[index-1];
    return NULL;
}

static struct confd_notification_sub_snmp_cb *tag_to_sub_snmpcbs(
    struct confd_daemon_ctx* dx,
    const ETERM *sub_id, int index)
{
    if (index <= dx->num_notif_sub_snmp_cbs &&
        bin_eq(sub_id, dx->notif_sub_snmp_cbs[index-1].sub_id))
        return &dx->notif_sub_snmp_cbs[index-1];
    return NULL;
}



/* Initialize library */
static PTHREAD_MUTEX_T init_mutex = PTHREAD_MUTEX_INITIALIZER;

void confd_init_vsn_sz(const char *name, FILE *estream,
                       const enum confd_debug_level debug,
                       int vsn, int maxdepth, int maxkeylen)
{
    char *vsn_msg =
        "Library API version (%x) is not compatible with header file "
        "API version (%x)\n- application (%s) must be re-compiled\n";
    char *size_msg =
        "Library MAXDEPTH/MAXKEYLEN (%d/%d) is not compatible with application "
        "(%d/%d)\n- application (%s) must be re-compiled\n";
    unsigned char buf[1024];
    int res;

    if (vsn != CONFD_LIB_API_VSN ||
        maxdepth != MAXDEPTH || maxkeylen != MAXKEYLEN) {
        if (vsn != CONFD_LIB_API_VSN) {
            snprintf((char *)buf, sizeof(buf), vsn_msg,
                     CONFD_LIB_API_VSN, vsn, name);
        } else {
            snprintf((char *)buf, sizeof(buf), size_msg,
                     MAXDEPTH, MAXKEYLEN, maxdepth, maxkeylen, name);
        }
        confd_debug_level = CONFD_DEBUG;
        if (estream != NULL && estream != stderr) {
            fprintf(stderr, "%s", buf);
            confd_debug_stream = estream;
        } else {
            confd_debug_stream = stderr;
        }
        confd_report_err(CONFD_DEBUG, "%s", buf);
        exit(1);
    }

    PTHREAD_MUTEX_LOCK(&init_mutex);
    if (confd_is_initialized == 0) {
        confd_is_initialized = 1;
        confd_crypto_keys.des3_keys_initialized = 0;
        confd_crypto_keys.aes_keys_initialized = 0;
        confd_crypto_keys.aes256_keys_initialized = 0;
        PTHREAD_MUTEX_INIT(&maapi_load_schemas_lock, NULL);
        PTHREAD_KEY_CREATE(&errno_key, free);
        PTHREAD_KEY_CREATE(&lasterr_key, free);
        PTHREAD_KEY_CREATE(&last_apptag_key, free);
        PTHREAD_KEY_CREATE(&confd_syslog_buf_key, free);
        signal(SIGPIPE, SIG_IGN);
        /* Initialize ei libs */
        erl_init(NULL, 0);
        snprintf(confd_daemon_name, sizeof(confd_daemon_name),
                 "%s", name ? name : "");
        confd_debug_level = debug;
        confd_debug_stream = estream;
        if (debug >= CONFD_TRACE && estream)
            setvbuf(estream, NULL, _IONBF, 0);
        confd_type_init();
        res = confd_ipc_access_get_secret(buf, sizeof(buf));
        if (res > 0) {
            confd_ipc_access_secret = (unsigned char *)strdup((char *)buf);
        } else {
            if (res < 0)
                confd_report_err(CONFD_DEBUG, "%s", buf);
            confd_ipc_access_secret = NULL;
        }
    }
    PTHREAD_MUTEX_UNLOCK(&init_mutex);
}

/* Old version for nicer error msg with non-recompiled app */
void confd_init_vsn(const char *name, FILE *estream,
                    const enum confd_debug_level debug, int vsn)
{
    confd_init_vsn_sz(name, estream, debug, vsn, MAXDEPTH, MAXKEYLEN);
}

int confd_check_init()
{
    if (confd_is_initialized != 1) {
        if (confd_is_initialized == 0) {
            /* must init for confd_errno etc to work */
            confd_init("amnesiac", stderr, CONFD_DEBUG);
            /* but this should not make the error go away */
            confd_is_initialized = -1;
        }
        return ret_err(CONFD_ERR_LIB_NOT_INITIALIZED, "Library not initalized");
    }
    return CONFD_OK;
}


/* Initialize one daemon structure */
struct confd_daemon_ctx *confd_init_daemon(const char* name)
{
    struct confd_daemon_ctx *d;

    if ((name == NULL) || (strlen(name) == 0)) {
        ret_err(CONFD_ERR_PROTOUSAGE, "Daemon name is required");
        return NULL;
    }
    d = (struct confd_daemon_ctx*)calloc(1, sizeof (struct confd_daemon_ctx));
    if (d != NULL) {
        snprintf(d->name, sizeof(d->name), "%s", name);
        d->index_pos = 0;       /* next pos to try for alloc */
#ifdef DISABLE_THREADS
        d->slock = confd_malloc(sizeof(char));
#else
        d->slock = confd_malloc(sizeof(pthread_mutex_t));
#endif
        if (d->slock == NULL) {
            free(d);
            return NULL;
        }
        d->user_sessions = create_hashtable(16, usess_hashfromkey,
                                            usess_equalkeys);
        PTHREAD_MUTEX_INIT(d->slock, NULL);
        d->ctl_sock = -1;
        return d;
    }
    confd_set_errno(CONFD_ERR_MALLOC);
    return NULL;
}

/* Set debug level for all library function */
int confd_set_debug(enum confd_debug_level debug, FILE *estream)
{
    confd_debug_level = debug;
    confd_debug_stream = estream;
    if (debug >= CONFD_TRACE && estream)
        setvbuf(estream, NULL, _IONBF, 0);
    return CONFD_OK;
}

int confd_set_daemon_flags(struct confd_daemon_ctx *dx, int flags)
{
    int internal_flags =
        CONFD_DAEMON_FLAG_SEND_IKP | CONFD_DAEMON_FLAG_REG_DONE;

    dx->flags = (dx->flags & internal_flags) | flags;
    return CONFD_OK;
}


int confd_install_crypto_keys(struct confd_daemon_ctx* dtx)
{
    ETERM *req, *reply, *item;
    int status;

    CHECK_REG_OK(dtx);
    req = erl_mk_int(CONFD_GET_CRYPTO_KEYS);
    if ((reply = confd_call(dtx->ctl_sock, req, &status)) == NULL) {
        erl_free_term(req);
        return status;
    }
    erl_free_term(req);
    if (! ERL_IS_TUPLE(reply)) {
        erl_free_compound(reply);
        return confd_internal_error("Bad data for crypto keys");
    }
    item = TE(reply, 0);
    if (ERL_IS_BINARY(item)) {
        /* install des keys */
        memcpy(&confd_crypto_keys.des3_key1[0], ERL_BIN_PTR(TE(reply,0)), 8);
        memcpy(&confd_crypto_keys.des3_key2[0], ERL_BIN_PTR(TE(reply,1)), 8);
        memcpy(&confd_crypto_keys.des3_key3[0], ERL_BIN_PTR(TE(reply,2)), 8);
        memcpy(&confd_crypto_keys.des3_ivec[0], ERL_BIN_PTR(TE(reply,3)), 8);
        confd_crypto_keys.des3_keys_initialized = 1;
    }
    item  = TE(reply, 4);
    if (ERL_IS_BINARY(item)) {
        /* install aes keys */
        memcpy(&confd_crypto_keys.aes_key[0], ERL_BIN_PTR(TE(reply,4)), 16);
        memcpy(&confd_crypto_keys.aes_ivec[0], ERL_BIN_PTR(TE(reply,5)), 16);
        confd_crypto_keys.aes_keys_initialized = 1;
    }
    item  = TE(reply, 6);
    if (ERL_IS_BINARY(item)) {
        /* install aes keys */
        memcpy(&confd_crypto_keys.aes256_key[0], ERL_BIN_PTR(TE(reply,6)), 32);
        confd_crypto_keys.aes256_keys_initialized = 1;
    }

    erl_free_compound(reply);
    return CONFD_OK;
}


static struct confd_user_info *add_user_session(struct confd_daemon_ctx *dx,
                                                const ETERM *utup, int new,
                                                int *is_updatep);
static struct confd_user_info *get_user_session(struct confd_daemon_ctx *dx,
                                                int usid);


/* FIXME, this need more thought */
void confd_release_daemon(struct confd_daemon_ctx *dx)
{
    int i;
    struct confd_trans_ctx *tctx;

    if (dx->transactions != NULL) {
        for (i=0; i<dx->trans_len; i++) {
            if ((tctx = dx->transactions[i]) != NULL) {
                tctx_free(tctx);
            }
        }
        free(dx->transactions);
    }
    if (dx->data_cbs != NULL) free(dx->data_cbs);
    if (dx->valp_cbs != NULL) free(dx->valp_cbs);
    if (dx->action_cbs != NULL) free(dx->action_cbs);
    if (dx->notif_cbs != NULL) free(dx->notif_cbs);
    if (dx->notif_snmp_inform_cbs != NULL) free(dx->notif_snmp_inform_cbs);
    if (dx->notif_sub_snmp_cbs != NULL) free(dx->notif_sub_snmp_cbs);
    if (dx->notif_ctxs != NULL) {
        struct confd_notification_ctx *nctx;
        for (i = 0; i < dx->num_notif_ctxs; i++) {
            nctx = dx->notif_ctxs[i];
            if (nctx->name != NULL)
                free(nctx->name);
            if (nctx->ctx_name != NULL)
                free(nctx->ctx_name);
            free(nctx);
        }
        free(dx->notif_ctxs);
    }
    /* Note, using free_values == 1 requires that
       freekey() in hashtable_private.h is a no-op */
    hashtable_destroy(dx->user_sessions, 1);
    PTHREAD_MUTEX_DESTROY(dx->slock);
    free(dx->slock);
    free(dx);
}


/* connect to confd at let it know that we have a new daemon socket */
/* here. Also fillin dtx with the daemon_id which is received */
/* from confd. The socket arg is an already created but unbound socket */
/* which the caller has created through syscall socket() */

int confd_connect(struct confd_daemon_ctx* dtx, int sock,
                  enum confd_sock_type type,
                  const struct sockaddr* srv, int srv_sz)
{
    ETERM *term, *daemon, *worker;
    int status, ret;

    if ((ret = confd_do_connect(sock, srv, srv_sz, CLIENT_CAPI)) != CONFD_OK)
        return ret;
    confd_trace(CONFD_TRACE, "Connected (dp) to ConfD\n");

    if (type == CONTROL_SOCKET) {
        if ((daemon = erl_format("{~i,~a,~i}", CONFD_PROTO_DAEMON,
                                 dtx->name, dtx->flags)) == NULL) {
            ret_err(CONFD_ERR_MALLOC, "Failed to create datastruct\n");
        }
        if ((term = confd_call(sock, daemon, &status)) == NULL) {
            erl_free_compound(daemon);
            return status;
        }
        erl_free_compound(daemon);

        if (ERL_IS_TUPLE(term) && (ERL_TUPLE_SIZE(term) == 2)) {
            unsigned int did;
            /* unused id_const is first elem */
            did = TUINT(term, 1);

            /* we're all ok, fill in the did  */
            dtx->daemon_id = did;
            dtx->ctl_sock = sock;
            erl_free_compound(term);

            confd_trace(CONFD_TRACE, "Received daemon id %d\n", did);
            return CONFD_OK;
        }
        erl_free_compound(term);
        confd_internal_error("Got bad data");
        return ret_err(CONFD_ERR_INTERNAL, "Got bad data\n");
    }
    else if (type == WORKER_SOCKET) {
        if ((worker = erl_format("{~i,~i,~i}", CONFD_PROTO_WORKER,
                                 dtx->daemon_id,sock)) == NULL) {
            ret_err(CONFD_ERR_MALLOC, "Failed to create datastruct\n");
        }
        if ((status = term_write(sock, worker, -1, -1)) < 0) {
            erl_free_compound(worker);
            return status;
        }
        erl_free_compound(worker);
        return CONFD_OK;
    }
    else {
        confd_trace(CONFD_DEBUG, "confd_connect() Bad type %d\n", type);
        return CONFD_ERR;
    }
}

int confd_register_usess_cb(struct confd_daemon_ctx *dx,
                            const struct confd_usess_cbs *ucb)
{
    CHECK_REG_OK(dx);
    memcpy(&dx->usess_cb, ucb, sizeof(struct confd_usess_cbs));
    return CONFD_OK;
}

int confd_register_trans_cb(struct confd_daemon_ctx *dx,
                            const struct confd_trans_cbs *scb)
{
    int ret;
    int mask = 0;
    ETERM *tup[3];
    ETERM *req;

    CHECK_REG_OK(dx);
    memcpy((void*)&dx->trans_cb, (void*)scb, sizeof(struct confd_trans_cbs));
    if (scb->init)
        mask |= MASK_TR_INIT;
    else
        return CONFD_ERR;
    if (scb->trans_lock) mask |= MASK_TR_TRANS_LOCK;
    if (scb->trans_unlock) mask |= MASK_TR_TRANS_UNLOCK;
    if (scb->write_start) mask |= MASK_TR_WRITE_START;
    if (scb->prepare) mask |= MASK_TR_PREPARE;
    if (scb->abort) mask |= MASK_TR_ABORT;;
    if (scb->commit) mask |= MASK_TR_COMMIT;
    if (scb->finish) mask |= MASK_TR_FINISH;
    if (scb->interrupt) mask |= MASK_TR_INTERRUPT;
    tup[0] = erl_mk_int(CONFD_TRANS_CB_REGISTER);
    tup[1] = erl_mk_int(dx->daemon_id);
    tup[2] = erl_mk_int(mask);
    req = erl_mk_tuple(tup, 3);
    ret = term_write(dx->ctl_sock, req, -1, -1);
    erl_free_compound(req);
    return ret;
}


void confd_register_trans_validate_cb(
    struct confd_daemon_ctx *dx,
    const struct confd_trans_validate_cbs *vcb)
{

    memcpy((void*)&dx->trans_validate_cb,
           (void*)vcb, sizeof(struct confd_trans_validate_cbs));
}



int confd_register_db_cb(struct confd_daemon_ctx *dx,
                         const struct confd_db_cbs *dbcbs)
{
    int ret;
    int mask = 0;
    ETERM *tup[3];
    ETERM *req;

    CHECK_REG_OK(dx);
    memcpy((void*)&dx->db_cb, (void*)dbcbs, sizeof(struct confd_db_cbs));
    if (dbcbs->candidate_commit) mask |= MASK_DB_CANDIDATE_COMMIT;
    if (dbcbs->candidate_confirming_commit)
        mask |= MASK_DB_CANDIDATE_CONFIRMING_COMMIT;
    if (dbcbs->candidate_reset) mask |= MASK_DB_CANDIDATE_RESET;
    if (dbcbs->candidate_chk_not_modified)
        mask |= MASK_DB_CANDIDATE_CHK_NOT_MODIFIED;
    if (dbcbs->candidate_rollback_running)
        mask |= MASK_DB_CANDIDATE_ROLLBACK_RUNNING;
    if (dbcbs->candidate_validate) mask |= MASK_DB_CANDIDATE_VALIDATE;
    if (dbcbs->add_checkpoint_running) mask |= MASK_DB_ADD_CHECKPOINT_RUNNING ;
    if (dbcbs->del_checkpoint_running) mask |= MASK_DB_DEL_CHECKPOINT_RUNNING ;
    if (dbcbs->activate_checkpoint_running)
        mask |= MASK_DB_ACTIVATE_CHECKPOINT_RUNNING;
    if (dbcbs->copy_running_to_startup) mask |= MASK_DB_COPY_RUNNING_TO_STARTUP;
    if (dbcbs->running_chk_not_modified)
        mask |= MASK_DB_RUNNING_CHK_NOT_MODIFIED;
    if (dbcbs->lock) mask |= MASK_DB_LOCK;
    if (dbcbs->unlock) mask |= MASK_DB_UNLOCK;
    if (dbcbs->delete_config) mask |= MASK_DB_DELETE_CONFIG;
    if (dbcbs->lock_partial) mask |= MASK_DB_LOCK_PARTIAL;
    if (dbcbs->unlock_partial) mask |= MASK_DB_UNLOCK_PARTIAL;
    tup[0] = erl_mk_int(CONFD_DB_CB_REGISTER);
    tup[1] = erl_mk_int(dx->daemon_id);
    tup[2] = erl_mk_int(mask);
    req = erl_mk_tuple(tup, 3);
    ret = term_write(dx->ctl_sock, req, -1, -1);
    erl_free_compound(req);
    return ret;
}


static int mkmask(const struct confd_data_cbs *data)
{
    int mask = 0;
    if (data->exists_optional)  mask |=  MASK_DATA_EXISTS_OPTIONAL;
    if (data->get_elem)         mask |=  MASK_DATA_GET_ELEM;
    if (data->get_next)         mask |=  MASK_DATA_GET_NEXT;
    if (data->set_elem)         mask |=  MASK_DATA_SET_ELEM;
    if (data->create)           mask |=  MASK_DATA_CREATE;
    if (data->remove)           mask |=  MASK_DATA_REMOVE;
    if (data->find_next)        mask |=  MASK_DATA_FIND_NEXT;
    if (data->num_instances)    mask |=  MASK_DATA_NUM_INSTANCES;
    if (data->get_object)       mask |=  MASK_DATA_GET_OBJECT;
    if (data->get_next_object)  mask |=  MASK_DATA_GET_NEXT_OBJECT;
    if (data->find_next_object) mask |=  MASK_DATA_FIND_NEXT_OBJECT;
    if (data->get_case)         mask |=  MASK_DATA_GET_CASE;
    if (data->set_case)         mask |=  MASK_DATA_SET_CASE;
    if (data->get_attrs)        mask |=  MASK_DATA_GET_ATTRS;
    if (data->set_attr)         mask |=  MASK_DATA_SET_ATTR;
    if (data->move_after)       mask |=  MASK_DATA_MOVE_AFTER;
    if (data->write_all)        mask |=  MASK_DATA_WRITE_ALL;
    if (data->flags &
        CONFD_DATA_WANT_FILTER) mask |=  MASK_DATA_WANT_FILTER;
    return mask;
}

int  confd_register_data_cb(struct confd_daemon_ctx *dx,
                            const struct confd_data_cbs *data)
{
    struct confd_data_cbs *new_data_cbs;
    ETERM *r;
    int ret;

    CHECK_REG_OK(dx);
    clr_confd_err();
    if (dx->num_data_cbs + 1 > dx->data_cbs_len) {
        if ((new_data_cbs = realloc(dx->data_cbs,
                                    (dx->data_cbs_len + CB_INCREMENT) *
                                    sizeof(struct confd_data_cbs))) == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
        }
        dx->data_cbs = new_data_cbs;
        dx->data_cbs_len += CB_INCREMENT;
    }
    memcpy(&dx->data_cbs[dx->num_data_cbs++], data,
           sizeof(struct confd_data_cbs));

    r = erl_format("{~i, ~i, {~i, ~a, ~i, ~i, ~i}}",
                   CONFD_PROTO_REGISTER,
                   dx->daemon_id,
                   CONFD_PROTO_DATA_CB,
                   data->callpoint,
                   mkmask(data),
                   dx->flags,
                   dx->num_data_cbs
        );
    if (r == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    ret = term_write(dx->ctl_sock, r, -1, -1);
    erl_free_compound(r);
    return ret;
}

int  confd_register_range_data_cb(struct confd_daemon_ctx *dx,
                                  const struct confd_data_cbs *data,
                                  const confd_value_t *lower,
                                  const confd_value_t *upper,
                                  int numkeys,
                                  const char *fmt, ...)
{
    struct confd_data_cbs *new_data_cbs;
    ETERM *r, *elower, *eupper;
    int i, j, ret;
    ETERM *epath;
    ETERM *tup1[3];
    ETERM *tup2[9];
    int isrel;
    va_list args;
    va_start(args,fmt);

    CHECK_REG_OK(dx);
    clr_confd_err();

    epath = parse_path(&isrel, fmt, args);
    va_end(args);
    if (epath == NULL || isrel) {
        confd_set_errno(CONFD_ERR_BADPATH);
        return CONFD_ERR;
    }

    if (dx->num_data_cbs + 1 > dx->data_cbs_len) {
        if ((new_data_cbs = realloc(dx->data_cbs,
                                    (dx->data_cbs_len + CB_INCREMENT) *
                                    sizeof(struct confd_data_cbs))) == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
        }
        dx->data_cbs = new_data_cbs;
        dx->data_cbs_len += CB_INCREMENT;
    }
    memcpy(&dx->data_cbs[dx->num_data_cbs++], data,
           sizeof(struct confd_data_cbs));

    if (lower == NULL && upper == NULL) {
        elower = erl_mk_empty_list();
        eupper = erl_mk_empty_list();
    } else {
        ETERM *el[numkeys], *eh[numkeys];
        for (i=0; i<numkeys; i++) {
            if ((el[i] = val_to_term(&lower[i])) == NULL)
                return CONFD_ERR;
            if ((eh[i] = val_to_term(&upper[i])) == NULL)
                return CONFD_ERR;
        }
        elower = erl_mk_tuple(el, numkeys);
        eupper = erl_mk_tuple(eh, numkeys);
    }

    i=0;

    tup2[i++] = erl_mk_int(CONFD_PROTO_DATA_CB);
    tup2[i++] = erl_mk_atom(data->callpoint);
    tup2[i++] = erl_mk_int(mkmask(data));
    tup2[i++] = erl_mk_int(dx->flags);  /* no ikp */
    tup2[i++] = erl_mk_int(dx->num_data_cbs);
    tup2[i++] = erl_mk_int(isrel);
    tup2[i++] = epath;
    tup2[i++] = elower;
    tup2[i++] = eupper;

    j=0;

    tup1[j++] = erl_mk_int(CONFD_PROTO_REGISTER_RANGE);
    tup1[j++] = erl_mk_int(dx->daemon_id);
    tup1[j++] = erl_mk_tuple(tup2, i);

    r = erl_mk_tuple(tup1, j);

    if (r == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    ret = term_write(dx->ctl_sock, r, -1, -1);
    erl_free_compound(r);
    return ret;
}


int ncs_register_service_cb(struct confd_daemon_ctx *dx,
                            const struct ncs_service_cbs *scb)
{
    struct ncs_service_cbs *new_service_cbs;
    int mask = 0;
    ETERM *r;
    int ret;

    CHECK_REG_OK(dx);
    clr_confd_err();
    if (scb->pre_modification != NULL)  mask |= MASK_SERVICE_PRE_MODIFICATION;
    if (scb->post_modification != NULL) mask |= MASK_SERVICE_POST_MODIFICATION;
    if (scb->pre_lock_create != NULL)   mask |= MASK_SERVICE_PRE_LOCK_CREATE;
    if (scb->create != NULL)            mask |= MASK_SERVICE_CREATE;

    if ((mask & (MASK_SERVICE_PRE_LOCK_CREATE|MASK_SERVICE_CREATE)) ==
        (MASK_SERVICE_PRE_LOCK_CREATE|MASK_SERVICE_CREATE)) {
        return ret_err(CONFD_ERR_PROTOUSAGE, "Cannot register both "
                       "pre_lock_create() and create() callbacks\n");
    }

    if (dx->num_service_cbs + 1 > dx->service_cbs_len) {
        if ((new_service_cbs =
             realloc(dx->service_cbs,
                     (dx->service_cbs_len + CB_INCREMENT) *
                     sizeof(struct ncs_service_cbs))) == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
        }
        dx->service_cbs = new_service_cbs;
        dx->service_cbs_len += CB_INCREMENT;
    }
    memcpy(&dx->service_cbs[dx->num_service_cbs++], scb,
           sizeof(struct ncs_service_cbs));

    r = erl_format("{~i, ~i, {~i, ~a, ~i, ~i, ~i}}",
                   CONFD_PROTO_REGISTER,
                   dx->daemon_id,
                   CONFD_PROTO_SERVICE_CB,
                   scb->servicepoint,
                   mask,
                   dx->flags,
                   dx->num_service_cbs
        );
    if (r == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    ret = term_write(dx->ctl_sock, r, -1, -1);
    erl_free_compound(r);
    return ret;
}

int ncs_register_nano_service_cb(struct confd_daemon_ctx *dx,
                                 const char *component_type,
                                 const char *state,
                                 const struct ncs_nano_service_cbs *nscb)
{
    struct ncs_nano_service_cbs *new_nano_service_cbs;
    int mask = 0;
    ETERM *r;
    int ret;

    CHECK_REG_OK(dx);
    clr_confd_err();
    if (nscb->nano_create != NULL)  mask |= MASK_NANO_SERVICE_CREATE;
    if (nscb->nano_delete != NULL)  mask |= MASK_NANO_SERVICE_DELETE;

    if (dx->num_nano_service_cbs + 1 > dx->nano_service_cbs_len) {
        if ((new_nano_service_cbs =
             realloc(dx->nano_service_cbs,
                     (dx->nano_service_cbs_len + CB_INCREMENT) *
                     sizeof(struct ncs_nano_service_cbs))) == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
        }
        dx->nano_service_cbs = new_nano_service_cbs;
        dx->nano_service_cbs_len += CB_INCREMENT;
    }
    memcpy(&dx->nano_service_cbs[dx->num_nano_service_cbs++], nscb,
           sizeof(struct ncs_nano_service_cbs));

    r = erl_format("{~i, ~i, {~i, {~a, ~w, ~w}, ~i, ~i, ~i}}",
                   CONFD_PROTO_REGISTER_NANO,
                   dx->daemon_id,
                   CONFD_PROTO_NANO_SERVICE_CB,
                   nscb->servicepoint,
                   erl_mk_binary(component_type, strlen(component_type)),
                   erl_mk_binary(state, strlen(state)),
                   mask,
                   dx->flags,
                   dx->num_nano_service_cbs
        );
    if (r == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    ret = term_write(dx->ctl_sock, r, -1, -1);
    erl_free_compound(r);
    return ret;
}


int confd_register_valpoint_cb(struct confd_daemon_ctx *dx,
                               const struct confd_valpoint_cb *vcb)
{
    struct confd_valpoint_cb *new_valp_cbs;
    ETERM *r;
    int ret;

    CHECK_REG_OK(dx);
    clr_confd_err();
    if (dx->num_validation_cbs + 1 > dx->valp_cbs_len) {
        if ((new_valp_cbs =
             realloc(dx->valp_cbs,
                     (dx->valp_cbs_len + CB_INCREMENT) *
                     sizeof(struct confd_valpoint_cb))) == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
        }
        dx->valp_cbs = new_valp_cbs;
        dx->valp_cbs_len += CB_INCREMENT;
    }
    memcpy(&dx->valp_cbs[dx->num_validation_cbs++], vcb,
           sizeof(struct confd_valpoint_cb));

    r = erl_format("{~i, ~i, {~i,~a, ~i, ~i, ~i}}",
                   CONFD_PROTO_REGISTER,
                   dx->daemon_id,
                   CONFD_PROTO_VALIDATE_CB,
                   vcb->valpoint, 0, dx->flags,
                   dx->num_validation_cbs
        );
    if (r == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    ret = term_write(dx->ctl_sock, r, -1, -1);
    erl_free_compound(r);
    return ret;
}

int  confd_register_range_valpoint_cb(struct confd_daemon_ctx *dx,
                                      struct confd_valpoint_cb *vcb,
                                      const confd_value_t *lower,
                                      const confd_value_t *upper,
                                      int numkeys,
                                      const char *fmt, ...)
{
    struct confd_valpoint_cb *new_valp_cbs;
    ETERM *r, *elower, *eupper;
    int i, j, ret;
    ETERM *epath;
    ETERM *tup1[3];
    ETERM *tup2[9];
    int isrel;
    va_list args;

    CHECK_REG_OK(dx);
    clr_confd_err();

    va_start(args,fmt);
    epath = parse_path(&isrel, fmt, args);
    va_end(args);
    if (epath == NULL || isrel) {
        confd_set_errno(CONFD_ERR_BADPATH);
        return CONFD_ERR;
    }

    if (dx->num_validation_cbs + 1 > dx->valp_cbs_len) {
        if ((new_valp_cbs =
             realloc(dx->valp_cbs,
                     (dx->valp_cbs_len + CB_INCREMENT) *
                     sizeof(struct confd_valpoint_cb))) == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
        }
        dx->valp_cbs = new_valp_cbs;
        dx->valp_cbs_len += CB_INCREMENT;
    }
    memcpy(&dx->valp_cbs[dx->num_validation_cbs++], vcb,
           sizeof(struct confd_valpoint_cb));

    if (lower == NULL && upper == NULL) {
        elower = erl_mk_empty_list();
        eupper = erl_mk_empty_list();
    } else {
        ETERM *el[numkeys], *eh[numkeys];
        for (i=0; i<numkeys; i++) {
            if ((el[i] = val_to_term(&lower[i])) == NULL)
                return CONFD_ERR;
            if ((eh[i] = val_to_term(&upper[i])) == NULL)
                return CONFD_ERR;
        }
        elower = erl_mk_tuple(el, numkeys);
        eupper = erl_mk_tuple(eh, numkeys);
    }

    i=0;
    tup2[i++] = erl_mk_int(CONFD_PROTO_VALIDATE_CB);
    tup2[i++] = erl_mk_atom(vcb->valpoint);
    tup2[i++] = erl_mk_int(0);
    tup2[i++] = erl_mk_int(dx->flags);
    tup2[i++] = erl_mk_int(dx->num_validation_cbs);
    tup2[i++] = erl_mk_int(isrel);
    tup2[i++] = epath;
    tup2[i++] = elower;
    tup2[i++] = eupper;

    j=0;
    tup1[j++] = erl_mk_int(CONFD_PROTO_REGISTER_RANGE);
    tup1[j++] = erl_mk_int(dx->daemon_id);
    tup1[j++] = erl_mk_tuple(tup2, i);

    r = erl_mk_tuple(tup1, j);
    if (r == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    ret = term_write(dx->ctl_sock, r, -1, -1);
    erl_free_compound(r);
    return ret;
}

static int mkmask_act(const struct confd_action_cbs *acb)
{
    int mask = 0;
    if (acb->init != NULL)       mask |= MASK_ACT_INIT;
    if (acb->action != NULL)     mask |= MASK_ACT_ACTION;
    if (acb->command != NULL)    mask |= MASK_ACT_COMMAND;
    if (acb->completion != NULL) mask |= MASK_ACT_COMPLETION;
    if (acb->abort != NULL)      mask |= MASK_ACT_ABORT;
    return mask;
}

int confd_register_action_cbs(struct confd_daemon_ctx *dx,
                              const struct confd_action_cbs *acb)
{
    struct confd_action_cbs *new_action_cbs;
    ETERM *r;
    int mask;
    int ret;

    CHECK_REG_OK(dx);
    clr_confd_err();
    mask = mkmask_act(acb);
    if ((mask & MASK_ACT_INIT) == 0) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Must always have init() callback\n");
    }
    if ((mask & (MASK_ACT_ACTION|MASK_ACT_COMMAND|MASK_ACT_COMPLETION)) == 0) {
        return ret_err(CONFD_ERR_PROTOUSAGE, "Must have at least one of "
                       "action(), command(), and completion() callbacks\n");
    }
    if (dx->num_action_cbs + 1 > dx->action_cbs_len) {
        if ((new_action_cbs =
             realloc(dx->action_cbs,
                     (dx->action_cbs_len + CB_INCREMENT) *
                     sizeof(struct confd_action_cbs))) == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
        }
        dx->action_cbs = new_action_cbs;
        dx->action_cbs_len += CB_INCREMENT;
    }
    memcpy(&dx->action_cbs[dx->num_action_cbs++], acb,
           sizeof(struct confd_action_cbs));

    r = erl_format("{~i, ~i, {~i,~a, ~i, ~i, ~i}}",
                   CONFD_PROTO_REGISTER,
                   dx->daemon_id,
                   CONFD_PROTO_ACTION_CB,
                   acb->actionpoint, mask, dx->flags,
                   dx->num_action_cbs
        );
    if (r == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    ret = term_write(dx->ctl_sock, r, -1, -1);
    erl_free_compound(r);
    return ret;
}

int confd_register_range_action_cbs(struct confd_daemon_ctx *dx,
                                    const struct confd_action_cbs *acb,
                                    const confd_value_t *lower,
                                    const confd_value_t *upper,
                                    int numkeys, const char *fmt, ...)
{
    int mask;
    struct confd_action_cbs *new_action_cbs;
    ETERM *r, *elower, *eupper;
    int i, j, ret;
    ETERM *epath;
    ETERM *tup1[3];
    ETERM *tup2[9];
    int isrel;
    va_list args;

    CHECK_REG_OK(dx);
    clr_confd_err();
    mask = mkmask_act(acb);
    if ((mask & MASK_ACT_INIT) == 0) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Must always have init() callback\n");
    }
    if ((mask & (MASK_ACT_ACTION|MASK_ACT_COMMAND|MASK_ACT_COMPLETION))
        != MASK_ACT_ACTION) {
        return ret_err(CONFD_ERR_PROTOUSAGE, "Range registration must have "
                       "action() and not command() or completion() callback\n");
    }

    va_start(args,fmt);
    epath = parse_path(&isrel, fmt, args);
    va_end(args);
    if (epath == NULL || isrel) {
        confd_set_errno(CONFD_ERR_BADPATH);
        return CONFD_ERR;
    }

    if (dx->num_action_cbs + 1 > dx->action_cbs_len) {
        if ((new_action_cbs =
             realloc(dx->action_cbs,
                     (dx->action_cbs_len + CB_INCREMENT) *
                     sizeof(struct confd_action_cbs))) == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
        }
        dx->action_cbs = new_action_cbs;
        dx->action_cbs_len += CB_INCREMENT;
    }
    memcpy(&dx->action_cbs[dx->num_action_cbs++], acb,
           sizeof(struct confd_action_cbs));

    if (lower == NULL && upper == NULL) {
        elower = erl_mk_empty_list();
        eupper = erl_mk_empty_list();
    } else {
        ETERM *el[numkeys], *eh[numkeys];
        for (i=0; i<numkeys; i++) {
            if ((el[i] = val_to_term(&lower[i])) == NULL)
                return CONFD_ERR;
            if ((eh[i] = val_to_term(&upper[i])) == NULL)
                return CONFD_ERR;
        }
        elower = erl_mk_tuple(el, numkeys);
        eupper = erl_mk_tuple(eh, numkeys);
    }

    i=0;

    tup2[i++] = erl_mk_int(CONFD_PROTO_ACTION_CB);
    tup2[i++] = erl_mk_atom(acb->actionpoint);
    tup2[i++] = erl_mk_int(mask);
    tup2[i++] = erl_mk_int(dx->flags);
    tup2[i++] = erl_mk_int(dx->num_action_cbs);
    tup2[i++] = erl_mk_int(isrel);
    tup2[i++] = epath;
    tup2[i++] = elower;
    tup2[i++] = eupper;

    j=0;

    tup1[j++] = erl_mk_int(CONFD_PROTO_REGISTER_RANGE);
    tup1[j++] = erl_mk_int(dx->daemon_id);
    tup1[j++] = erl_mk_tuple(tup2, i);

    r = erl_mk_tuple(tup1, j);

    if (r == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    ret = term_write(dx->ctl_sock, r, -1, -1);
    erl_free_compound(r);
    return ret;
}


static void clear_error(struct confd_error *error);

static struct confd_notification_ctx *alloc_notification_ctx(
    struct confd_daemon_ctx *dx)
{
    struct confd_notification_ctx **new_notif_ctxs;
    struct confd_notification_ctx *new_notif_ctx;

    if (dx->num_notif_ctxs + 1 > dx->notif_ctxs_len) {
        if ((new_notif_ctxs =
             realloc(dx->notif_ctxs,
                     (dx->notif_ctxs_len + CB_INCREMENT) *
                     sizeof(struct confd_notification_ctx *))) == NULL) {
            ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
            return NULL;
        }
        dx->notif_ctxs = new_notif_ctxs;
        dx->notif_ctxs_len += CB_INCREMENT;
    }
    if ((new_notif_ctx =
         confd_malloc(sizeof(struct confd_notification_ctx))) == NULL)
        return NULL;
    memset(new_notif_ctx, 0, sizeof(struct confd_notification_ctx));
    dx->notif_ctxs[dx->num_notif_ctxs++] = new_notif_ctx;
    return new_notif_ctx;
}

static void dealloc_notification_ctx(struct confd_daemon_ctx *dx,
                                     struct confd_notification_ctx *nctx)
{
    int i = dx->num_notif_ctxs;

    while (i > 0 && dx->notif_ctxs[i-1] != nctx) {
        i--;
    }
    if (i > 0) {
        dx->notif_ctxs[i-1] = NULL;
        if (i == dx->num_notif_ctxs) {
            /* can only reuse if last */
            dx->num_notif_ctxs--;
        }
    }
    free(nctx);
}

/* mask used to tell capi_server which cbs we have installed */
#define NOTIF_MASK_GET_LOG_TIMES   (1 << 0)
#define NOTIF_MASK_REPLAY          (1 << 1)

int confd_register_notification_stream(
    struct confd_daemon_ctx *dx,
    const struct confd_notification_stream_cbs *ncbs,
    struct confd_notification_ctx **nctx)
{
    struct confd_notification_ctx *new_nctx;
    struct confd_notification_stream_cbs *new_notif_cbs;
    ETERM *r;
    int mask;
    int ret;

    CHECK_REG_OK(dx);
    clr_confd_err();
    if ((ncbs->get_log_times == NULL && ncbs->replay != NULL) ||
        (ncbs->get_log_times != NULL && ncbs->replay == NULL)) {
        ret_err(CONFD_ERR_PROTOUSAGE, "Must have neither or both callbacks\n");
        return CONFD_ERR;
    }
    if ((new_nctx = alloc_notification_ctx(dx)) == NULL) {
        return CONFD_ERR;
    }
    if (dx->num_notif_cbs + 1 > dx->notif_cbs_len) {
        if ((new_notif_cbs =
             realloc(dx->notif_cbs,
                     (dx->notif_cbs_len + CB_INCREMENT) *
                     sizeof(struct confd_notification_stream_cbs))) == NULL) {
            dealloc_notification_ctx(dx, new_nctx);
            return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
        }
        dx->notif_cbs = new_notif_cbs;
        dx->notif_cbs_len += CB_INCREMENT;
    }
    if (ncbs->get_log_times == NULL)
        mask = 0;
    else
        mask = NOTIF_MASK_GET_LOG_TIMES | NOTIF_MASK_REPLAY;
    memcpy(&dx->notif_cbs[dx->num_notif_cbs++], ncbs,
           sizeof(struct confd_notification_stream_cbs));

    r = erl_format("{~i, ~i, {~i,~a, ~i, ~i, ~i}}",
                   CONFD_PROTO_REGISTER,
                   dx->daemon_id,
                   CONFD_PROTO_NOTIF_STREAM_CB,
                   ncbs->streamname, mask, dx->flags,
                   dx->num_notif_cbs
        );
    if (r == NULL) {
        dealloc_notification_ctx(dx, new_nctx);
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    ret = term_write(dx->ctl_sock, r, -1, -1);
    erl_free_compound(r);
    if (ret != CONFD_OK) {
        dealloc_notification_ctx(dx, new_nctx);
        return ret;
    }
    clear_error(&new_nctx->error);
    if ((new_nctx->name =
         strdup(dx->notif_cbs[dx->num_notif_cbs-1].streamname)) == NULL) {
        dealloc_notification_ctx(dx, new_nctx);
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate stream name\n");
    }
    new_nctx->ctx_name = NULL;
    new_nctx->fd = new_nctx->live_fd = dx->notif_cbs[dx->num_notif_cbs-1].fd;
    new_nctx->dx = dx;
    new_nctx->cb_opaque = dx->notif_cbs[dx->num_notif_cbs-1].cb_opaque;
    new_nctx->subid = 0;
    new_nctx->flags = dx->flags;
    new_nctx->src_addr.af = AF_UNSPEC;
    *nctx = new_nctx;
    return CONFD_OK;
}

int confd_register_snmp_notification(
    struct confd_daemon_ctx *dx, int fd,
    const char *notify_name, const char *ctx_name,
    struct confd_notification_ctx **nctx)
{
    struct confd_notification_ctx *new_nctx;

    CHECK_REG_OK(dx);
    clr_confd_err();
    if ((new_nctx = alloc_notification_ctx(dx)) == NULL) {
        return CONFD_ERR;
    }
    clear_error(&new_nctx->error);
    if (notify_name == NULL)
        new_nctx->name = strdup("");
    else
        new_nctx->name = strdup(notify_name);
    if (new_nctx->name == NULL) {
        dealloc_notification_ctx(dx, new_nctx);
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    if (ctx_name == NULL)
        new_nctx->ctx_name = strdup("");
    else
        new_nctx->ctx_name = strdup(ctx_name);
    if (new_nctx->ctx_name == NULL) {
        free(new_nctx->name);
        dealloc_notification_ctx(dx, new_nctx);
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    new_nctx->fd = fd;
    new_nctx->dx = dx;
    new_nctx->flags = dx->flags;
    new_nctx->src_addr.af = AF_UNSPEC;
    *nctx = new_nctx;
    return CONFD_OK;
}

int confd_register_notification_snmp_inform_cb(
    struct confd_daemon_ctx *dx,
    const struct confd_notification_snmp_inform_cbs *cb)
{
    struct confd_notification_snmp_inform_cbs *new_notif_snmp_inform_cbs;
    ETERM *r;
    int mask = 0;
    int ret;

    CHECK_REG_OK(dx);
    clr_confd_err();
    if (dx->num_notif_snmp_inform_cbs + 1 > dx->notif_snmp_inform_cbs_len) {
        if ((new_notif_snmp_inform_cbs =
             realloc(dx->notif_snmp_inform_cbs,
                     (dx->notif_snmp_inform_cbs_len + CB_INCREMENT) *
                     sizeof(struct confd_notification_snmp_inform_cbs))) ==
            NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
        }
        dx->notif_snmp_inform_cbs = new_notif_snmp_inform_cbs;
        dx->notif_snmp_inform_cbs_len += CB_INCREMENT;
    }
    if (cb->targets != NULL) mask |= MASK_NOTIF_SNMP_INFORM_TARGETS;
    if (cb->result != NULL) mask |= MASK_NOTIF_SNMP_INFORM_RESULT;
    memcpy(&dx->notif_snmp_inform_cbs[dx->num_notif_snmp_inform_cbs++], cb,
           sizeof(struct confd_notification_snmp_inform_cbs));

    r = erl_format("{~i, ~i, {~i,~a, ~i, ~i, ~i}}",
                   CONFD_PROTO_REGISTER,
                   dx->daemon_id,
                   CONFD_PROTO_NOTIF_SNMP_INFORM_CB,
                   cb->cb_id, mask, dx->flags,
                   dx->num_notif_snmp_inform_cbs
        );
    if (r == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    ret = term_write(dx->ctl_sock, r, -1, -1);
    erl_free_compound(r);
    return ret;
}

int confd_register_notification_sub_snmp_cb(
    struct confd_daemon_ctx *dx,
    const struct confd_notification_sub_snmp_cb *cb)
{
    struct confd_notification_sub_snmp_cb *new_notif_sub_snmp_cbs;
    ETERM *r;
    int ret;

    CHECK_REG_OK(dx);
    clr_confd_err();
    if (dx->num_notif_sub_snmp_cbs + 1 > dx->notif_sub_snmp_cbs_len) {
        if ((new_notif_sub_snmp_cbs =
             realloc(dx->notif_sub_snmp_cbs,
                     (dx->notif_sub_snmp_cbs_len + CB_INCREMENT) *
                     sizeof(struct confd_notification_sub_snmp_cb))) == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
        }
        dx->notif_sub_snmp_cbs = new_notif_sub_snmp_cbs;
        dx->notif_sub_snmp_cbs_len += CB_INCREMENT;
    }
    memcpy(&dx->notif_sub_snmp_cbs[dx->num_notif_sub_snmp_cbs++], cb,
           sizeof(struct confd_notification_sub_snmp_cb));

    r = erl_format("{~i, ~i, {~i,~a, ~i, ~i, ~i}}",
                   CONFD_PROTO_REGISTER,
                   dx->daemon_id,
                   CONFD_PROTO_NOTIF_SUB_SNMP_CB,
                   cb->sub_id, 0, dx->flags,
                   dx->num_notif_sub_snmp_cbs
        );
    if (r == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    }
    ret = term_write(dx->ctl_sock, r, -1, -1);
    erl_free_compound(r);
    return ret;
}

int confd_register_auth_cb(struct confd_daemon_ctx *dx,
                           const struct confd_auth_cb *acb)
{
    ETERM *r;
    int ret = CONFD_OK;

    CHECK_REG_OK(dx);
    memcpy(&dx->auth_cb, acb, sizeof(dx->auth_cb));
    r = erl_format("{~i, ~i, {~i, ~a, ~i, ~i, ~i}}",
                   CONFD_PROTO_REGISTER,
                   dx->daemon_id,
                   CONFD_PROTO_AUTH_CB,
                   "auth", 0, dx->flags, 0
        );
    if (r == NULL) {
        ret = ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    } else {
        ret = term_write(dx->ctl_sock, r, -1, -1);
        erl_free_compound(r);
    }
    return ret;
}

int confd_register_authorization_cb(struct confd_daemon_ctx *dx,
                                    const struct confd_authorization_cbs *acb)
{
    ETERM *r;
    int mask = 0;
    int ret = CONFD_OK;

    CHECK_REG_OK(dx);
    if (acb->chk_cmd_access != NULL) mask |= MASK_CHK_CMD_ACCESS;
    if (acb->chk_data_access != NULL) mask |= MASK_CHK_DATA_ACCESS;
    memcpy(&dx->authorization_cbs, acb, sizeof(dx->authorization_cbs));
    r = erl_format("{~i, ~i, {~i, ~a, {~i, ~i, ~i}, ~i, ~i}}",
                   CONFD_PROTO_REGISTER,
                   dx->daemon_id,
                   CONFD_PROTO_AUTHORIZATION_CB,
                   "auth", mask, acb->cmd_filter, acb->data_filter,
                   dx->flags, 0
        );
    if (r == NULL) {
        ret = ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    } else {
        ret = term_write(dx->ctl_sock, r, -1, -1);
        erl_free_compound(r);
    }
    return ret;
}

int confd_register_error_cb(struct confd_daemon_ctx *dx,
                            const struct confd_error_cb *ecb)
{
    int mask, types;
    ETERM *r;
    int ret = CONFD_OK;

    CHECK_REG_OK(dx);
    if (dx->error_cb.format_error != NULL)
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Only one error callback registration allowed\n");
    if (ecb->error_types == 0 || ecb->format_error == NULL)
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Missing error types or callback\n");
    memcpy(&dx->error_cb, ecb, sizeof(dx->error_cb));
    /* do a separate registration for each error type,
       using the type bit as "callpoint"  */
    for (mask = 1, types = ecb->error_types;
         ret == CONFD_OK && types != 0; mask <<= 1, types >>= 1) {
        if (types & 1) {
            r = erl_format("{~i, ~i, {~i, ~i, ~i, ~i, ~i}}",
                           CONFD_PROTO_REGISTER,
                           dx->daemon_id,
                           CONFD_PROTO_ERROR_CB,
                           mask, 0, dx->flags, 0
                );
            if (r == NULL) {
                ret = ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
            } else {
                ret = term_write(dx->ctl_sock, r, -1, -1);
                erl_free_compound(r);
            }
        }
    }
    return ret;
}

int confd_register_done(struct confd_daemon_ctx *dx)
{
    ETERM *tup[2];
    ETERM *req, *reply;
    int status;
    ETERM *hd, *tl;

    CHECK_REG_OK(dx);
    if (dx->num_data_cbs > 0 && dx->trans_cb.init == NULL) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Must register transaction init() callback "
                       "when data callbacks are registered");
    }
    if (dx->num_validation_cbs > 0 && dx->trans_validate_cb.init == NULL) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Must register validation init() callback "
                       "when validation point callbacks are registered");
    }
    tup[0] = erl_mk_int(CONFD_PROTO_REGISTER_DONE);
    tup[1] = erl_mk_int(dx->daemon_id);
    req = erl_mk_tuple(tup, 2);
    reply = confd_call(dx->ctl_sock, req, &status);
    erl_free_compound(req);
    if (reply == NULL)
        return status;
    if (ERL_IS_TUPLE(reply) && (ERL_TUPLE_SIZE(reply) == 2) &&
        TUINT(reply, 0) == CONFD_PROTO_OLD_USESS) {
        tl = ERL_TUPLE_ELEMENT(reply, 1);
        while (status == CONFD_OK && ! ERL_IS_EMPTY_LIST(tl)) {
            struct confd_user_info *uinfo;

            hd = ERL_CONS_HEAD(tl);
            tl = ERL_CONS_TAIL(tl);
            uinfo = add_user_session(dx, hd, 0, NULL);
            if (uinfo == NULL) {
                status = ret_err(CONFD_ERR_MALLOC, "Failed to mk uinfo");
            } else {
                if (dx->usess_cb.start != NULL)
                    dx->usess_cb.start(dx, uinfo);
            }
        }
    } else {
        confd_internal_error("Got bad data");
        status = ret_err(CONFD_ERR_INTERNAL, "Got bad data\n");
    }
    erl_free_compound(reply);
    dx->flags |= CONFD_DAEMON_FLAG_REG_DONE;
    return status;
}

static void clear_error(struct confd_error *error)
{
    error->code = CONFD_ERRCODE_APPLICATION;
    error->apptag.ns = 0;
    error->apptag.tag = 0;
    error->str = NULL;
    error->info = NULL;
}

static void free_error(struct confd_error *error)
{
    if (error->str != NULL)
        free(error->str);
    if (error->info != NULL)
        erl_free_compound(error->info);
    clear_error(error);
}

int _confd_vset_error(struct confd_error *error, enum confd_errcode code,
                      u_int32_t apptag_ns, u_int32_t apptag_tag,
                      const confd_tag_value_t *error_info, int n, int flags,
                      const char *fmt, va_list args)
{
    ETERM *tup[2], *ei[2];
    char buf[BUFSIZ];

    free_error(error);
    if (n > 0) {
        if ((tup[1] = tag_vals_to_termlist(error_info, n, 0)) == NULL) {
            return CONFD_ERR;
        }
        tup[0] = erl_mk_atom("hxml");
        ei[0] = erl_mk_tuple(tup, 2);
        ei[1] = erl_mk_int(flags);
        error->info = erl_mk_tuple(ei, 2);
    }
    error->code = code;
    error->apptag.ns = apptag_ns;
    error->apptag.tag = apptag_tag;
    if (fmt != NULL) {
        vsnprintf(buf, sizeof(buf), fmt, args);
        if (buf[0] != '\0')
            if ((error->str = strdup(buf)) == NULL) {
                erl_free_compound(error->info);
                return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
            }
    }
    return CONFD_OK;
}

static void set_error(struct confd_error *error, enum confd_errcode code,
                      u_int32_t apptag_ns, u_int32_t apptag_tag,
                      const char *fmt, ...)
{
    SETERR_EXTENDED(error);
}

ETERM *_confd_make_error(struct confd_error *error)
{
    ETERM *pair[2];
    ETERM *tup[4];
    int n;

    switch (error->code) {
    case CONFD_ERRCODE_IN_USE:
        tup[0] = erl_mk_atom("in_use"); break;
    case CONFD_ERRCODE_RESOURCE_DENIED:
        tup[0] = erl_mk_atom("resource_denied"); break;
    case CONFD_ERRCODE_INCONSISTENT_VALUE:
        tup[0] = erl_mk_atom("inconsistent_value"); break;
    case CONFD_ERRCODE_ACCESS_DENIED:
        tup[0] = erl_mk_atom("access_denied"); break;
    case CONFD_ERRCODE_APPLICATION:
        tup[0] = erl_mk_atom("application"); break;
    case CONFD_ERRCODE_APPLICATION_INTERNAL:
        tup[0] = erl_mk_atom("application_internal"); break;
    case CONFD_ERRCODE_PROTO_USAGE:
        tup[0] = erl_mk_atom("proto_usage"); break;
    case CONFD_ERRCODE_INTERNAL:
        tup[0] = erl_mk_atom("internal"); break;
    case CONFD_ERRCODE_DATA_MISSING:
        tup[0] = erl_mk_atom("data_missing"); break;
    case CONFD_ERRCODE_INTERRUPT:
        tup[0] = erl_mk_atom("interrupt"); break;
    default:
        tup[0] = erl_mk_atom("undefined"); break;
    }
    if (error->apptag.tag != 0) {
        pair[0] = erl_mk_uint(error->apptag.ns);
        pair[1] = erl_mk_uint(error->apptag.tag);
        tup[1] = erl_cons(pair[0], pair[1]);
    } else {
        tup[1] = erl_mk_atom("undefined");
    }
    if (error->str != NULL)
        tup[2] = erl_mk_binary(error->str, strlen(error->str));
    else
        tup[2] = erl_mk_atom("undefined");
    if (error->info != NULL) {
        tup[3] = error->info;
        error->info = NULL;
        n = 4;
    } else {
        n = 3;
    }
    free_error(error);
    return erl_mk_tuple(tup, n);
}

static int trans_reply_callback(struct confd_trans_ctx *tctx, ETERM *reply)
{
    ETERM *tup;
    ETERM *a[4];
    int ret;

    SET_SEEN_REPLY(tctx);
    /* Construct reply tuple */
    a[0] = erl_mk_int(CONFD_PROTO_CALLBACK);
    a[1] = erl_mk_int(tctx->query_ref);
    a[2] = erl_mk_int(tctx->dx->daemon_id);
    a[3] = reply;
    tup = erl_mk_tuple(a, 4);
    free_error(&tctx->error);
    ret = term_write(tctx->fd, tup, -1, -1);
    erl_free_compound(tup);
    return ret;
}

static int reply_error(int fd, int op, int qref, int did,
                       struct confd_error *error)
{
    ETERM *a[5];
    ETERM *tup;
    int twret;

    a[0] = erl_mk_int(op);
    a[1] = erl_mk_int(qref);
    a[2] = erl_mk_int(did);
    a[3] = erl_mk_atom("error");
    a[4] = _confd_make_error(error);
    if ((tup = erl_mk_tuple(a, 5)) == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
    }
    twret = term_write(fd, tup, -1, -1);
    erl_free_compound(tup);
    return twret;
}


/* assumes error info (if any) already set in tctx */
static int trans_reply_error(struct confd_trans_ctx *tctx)
{
    int fd;

    SET_SEEN_REPLY(tctx);
    if (tctx->lastop == CONFD_PROTO_NEW_TRANS ||
        tctx->lastop == CONFD_PROTO_NEW_VALIDATE)
        fd = tctx->dx->ctl_sock;
    else if ((tctx->lastop == CONFD_PROTO_CALLBACK &&
              tctx->last_proto_op == CONFD_VALIDATE_VALUE) ||
             tctx->lastop == CONFD_PROTO_CLOSE_VALIDATE)
        fd = tctx->vfd;
    else
        fd = tctx->fd;
    return reply_error(fd, tctx->lastop, tctx->query_ref,
                       tctx->dx->daemon_id, &tctx->error);
}

static int trans_reply_error_extended(struct confd_trans_ctx *tctx,
                                      enum confd_errcode code,
                                      u_int32_t apptag_ns, u_int32_t apptag_tag,
                                      const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    _confd_vset_error(&tctx->error, code, apptag_ns, apptag_tag,
                      NULL, 0, 0, fmt, args);
    va_end(args);
    return trans_reply_error(tctx);
}

static int trans_reply_warning(struct confd_trans_ctx *tctx)
{
    ETERM *tup;
    ETERM *a[5];
    ETERM *retpair[2];
    int wfd = (tctx->last_proto_op == CONFD_VALIDATE_VALUE ?
               tctx->vfd : tctx->fd);
    int ret;

    a[0] = erl_mk_int(CONFD_PROTO_CALLBACK);
    a[1] = erl_mk_int(tctx->query_ref);
    a[2] = erl_mk_int(tctx->dx->daemon_id);
    retpair[0] = erl_mk_atom("warning");
    if (tctx->error.str == NULL)
        retpair[1] = erl_mk_binary("", 0);
    else
        retpair[1] = erl_mk_binary(tctx->error.str, strlen(tctx->error.str));
    a[3] = erl_mk_tuple(retpair, 2);
    tup = erl_mk_tuple(a, 4);
    free_error(&tctx->error);
    ret = term_write(wfd, tup, -1, -1);
    erl_free_compound(tup);
    return ret;
}

static int i_trans_reply_ok(struct confd_trans_ctx *tctx)
{
    ETERM *r;
    ETERM *arr[5];
    int wfd;
    int ret;

    if (tctx->lastop == CONFD_PROTO_NEW_TRANS ||
        tctx->lastop == CONFD_PROTO_NEW_VALIDATE) {
        if (tctx->lastop == CONFD_PROTO_NEW_VALIDATE)
            wfd = tctx->vfd;
        else
            wfd = tctx->fd;
        if (wfd == -1) {
            /* They forgot to do set_fd, so it's an error */
            // proto err
            trans_reply_error_extended(tctx, CONFD_ERRCODE_PROTO_USAGE, 0, 0,
                                       "No file descriptor set for trans");
            return ret_err(CONFD_ERR_PROTOUSAGE, "No descriptor set for trans");
        }
        arr[0] = erl_mk_int(tctx->lastop);
        arr[1] = erl_mk_int(tctx->query_ref);
        arr[2] = erl_mk_int(tctx->dx->daemon_id);
        arr[3] = erl_mk_int(tctx->thandle);
        arr[4] = erl_mk_int(wfd);
        r = erl_mk_tuple(arr, 5);
        if (r == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
        }
        tctx->lastop = CONFD_TRANS_REPLY_OK;
        ret = term_write(tctx->dx->ctl_sock, r, -1, -1);
        erl_free_compound(r);
        return ret;
    }
    else {
        if (tctx->lastop == CONFD_PROTO_CLOSE_VALIDATE)
            wfd = tctx->vfd;
        else
            wfd = tctx->fd;
        arr[0] = erl_mk_int(tctx->lastop);
        arr[1] = erl_mk_int(tctx->query_ref);
        arr[2] = erl_mk_int(tctx->dx->daemon_id);
        arr[3] = erl_mk_int(tctx->thandle);
        r = erl_mk_tuple(arr, 4);
        if (r == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
        }
        tctx->lastop = CONFD_TRANS_REPLY_OK;
        ret = term_write(wfd, r, -1, -1);
        erl_free_compound(r);
        return ret;
    }
}

static int trans_reply(struct confd_trans_ctx *tctx, int retval)
{
    int r = retval;
    int retval_ok = 0;

    if (confd_debug_level >= CONFD_TRACE) {
        switch (retval) {
        case CONFD_OK:
            confd_trace_printf(" --> CONFD_OK\n");
            break;
        case CONFD_ERR:
            confd_trace_printf(" --> CONFD_ERR\n");
            break;
        case CONFD_ALREADY_LOCKED:
            confd_trace_printf(" --> CONFD_ALREADY_LOCKED\n");
            break;
        case CONFD_IN_USE:
            confd_trace_printf(" --> CONFD_IN_USE\n");
            break;
        case CONFD_DELAYED_RESPONSE:
            confd_trace_printf(" --> CONFD_DELAYED_RESPONSE\n");
            break;
        default:
            confd_trace_printf(" --> BADRETVAL\n");
        }
    }

    switch (retval) {
    case CONFD_OK:
        r = i_trans_reply_ok(tctx);
        retval_ok++;
        break;
    case CONFD_ERR:
        confd_set_errno(CONFD_ERR_EXTERNAL);
        trans_reply_error(tctx);
        retval_ok++;
        break;
    case CONFD_ALREADY_LOCKED:
        if (tctx->lastop == CONFD_PROTO_TRANS_LOCK) {
            trans_reply_error_extended(tctx, CONFD_ERRCODE_IN_USE, 0, 0, NULL);
            retval_ok++;
        }
        break;
    case CONFD_IN_USE:
        if (tctx->lastop == CONFD_PROTO_WRITE_START ||
            tctx->lastop == CONFD_PROTO_PREPARE) {
            trans_reply_error_extended(tctx, CONFD_ERRCODE_IN_USE, 0, 0, NULL);
            retval_ok++;
        }
        break;
    case CONFD_DELAYED_RESPONSE:
        retval_ok++;
        break;
    }
    if (!retval_ok) {
        r = ret_err(CONFD_ERR_PROTOUSAGE,
                    "Bad application return value: %d thandle=%d\n",
                    retval, tctx->thandle);
        trans_reply_error_extended(tctx, CONFD_ERRCODE_PROTO_USAGE, 0, 0,
                                   "bad application retval");
    }
    return r;
}

static int async_ctl_reply(struct confd_daemon_ctx *dx, int op, int qref)
{
    ETERM *tup;
    ETERM *arr[3];
    int twret;

    arr[0] = erl_mk_int(op);
    arr[1] = erl_mk_int(qref);
    arr[2] = erl_mk_int(dx->daemon_id);
    tup = erl_mk_tuple(arr, 3);
    if (tup == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
    }
    twret = term_write(dx->ctl_sock, tup, -1, -1);
    erl_free_compound(tup);
    return twret;
}


static int action_reply_error(struct confd_action_ctx *actx)
{
    int fd;
    int op;
    int qref = actx->query_ref;
    int did = actx->dx->daemon_id;
    struct confd_error error;

    if (actx->last_op == CONFD_PROTO_NEW_ACTION) {
        fd = actx->dx->ctl_sock;
        op = CONFD_PROTO_NEW_ACTION;
    } else {
        fd = actx->fd;
        op = CONFD_PROTO_CALLBACK;
    }
    error = actx->error;
    clear_error(&actx->error);
    actx->state = ACT_STATE_NONE;
    return reply_error(fd, op, qref, did, &error);
}

/* we mustn't write in the uinfo struct in this case */
static int action_reply_busy(int fd, int op, int qref, int did, char *fmt, ...)
{
    struct confd_error error;
    va_list args;

    clear_error(&error);
    va_start(args, fmt);
    _confd_vset_error(&error, CONFD_ERRCODE_RESOURCE_DENIED, 0, 0,
                      NULL, 0, 0, fmt, args);
    va_end(args);
    return reply_error(fd, op, qref, did, &error);
}

static int new_action_reply(struct confd_user_info *uinfo, int retval)
{
    struct confd_action_ctx *actx = &uinfo->actx;
    int fd = actx->dx->ctl_sock;
    int qref = actx->query_ref;
    int did = actx->dx->daemon_id;
    ETERM *tup;
    ETERM *a[5];

    if (confd_debug_level >= CONFD_TRACE) {
        switch (retval) {
        case CONFD_OK:
            confd_trace_printf(" --> CONFD_OK\n");
            break;
        case CONFD_ERR:
            confd_trace_printf(" --> CONFD_ERR\n");
            break;
        default:
            confd_trace_printf(" --> BADRETVAL\n");
        }
    }

    if (retval == CONFD_OK && actx->fd == -1) {
        /* They forgot to do set_fd, so it's an error */
        confd_action_seterr_extended(uinfo, CONFD_ERRCODE_PROTO_USAGE,
                                     0, 0, "No file descriptor set");
        action_reply_error(actx);
        return ret_err(CONFD_ERR_PROTOUSAGE, "No descriptor set for action");
    }
    if (retval != CONFD_OK) {
        if (retval == CONFD_ERR) {
            confd_set_errno(CONFD_ERR_EXTERNAL);
        } else {
            confd_action_seterr_extended(uinfo, CONFD_ERRCODE_PROTO_USAGE,
                                         0, 0, "Bad return value");
            ret_err(CONFD_ERR_PROTOUSAGE,
                    "Bad application return value: %d usid=%d\n",
                    retval, uinfo->usid);
        }
        action_reply_error(actx);
        return CONFD_ERR;
    }

    a[0] = erl_mk_int(CONFD_PROTO_NEW_ACTION);
    a[1] = erl_mk_int(qref);
    a[2] = erl_mk_int(did);
    a[3] = erl_mk_int(USID2TID(uinfo->usid));
    a[4] = erl_mk_int(actx->fd);

    if ((tup = erl_mk_tuple(a, 5)) == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
    }
    free_error(&actx->error);
    retval = term_write(fd, tup, -1, -1);
    if (retval != CONFD_OK)
        actx->state = ACT_STATE_NONE;
    erl_free_compound(tup);
    return retval;
}

static int notif_get_log_times_reply(
    struct confd_notification_ctx *nctx, int retval)
{
    if (confd_debug_level >= CONFD_TRACE) {
        switch (retval) {
        case CONFD_OK:
            confd_trace_printf(" --> CONFD_OK\n");
            break;
        case CONFD_ERR:
            confd_trace_printf(" --> CONFD_ERR\n");
            break;
        default:
            confd_trace_printf(" --> BADRETVAL\n");
        }
    }

    switch (retval) {
    case CONFD_OK:
        if (nctx->seen_reply == 1) {
            return CONFD_OK;
        } else {
            ret_err(CONFD_ERR_PROTOUSAGE,
                    "Missing notification stream "
                    "get_log_times() reply\n");
            confd_notification_seterr_extended(nctx, CONFD_ERRCODE_PROTO_USAGE,
                                               0, 0, "expect data");
        }
        break;
    case CONFD_ERR:
        if (nctx->seen_reply == 1) {
            return ret_err(CONFD_ERR_PROTOUSAGE,
                           "Got ret CONFD_ERR after "
                           "get_log_times() reply\n");
        } else {
            confd_set_errno(CONFD_ERR_EXTERNAL);
        }
        break;
    default:
        ret_err(CONFD_ERR_PROTOUSAGE,
                "Bad return value: %d\n", retval);
        confd_notification_seterr_extended(nctx, CONFD_ERRCODE_PROTO_USAGE,
                                           0, 0, "Bad return value");
    }

    reply_error(nctx->dx->ctl_sock, CONFD_PROTO_NOTIF_GET_LOG_TIMES,
                nctx->query_ref, nctx->dx->daemon_id, &nctx->error);
    return CONFD_ERR;
}

/* only for nctx "temporarily allocated" at replay */
static void confd_notification_free_ctx(struct confd_notification_ctx *nctx)
{
    if (nctx->name != NULL)
        free(nctx->name);
    if (nctx->ctx_name != NULL)
        free(nctx->ctx_name);
    free(nctx);
}

static int notif_replay(struct confd_daemon_ctx *dx, int qref,
                        struct confd_notification_stream_cbs *ncbs,
                        int subid, ETERM *estart, ETERM *estop)
{
    struct confd_notification_ctx *nctx;
    confd_value_t startv, stopv;
    struct confd_datetime *start = &startv.val.datetime;
    struct confd_datetime *stop = &stopv.val.datetime;
    ETERM *tup;
    ETERM *a[5];
    int retval;

    if (eterm_to_val(estart, &startv) == NULL)
        return CONFD_ERR;
    if (bin_eq(estop, "undefined"))
        stop = NULL;
    else {
        if (eterm_to_val(estop, &stopv) == NULL)
            return CONFD_ERR;
    }
    if ((nctx =         /* freed at replay done or on cb error */
         malloc(sizeof(struct confd_notification_ctx))) == NULL) {
        confd_trace(CONFD_DEBUG, "Cannot allocate context\n");
        return CONFD_ERR;
    }
    if ((nctx->name = strdup(ncbs->streamname)) == NULL) {
        free(nctx);
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate context name\n");
    }
    nctx->ctx_name = NULL;
    nctx->fd = nctx->live_fd = ncbs->fd;
    nctx->dx = dx;
    clear_error(&nctx->error);
    nctx->cb_opaque = ncbs->cb_opaque;
    nctx->subid = subid;
    nctx->flags = dx->flags;
    nctx->src_addr.af = AF_UNSPEC;
    confd_trace(CONFD_TRACE,
                "CALL notification stream replay(stream=%s, replay=%d)",
                nctx->name, nctx->subid);
    retval = ncbs->replay(nctx, start, stop);
    if (confd_debug_level >= CONFD_TRACE) {
        switch (retval) {
        case CONFD_OK:
            confd_trace_printf(" --> CONFD_OK\n");
            break;
        case CONFD_ERR:
            confd_trace_printf(" --> CONFD_ERR\n");
            break;
        default:
            confd_trace_printf(" --> BADRETVAL\n");
        }
    }

    if (retval == CONFD_OK) {
        a[0] = erl_mk_int(CONFD_PROTO_NOTIF_REPLAY);
        a[1] = erl_mk_int(qref);
        a[2] = erl_mk_int(dx->daemon_id);
        a[3] = erl_mk_atom("ok");
        if ((tup = erl_mk_tuple(a, 4)) == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
        }
        free_error(&nctx->error);
        retval = term_write(nctx->dx->ctl_sock, tup, -1, -1);
        erl_free_compound(tup);
        return retval;
    }

    if (retval == CONFD_ERR) {
        confd_set_errno(CONFD_ERR_EXTERNAL);
    } else {
        ret_err(CONFD_ERR_PROTOUSAGE,
                "Bad return value: %d\n", retval);
        confd_notification_seterr_extended(nctx, CONFD_ERRCODE_PROTO_USAGE,
                                           0, 0, "Bad return value");
    }
    reply_error(nctx->dx->ctl_sock, CONFD_PROTO_NOTIF_REPLAY, qref,
                dx->daemon_id, &nctx->error);
    confd_notification_free_ctx(nctx);
    return CONFD_ERR;
}


static int decode_target(ETERM *etarget, struct confd_snmp_target *target)
{
    if (eterm_to_val(TE(etarget, 0), &target->address) == NULL)
        return CONFD_ERR;
    target->port = TUINT(etarget, 1);
    return CONFD_OK;
}

static int notif_snmp_inform(struct confd_daemon_ctx *dx, int qref,
                             struct confd_notification_snmp_inform_cbs *cb,
                             int op, ETERM *et)
{
    struct confd_notification_ctx nctx;
    ETERM *tup;
    ETERM *a[5];
    int ref = TINT(et, 5);
    int retval;

    memset(&nctx, 0, sizeof(nctx));
    nctx.fd = -1;
    nctx.dx = dx;
    nctx.cb_opaque = cb->cb_opaque;
    clear_error(&nctx.error);
    if (op == CONFD_PROTO_NOTIF_SNMP_INFORM_TARGETS) {
        ETERM *etargets = ERL_TUPLE_ELEMENT(et, 6);
        int n = erl_length(etargets), i;
        struct confd_snmp_target targets[n];

        for (i = 0; i < n; i++) {
            ETERM *hd = ERL_CONS_HEAD(etargets);
            if (decode_target(hd, &targets[i]) != CONFD_OK)
                return CONFD_ERR;
            etargets = ERL_CONS_TAIL(etargets);
        }
        confd_trace(CONFD_TRACE, "CALL notification_snmp_inform "
                    "targets(ref=%d num_targets=%d)\n", ref, n);
        cb->targets(&nctx, ref, &targets[0], n);
    } else {
        ETERM *etarget = ERL_TUPLE_ELEMENT(et, 6);
        int got_response = TINT(et, 7);
        struct confd_snmp_target target;

        if (decode_target(etarget, &target) != CONFD_OK)
            return CONFD_ERR;;
        confd_trace(CONFD_TRACE, "CALL notification_snmp_inform "
                    "result(ref=%d got_response=%d)\n", ref, got_response);
        cb->result(&nctx, ref, &target, got_response);
    }

    /* no cb return value */
    a[0] = erl_mk_int(op);
    a[1] = erl_mk_int(qref);
    a[2] = erl_mk_int(dx->daemon_id);
    if ((tup = erl_mk_tuple(a, 3)) == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
    }
    free_error(&nctx.error);
    retval = term_write(dx->ctl_sock, tup, -1, -1);
    erl_free_compound(tup);
    return retval;
}

static void decode_oid(ETERM *oid, struct confd_snmp_oid *op)
{
    int i;

    for (i = 0; i < sizeof(op->oid)/sizeof(op->oid[0]) &&
             !ERL_IS_NIL(oid); i++) {
        op->oid[i] = ERL_INT_VALUE(ERL_CONS_HEAD(oid));
        oid = ERL_CONS_TAIL(oid);
    }
    op->len = i;
}

static int notif_recv_snmp(struct confd_daemon_ctx *dx, int qref,
                           struct confd_notification_sub_snmp_cb *cb,
                           ETERM *notification, ETERM *varbinds, int n,
                           ETERM *srcaddr, u_int16_t srcport)
{
    struct confd_snmp_varbind vb[n];
    confd_value_t v_srcaddr;
    struct confd_notification_ctx nctx;
    char *notif_str;
    ETERM *tup;
    ETERM *a[5];
    int retval;
    int i;

    if (eterm_to_val(srcaddr, &v_srcaddr) == NULL)
        return CONFD_ERR;
    if ((notif_str = bin_dup(notification)) == NULL) {
        confd_trace(CONFD_DEBUG, "Cannot allocate for snmp notification\n");
        return CONFD_ERR;
    }
    for (i = 0; i < n; i++) {
        ETERM *hd = ERL_CONS_HEAD(varbinds);

        if (ERL_TUPLE_SIZE(hd) == 2) {
            if (ERL_IS_BINARY(ERL_TUPLE_ELEMENT(hd, 0))) {
                vb[i].type = CONFD_SNMP_VARIABLE;
                bin_copy(vb[i].var.name, sizeof(vb[i].var.name),
                         ERL_TUPLE_ELEMENT(hd, 0));
            } else {
                vb[i].type = CONFD_SNMP_OID;
                decode_oid(ERL_TUPLE_ELEMENT(hd, 0), &vb[i].var.oid);
            }
            if (eterm_to_val(ERL_TUPLE_ELEMENT(hd, 1), &vb[i].val) == NULL)
                return CONFD_ERR;
        } else {
            vb[i].type = CONFD_SNMP_COL_ROW;
            bin_copy(vb[i].var.cr.column, sizeof(vb[i].var.cr.column),
                     ERL_TUPLE_ELEMENT(hd, 0));
            decode_oid(ERL_TUPLE_ELEMENT(hd, 1), &vb[i].var.cr.rowindex);
            if (eterm_to_val(ERL_TUPLE_ELEMENT(hd, 2), &vb[i].val) == NULL)
                return CONFD_ERR;
        }
        varbinds = ERL_CONS_TAIL(varbinds);
    }
    memset(&nctx, 0, sizeof(nctx));
    nctx.fd = -1;
    nctx.dx = dx;
    nctx.cb_opaque = cb->cb_opaque;
    nctx.query_ref = qref;
    clear_error(&nctx.error);
    confd_trace(CONFD_TRACE,
                "CALL notification recv snmp(notification=%s)",
                notif_str);
    retval = cb->recv(&nctx, notif_str, vb, n, &v_srcaddr, srcport);
    free(notif_str);
    for (i = 0; i < n; i++)
        confd_free_eterm_val(&vb[i].val);
    if (confd_debug_level >= CONFD_TRACE) {
        switch (retval) {
        case CONFD_OK:
            confd_trace_printf(" --> CONFD_OK\n");
            break;
        case CONFD_ERR:
            confd_trace_printf(" --> CONFD_ERR\n");
            break;
        default:
            confd_trace_printf(" --> BADRETVAL\n");
        }
    }

    if (retval == CONFD_OK) {
        a[0] = erl_mk_int(CONFD_PROTO_NOTIF_RECV_SNMP);
        a[1] = erl_mk_int(qref);
        a[2] = erl_mk_int(dx->daemon_id);
        a[3] = erl_mk_atom("ok");
        if ((tup = erl_mk_tuple(a, 4)) == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
        }
        free_error(&nctx.error);
        retval = term_write(dx->ctl_sock, tup, -1, -1);
        erl_free_compound(tup);
        return retval;
    }

    if (retval == CONFD_ERR) {
        confd_set_errno(CONFD_ERR_EXTERNAL);
    } else {
        ret_err(CONFD_ERR_PROTOUSAGE,
                "Bad return value: %d\n", retval);
        confd_notification_seterr_extended(&nctx, CONFD_ERRCODE_PROTO_USAGE,
                                           0, 0, "Bad return value");
    }
    reply_error(dx->ctl_sock, CONFD_PROTO_NOTIF_RECV_SNMP, qref,
                dx->daemon_id, &nctx.error);
    return CONFD_ERR;

}

static void mk_timezone(int zone, int minutes, ETERM **pair)
{
    if (zone == CONFD_TIMEZONE_UNDEF) {
        pair[0] = erl_mk_empty_list();
        pair[1] = erl_mk_uint(0);
    } else {
        pair[0] = erl_mk_int(zone);
        pair[1] = erl_mk_int(minutes);
    }
}


/* Given a confd_value_t, return an ETERM representing the val */

#define CHECK_VAL_PTR(elem, type) do {                                  \
        if (v->elem == NULL) {                                          \
            ret_err(CONFD_ERR_BADTYPE,                                  \
                    "confd_value_t " #elem " is NULL for " #type);      \
            return NULL;                                                \
        }                                                               \
    } while (0)


static void
free_tag_value_array(confd_tag_value_t tv[], int len)
{
    int i;
    for (i = 0; i < len; i++)
        confd_free_eterm_val(CONFD_GET_TAG_VALUE(&tv[i]));
}

static ETERM *
vals_to_terms(const confd_value_t *v,
                     ETERM **list)
{
    int i;
    for(i=0; i<v->val.list.size ;i++)
        if ((list[i] = val_to_term(&v->val.list.ptr[i])) == NULL)
            return NULL;
    return erl_mk_list(list, v->val.list.size);
}

ETERM *val_to_term(const confd_value_t *v)
{
    ETERM *tup[9];
    ETERM *pair[2];

    switch (v->type) {
    case C_NOEXISTS:
        return erl_mk_atom("not_found");
    case C_DEFAULT:
        return erl_mk_atom("default");
    case C_STR:
        CHECK_VAL_PTR(val.s, C_STR);
        return erl_mk_binary(v->val.s, strlen(v->val.s));
    case C_BUF:
        CHECK_VAL_PTR(val.buf.ptr, C_BUF);
        return erl_mk_binary((char *)v->val.buf.ptr,v->val.buf.size);
    case C_BINARY:
        CHECK_VAL_PTR(val.buf.ptr, C_BINARY);
        pair[0] = erl_mk_int(C_BINARY);
        pair[1] = erl_mk_binary((char *)v->val.buf.ptr,v->val.buf.size);
        return erl_mk_tuple(pair,2);
    case C_DOUBLE:
        if (!finite(v->val.d)) {
            ret_err(CONFD_ERR_BADTYPE,
                    "Unsupported floating point value: %g", v->val.d);
            return NULL;
        }
        return erl_mk_float(v->val.d);
    case C_IPV4:
        return ip4_to_term(&v->val.ip);
    case C_IPV6:
        return ip6_to_term(&v->val.ip6);
    case C_INT8:
        pair[0] = erl_mk_int(C_INT8);
        pair[1] = erl_mk_int(v->val.i8);
        return erl_mk_tuple(pair,2);
    case C_INT16:
        pair[0] = erl_mk_int(C_INT16);
        pair[1] = erl_mk_int(v->val.i16);
        return erl_mk_tuple(pair,2);
    case C_INT32:  /* special fast case */
        return erl_mk_int(v->val.i32);
    case C_INT64:
        pair[0] = erl_mk_int(C_INT64);
        pair[1] = erl_mk_longlong(v->val.i64);
        return erl_mk_tuple(pair,2);
    case C_UINT8:
        pair[0] = erl_mk_int(C_UINT8);
        pair[1] = erl_mk_uint(v->val.u8);
        return erl_mk_tuple(pair,2);
    case C_UINT16:
        pair[0] = erl_mk_int(C_UINT16);
        pair[1] = erl_mk_uint(v->val.u16);
        return erl_mk_tuple(pair,2);
    case C_UINT32:
        pair[0] = erl_mk_int(C_UINT32);
        pair[1] = erl_mk_uint(v->val.u32);
        return erl_mk_tuple(pair,2);
    case C_UINT64:
        pair[0] = erl_mk_int(C_UINT64);
        pair[1] = erl_mk_ulonglong(v->val.u64);
        return erl_mk_tuple(pair,2);
    case C_BOOL: {
        if (v->val.boolean == 0)
            return erl_mk_atom("false");
        else
            return erl_mk_atom("true");
    }
    case C_QNAME:
        CHECK_VAL_PTR(val.qname.name.ptr, C_QNAME);
        pair[0] = erl_mk_int(v->type);
        if (v->val.qname.prefix.size > 0) {
            CHECK_VAL_PTR(val.qname.prefix.ptr, C_QNAME);
            tup[0] = erl_mk_eatom((char *)v->val.qname.prefix.ptr,
                                  v->val.qname.prefix.size);
        } else {
            tup[0] = erl_mk_atom("undefined");
        }
        tup[1] = erl_mk_eatom((char *)v->val.qname.name.ptr,
                              v->val.qname.name.size);
        pair[1] = erl_mk_tuple(tup, 2);
        return erl_mk_tuple(pair,2);
    case C_DATETIME:
        pair[0] = erl_mk_int(v->type);
        tup[0] = erl_mk_int(v->val.datetime.year);
        tup[1] = erl_mk_uint(v->val.datetime.month);
        tup[2] = erl_mk_uint(v->val.datetime.day);
        tup[3] = erl_mk_uint(v->val.datetime.hour);
        tup[4] = erl_mk_uint(v->val.datetime.min);
        tup[5] = erl_mk_uint(v->val.datetime.sec);
        tup[6] = erl_mk_uint(v->val.datetime.micro);
        mk_timezone(v->val.datetime.timezone,
                    v->val.datetime.timezone_minutes,
                    &tup[7]);
        pair[1] = erl_mk_tuple(tup, 9);
        return erl_mk_tuple(pair,2);
    case C_DATE:
        pair[0] = erl_mk_int(v->type);
        tup[0] = erl_mk_int(v->val.date.year);
        tup[1] = erl_mk_uint(v->val.date.month);
        tup[2] = erl_mk_uint(v->val.date.day);
        mk_timezone(v->val.date.timezone,
                    v->val.date.timezone_minutes,
                    &tup[3]);
        pair[1] = erl_mk_tuple(tup, 5);
        return erl_mk_tuple(pair,2);
    case C_TIME:
        pair[0] = erl_mk_int(v->type);
        tup[0] = erl_mk_uint(v->val.time.hour);
        tup[1] = erl_mk_uint(v->val.time.min);
        tup[2] = erl_mk_uint(v->val.time.sec);
        tup[3] = erl_mk_uint(v->val.time.micro);
        mk_timezone(v->val.time.timezone,
                    v->val.time.timezone_minutes,
                    &tup[4]);
        pair[1] = erl_mk_tuple(tup, 6);
        return erl_mk_tuple(pair,2);
    case C_DURATION:
        pair[0] = erl_mk_int(v->type);
        tup[0] = erl_mk_int(v->val.duration.years);
        tup[1] = erl_mk_uint(v->val.duration.months);
        tup[2] = erl_mk_uint(v->val.duration.days);
        tup[3] = erl_mk_uint(v->val.duration.hours);
        tup[4] = erl_mk_uint(v->val.duration.mins);
        tup[5] = erl_mk_uint(v->val.duration.secs);
        tup[6] = erl_mk_uint(v->val.duration.micros);
        pair[1] = erl_mk_tuple(tup, 7);
        return erl_mk_tuple(pair,2);
    case C_ENUM_HASH:
        pair[0] = erl_mk_int(C_ENUM_HASH);
        pair[1] = erl_mk_int(v->val.enumhash);
        return erl_mk_tuple(pair,2);
    case C_BIT32:
        pair[0] = erl_mk_int(C_BIT32);
        pair[1] = erl_mk_uint(v->val.b32);
        return erl_mk_tuple(pair,2);
    case C_BIT64:
        pair[0] = erl_mk_int(C_BIT64);
        pair[1] = erl_mk_ulonglong(v->val.b64);
        return erl_mk_tuple(pair,2);
    case C_BITBIG:
        CHECK_VAL_PTR(val.buf.ptr, C_BITBIG);
        pair[0] = erl_mk_int(C_BITBIG);
        pair[1] = erl_mk_binary((char *)v->val.buf.ptr,v->val.buf.size);
        return erl_mk_tuple(pair,2);
    case C_LIST: {
        ETERM **list;
        ETERM *ret = NULL;

        if (v->val.list.size > 0)
            CHECK_VAL_PTR(val.list.ptr, C_LIST);

        /* Small requests on stack, large on heap. */
        if (v->val.list.size < 10) {
            ETERM *stack_list[v->val.list.size];
            ret = vals_to_terms(v, stack_list);
        } else if ((list = confd_malloc((v->val.list.size) *
                                        sizeof(ETERM *))) != NULL) {
            ret = vals_to_terms(v, list);
            free(list);
        }
        return ret;
    }
    case C_XMLTAG:
        pair[0] = erl_mk_int(CONFD_GET_XMLTAG_NS(v));
        pair[1] = erl_mk_int(CONFD_GET_XMLTAG(v));
        return erl_cons(pair[0], pair[1]);
    case C_OBJECTREF: {
        confd_hkeypath_t *hkp = CONFD_GET_OBJECTREF(v);
        CHECK_VAL_PTR(val.hkp, C_OBJECTREF);
        pair[0] = erl_mk_int(v->type);
        pair[1] = hkeypath_to_eterm(hkp);
        return erl_mk_tuple(pair,2);
    }
    case C_OID:
        CHECK_VAL_PTR(val.oidp, C_OID);
        {
            char buf[4*v->val.oidp->len];
            int i;
            for (i = 0; i < v->val.oidp->len; i++)
                put_int32(v->val.oidp->oid[i], &buf[4*i]);
            pair[0] = erl_mk_int(C_OID);
            pair[1] = erl_mk_binary(buf, 4 * v->val.oidp->len);
            return erl_mk_tuple(pair,2);
        }
    case C_IPV4PREFIX: {
        pair[0] = erl_mk_int(C_IPV4PREFIX);
        tup[0] = ip4_to_term(&v->val.ipv4prefix.ip);
        tup[1] = erl_mk_uint(v->val.ipv4prefix.len);
        pair[1] = erl_mk_tuple(tup, 2);
        return erl_mk_tuple(pair,2);
    }
    case C_IPV6PREFIX: {
        pair[0] = erl_mk_int(C_IPV6PREFIX);
        tup[0] = ip6_to_term(&v->val.ipv6prefix.ip6);
        tup[1] = erl_mk_uint(v->val.ipv6prefix.len);
        pair[1] = erl_mk_tuple(tup, 2);
        return erl_mk_tuple(pair,2);
    }
    case C_DECIMAL64: {
        pair[0] = erl_mk_int(C_DECIMAL64);
        tup[0] = erl_mk_longlong(v->val.d64.value);
        tup[1] = erl_mk_uint(v->val.d64.fraction_digits);
        pair[1] = erl_mk_tuple(tup, 2);
        return erl_mk_tuple(pair,2);
    }
    case C_IDENTITYREF: {
        pair[0] = erl_mk_int(C_IDENTITYREF);
        tup[0] = erl_mk_uint(v->val.idref.ns);
        tup[1] = erl_mk_uint(v->val.idref.id);
        pair[1] = erl_mk_tuple(tup, 2);
        return erl_mk_tuple(pair,2);
    }
    case C_IPV4_AND_PLEN: {
        pair[0] = erl_mk_int(C_IPV4_AND_PLEN);
        tup[0] = ip4_to_term(&v->val.ipv4prefix.ip);
        tup[1] = erl_mk_uint(v->val.ipv4prefix.len);
        pair[1] = erl_mk_tuple(tup, 2);
        return erl_mk_tuple(pair,2);
    }
    case C_IPV6_AND_PLEN: {
        pair[0] = erl_mk_int(C_IPV6_AND_PLEN);
        tup[0] = ip6_to_term(&v->val.ipv6prefix.ip6);
        tup[1] = erl_mk_uint(v->val.ipv6prefix.len);
        pair[1] = erl_mk_tuple(tup, 2);
        return erl_mk_tuple(pair,2);
    }
    case C_DQUAD:
        pair[0] = erl_mk_int(C_DQUAD);
        pair[1] = erl_mk_binary((char *)v->val.dquad.quad, 4);
        return erl_mk_tuple(pair,2);
    case C_HEXSTR:
        CHECK_VAL_PTR(val.buf.ptr, C_HEXSTR);
        pair[0] = erl_mk_int(C_HEXSTR);
        pair[1] = erl_mk_binary((char *)v->val.buf.ptr,v->val.buf.size);
        return erl_mk_tuple(pair,2);
    case C_SYMBOL:
    case C_XMLBEGIN:
    case C_XMLEND:
    case C_UNION:
    case C_PTR:
    case C_CDBBEGIN:
    case C_XMLBEGINDEL:
    case C_MAXTYPE:
    case C_XMLMOVEFIRST:
    case C_XMLMOVEAFTER:
        break;
    }

    ret_err(CONFD_ERR_BADTYPE, "Invalid confd_vtype value: %d", v->type);
    return NULL;
}


static ETERM *attr_to_term(const confd_attr_value_t *attrs, int num_attrs)
{
    ETERM *eattr[2], *elist[num_attrs];
    int i;
    for(i=0; i<num_attrs; i++) {
        eattr[0] = erl_mk_uint(attrs[i].attr);
        if ((eattr[1] = val_to_term(&attrs[i].v)) == NULL) {
            return NULL;
        }
        elist[i] = erl_mk_tuple(eattr, 2);
    }
    return erl_mk_list(elist, num_attrs);
}



/* Given a confd_tag_value_t, return an ETERM representing the tag_val */

ETERM *tag_val_to_term(const confd_tag_value_t *tv)
{
    ETERM *tag;
    ETERM *tup[2];
    ETERM *cdbtup[2];

    switch (CONFD_GET_TAG_VALUE(tv)->type) {
    case C_XMLBEGIN:
        tup[1] = erl_mk_atom("start");
        break;
    case C_XMLBEGINDEL:
        tup[1] = erl_mk_atom("delete");
        break;
    case C_XMLEND:
        tup[1] = erl_mk_atom("stop");
        break;
    case C_XMLTAG:
        tup[1] = erl_mk_atom("leaf");
        break;
    case C_XMLMOVEFIRST:
        tup[1] = erl_mk_atom("move_first");
        break;
    case C_XMLMOVEAFTER:
        tup[1] = erl_mk_atom("move_after");
        break;
    case C_CDBBEGIN:
        cdbtup[0] = erl_mk_atom("start");
        cdbtup[1] = erl_mk_int(CONFD_GET_CDBBEGIN(CONFD_GET_TAG_VALUE(tv)));
        tup[1] = erl_mk_tuple(cdbtup, 2);
        break;
    case C_PTR:
        tup[1] = erl_mk_atom("not_found");
        break;
    default:
        if ((tup[1] = val_to_term(CONFD_GET_TAG_VALUE(tv)))==NULL)
            return NULL;
    }
    tag = erl_mk_int(CONFD_GET_TAG_TAG(tv));
    if (CONFD_GET_TAG_NS(tv) == 0)
        tup[0] = tag;
    else
        tup[0] = erl_cons(erl_mk_int(CONFD_GET_TAG_NS(tv)), tag);
    return erl_mk_tuple(tup, 2);
}

static ETERM *tag_val_attr_to_term(const confd_tag_value_attr_t *tva)
{
    ETERM *tag;
    ETERM *tup[3];
    ETERM *cdbtup[3];

    switch (CONFD_GET_TAG_VALUE(tva)->type) {
    case C_XMLBEGIN:
        tup[1] = erl_mk_atom("start");
        break;
    case C_XMLBEGINDEL:
        tup[1] = erl_mk_atom("delete");
        break;
    case C_XMLEND:
        tup[1] = erl_mk_atom("stop");
        break;
    case C_XMLTAG:
        tup[1] = erl_mk_atom("leaf");
        break;
    case C_CDBBEGIN:
        cdbtup[0] = erl_mk_atom("start");
        cdbtup[1] = erl_mk_int(CONFD_GET_CDBBEGIN(CONFD_GET_TAG_VALUE(tva)));
        cdbtup[2] =
            erl_mk_int(CONFD_GET_CDBBEGIN(CONFD_GET_TAG_ATTR_VALUE(tva)));
        tup[1] = erl_mk_tuple(cdbtup, 3);
        break;
    case C_PTR:
        tup[1] = erl_mk_atom("not_found");
        break;
    default:
        if ((tup[1] = val_to_term(CONFD_GET_TAG_VALUE(tva)))==NULL)
            return NULL;
    }
    tag = erl_mk_int(CONFD_GET_TAG_TAG(tva));
    if (CONFD_GET_TAG_NS(tva) == 0)
        tup[0] = tag;
    else
        tup[0] = erl_cons(erl_mk_int(CONFD_GET_TAG_NS(tva)), tag);

    if ((tup[2] = attr_to_term(tva->attrs, tva->num_attrs))==NULL)
        return NULL;

    return erl_mk_tuple(tup, 3);
}

ETERM *vals_to_termlist(const confd_value_t *vp, int n, int ret_tup)
{
    int i;
    ETERM *arr[n];
    for(i=0; i<n; i++) {
        ETERM *h = val_to_term(&vp[i]);
        if (h == NULL) {
            for (i--; i>=0; i--)
                erl_free_compound(arr[i]);
            return NULL;
        }
        arr[i] = h;
    }
    if (ret_tup)
        return erl_mk_tuple(arr, n);
    return erl_mk_list(arr, n);
}

ETERM *tag_vals_to_termlist(const confd_tag_value_t *tvp, int n, int ret_tup)
{
    int i;
    ETERM **arr, *ret;

    /* Don't change this to stack allocation - is heap on customer request */
    if ((arr = confd_malloc(n * sizeof(ETERM *))) == NULL)
        return NULL;
    for(i=0; i<n; i++) {
        ETERM *h = tag_val_to_term(&tvp[i]);
        if (h == NULL) {
            for (i--; i>=0; i--)
                erl_free_compound(arr[i]);
            free(arr);
            return NULL;
        }
        arr[i] = h;
    }
    if (ret_tup)
        ret = erl_mk_tuple(arr, n);
    else
        ret = erl_mk_list(arr, n);
    free(arr);
    return ret;
}

static ETERM *tag_vals_attrs_to_termlist(const confd_tag_value_attr_t *tvap,
                                         int n, int ret_tup)
{
    int i;
    ETERM **arr, *ret;

    /* Don't change this to stack allocation - is heap on customer request */
    if ((arr = confd_malloc(n * sizeof(ETERM *))) == NULL)
        return NULL;
    for(i=0; i<n; i++) {
        ETERM *h = tag_val_attr_to_term(&tvap[i]);
        if (h == NULL) {
            for (i--; i>=0; i--)
                erl_free_compound(arr[i]);
            free(arr);
            return NULL;
        }
        arr[i] = h;
    }
    if (ret_tup)
        ret = erl_mk_tuple(arr, n);
    else
        ret = erl_mk_list(arr, n);
    free(arr);
    return ret;
}

int confd_serialize(struct confd_serializable *s,
                    unsigned char *buf, int bufsz,
                    int *bytes_written, unsigned char **allocated)
{
    ETERM *term, *tup[2], *r;
    int termlen;

    if (confd_check_init() != CONFD_OK)
        return -1;
    switch (s->type) {
    case CONFD_SERIAL_VALUE_T:
        if ((term = val_to_term(s->u.value)) == NULL)
            return -1;
        break;
    case CONFD_SERIAL_HKEYPATH:
        if ((term = hkeypath_to_eterm(s->u.hkp)) == NULL)
            return -1;
        break;
    case CONFD_SERIAL_TAG_VALUE:
        if ((term = tag_val_to_term(s->u.tval)) == NULL)
            return -1;
        break;
    default:
        return -1;
    }
    tup[0] = erl_mk_int(s->type); tup[1] = term;
    r = erl_mk_tuple(tup, 2);
    termlen = erl_term_len(r);
    if (buf == NULL) {
        if ((buf = malloc(termlen)) == NULL)
            return -1;
        *allocated = buf;
    }
    else if (termlen > bufsz ) {
        erl_free_compound(r);
        return termlen;
    }
    if (erl_encode(r, buf)  == 0) {
        erl_free_compound(r);
        return -1;
    }
    *bytes_written = termlen;
    erl_free_compound(r);
    return 0;
}

int confd_deserialize(struct confd_deserializable *s,
                      unsigned char *buf)
{
    ETERM *t;
    int ret = CONFD_OK;

    if (confd_check_init() != CONFD_OK)
        return CONFD_ERR;
    if ((t = erl_decode(buf)) == NULL)
        return CONFD_ERR;
    s->type = CONFD_SERIAL_NONE;
    switch (TINT(t, 0)) {
    case CONFD_SERIAL_VALUE_T:
        if (eterm_to_val(TE(t, 1), &(s->u.value)) == NULL)
            ret = CONFD_ERR;
        break;
    case CONFD_SERIAL_HKEYPATH:
        if (populate_keypath(TE(t, 1), &(s->u.hkp)) == 0)
            ret = CONFD_ERR;
        break;
    case CONFD_SERIAL_TAG_VALUE:
        if (eterm_to_tag_val(TE(t,1), &(s->u.tval), 1) == NULL)
            ret = CONFD_ERR;
        break;
    default:
        ret = CONFD_ERR;
    }
    if (ret == CONFD_OK)
        s->type = TINT(t, 0);
    s->internal = t;
    return ret;
}

void confd_deserialized_free(struct confd_deserializable *s)
{
    switch (s->type) {
    case CONFD_SERIAL_VALUE_T:
        confd_free_eterm_val(&s->u.value);
        break;
    case CONFD_SERIAL_HKEYPATH:
        confd_free_eterm_keypath(&s->u.hkp);
        break;
    case CONFD_SERIAL_TAG_VALUE:
        confd_free_eterm_val(&s->u.tval.v);
        break;
    case CONFD_SERIAL_NONE:
        break;
    }
    erl_free_compound((ETERM*)s->internal);
}


int confd_data_set_timeout(struct confd_trans_ctx *tctx, int timeout_secs)
{
    ETERM *a[4], *tup;
    int wfd = (tctx->last_proto_op == CONFD_VALIDATE_VALUE ?
               tctx->vfd : tctx->fd);
    int ret;

    if (tctx->lastop != CONFD_PROTO_CALLBACK) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Timeout can only be set in data/validation callback\n");
    }

    a[0] = erl_mk_int(CONFD_PROTO_CALLBACK_TIMEOUT);
    a[1] = erl_mk_int(tctx->query_ref);
    a[2] = erl_mk_int(tctx->dx->daemon_id);
    a[3] = erl_mk_int(timeout_secs);
    if ((tup = erl_mk_tuple(a, 4)) == NULL) {
        confd_set_errno(CONFD_ERR_MALLOC);
        return CONFD_ERR;
    }
    ret = term_write(wfd, tup, -1, -1);
    erl_free_compound(tup);
    return ret;
}


static int intern_confd_data_reply_value2(struct confd_trans_ctx *tctx,
                                          const confd_value_t *v, int do_trace)
{
    ETERM *tup;
    ETERM *a[4];
    int wfd = (tctx->last_proto_op == CONFD_VALIDATE_VALUE ?
               tctx->vfd : tctx->fd);
    int ret;

    SET_SEEN_REPLY(tctx);
    a[3] = val_to_term(v);
    if (a[3] == NULL) {
        tctx->seen_reply = 0;
        return CONFD_ERR;
    }
    a[0] = erl_mk_int(CONFD_PROTO_CALLBACK);
    a[1] = erl_mk_int(tctx->query_ref);
    a[2] = erl_mk_int(tctx->dx->daemon_id);
    if ((tup = erl_mk_tuple(a, 4)) == NULL) {
        tctx->seen_reply = 0;
        confd_set_errno(CONFD_ERR_MALLOC);
        return CONFD_ERR;
    }
    if (do_trace) {
        reply_trace(v);
    }
    free_error(&tctx->error);
    ret = term_write(wfd,tup, -1, -1);
    erl_free_compound(tup);
    return ret;
}

static int intern_confd_data_reply_value(struct confd_trans_ctx *tctx,
                                         const confd_value_t *v)
{
    return intern_confd_data_reply_value2(tctx, v, 1);
}

static int proto_cb_err(void)
{
    return ret_err(CONFD_ERR_PROTOUSAGE, "Cannot call this function here");
}

int confd_data_reply_value(struct confd_trans_ctx *tctx,
                           const confd_value_t *v)
{
    switch (tctx->last_proto_op) {
    case CONFD_DATA_CB_GET_ELEM:
    case CONFD_DATA_CB_NUM_INSTANCES:
        return intern_confd_data_reply_value(tctx, v);
    case CONFD_DATA_CB_GET_CASE:
        switch (v->type) {
        case C_XMLTAG:
        case C_NOEXISTS:
        case C_DEFAULT:
            return intern_confd_data_reply_value(tctx, v);
            break;
        default:
            return ret_err(CONFD_ERR_BADTYPE,
                           "Case value must be XMLTAG, NOEXISTS, or DEFAULT");
        }
        break;
    default:
        return proto_cb_err();
    }
}

int confd_data_reply_value_attrs(struct confd_trans_ctx *tctx,
                                 const confd_value_t *v,
                                 const confd_attr_value_t *attrs,
                                 int num_attrs)
{
    ETERM *reply[2];

    clr_confd_err();
    if (tctx->last_proto_op != CONFD_DATA_CB_GET_ELEM)
        return proto_cb_err();
    if ((reply[0] = val_to_term(v)) == NULL) {
        return CONFD_ERR;
    }
    if ((reply[1] = attr_to_term(attrs, num_attrs)) == NULL) {
        return CONFD_ERR;
    }
    return trans_reply_callback(tctx, erl_mk_list(reply, 2));
}

int confd_data_reply_attrs(struct confd_trans_ctx *tctx,
                           const confd_attr_value_t *attrs, int num_attrs)
{
    ETERM *reply;

    clr_confd_err();
    if (tctx->last_proto_op != CONFD_DATA_CB_GET_ATTRS)
        return proto_cb_err();
    if ((reply = attr_to_term(attrs, num_attrs)) == NULL) {
        return CONFD_ERR;
    }
    return trans_reply_callback(tctx, reply);
}


int confd_data_reply_not_found(struct confd_trans_ctx *tctx)
{
    confd_value_t v;

    v.type = C_NOEXISTS;
    v.val.i32 = 0;  /* why? */
    switch (tctx->last_proto_op) {
    case CONFD_DATA_CB_EXISTS_OPTIONAL:
    case CONFD_DATA_CB_GET_ELEM:
    case CONFD_DATA_CB_GET_OBJECT:
    case CONFD_DATA_CB_GET_CASE:
    case CONFD_DATA_CB_GET_ATTRS:
        return intern_confd_data_reply_value(tctx, &v);
    default:
        return proto_cb_err();
    }
}

int confd_data_reply_found(struct confd_trans_ctx *tctx)
{
    confd_value_t v;
    v.type = C_INT32;
    v.val.i32 = 1;
    if (tctx->last_proto_op != CONFD_DATA_CB_EXISTS_OPTIONAL)
        return proto_cb_err();
    return intern_confd_data_reply_value(tctx, &v);
}


int confd_data_reply_subsystem_down(struct confd_trans_ctx *tctx)
{
    confd_value_t v;
    v.type = C_INT32;
    v.val.i32 = 2;
    if (tctx->last_proto_op != CONFD_DATA_CB_EXISTS_OPTIONAL)
        return proto_cb_err();
    return intern_confd_data_reply_value(tctx, &v);
}


int confd_delayed_reply_error(struct confd_trans_ctx *tctx,
                              const char *errstr)
{
    if (tctx->seen_reply == 0) { /* we're ok */
        int put_tctx = 0;
        int ret;
        if (tctx->lastop == CONFD_PROTO_TRANS_LOCK &&
            errstr != NULL && strcmp(errstr, "locked") == 0) {
            return trans_reply_error_extended(tctx, CONFD_ERRCODE_IN_USE,
                                              0, 0, NULL);
        }
        if ((tctx->lastop == CONFD_PROTO_WRITE_START ||
             tctx->lastop == CONFD_PROTO_PREPARE) &&
            errstr != NULL && strcmp(errstr, "in_use") == 0) {
            return trans_reply_error_extended(tctx, CONFD_ERRCODE_IN_USE,
                                              0, 0, NULL);
        }
        if (tctx->lastop == CONFD_PROTO_NEW_TRANS ||
            tctx->lastop == CONFD_PROTO_NEW_VALIDATE ||
            tctx->lastop == CONFD_PROTO_CLOSE_TRANS ||
            tctx->lastop == CONFD_PROTO_CLOSE_VALIDATE) {
            put_tctx = 1;
        }
        if (errstr != NULL)
            ret = trans_reply_error_extended(tctx, CONFD_ERRCODE_APPLICATION,
                                             0, 0, errstr);
        else
            ret = trans_reply_error(tctx);
        if (put_tctx && put_transaction(tctx)) {
            tctx_free(tctx);
        }
        return ret;
    }
    return CONFD_ERR;
}



static int data_reply_ok(struct confd_trans_ctx *tctx)
{
    confd_value_t v;
    v.type = C_INT32;
    v.val.i32 = 0;
    return intern_confd_data_reply_value2(tctx, &v, 0);
}

#define is_trans_cb(op) ((op >= CONFD_PROTO_NEW_TRANS) && \
                         (op <= CONFD_PROTO_CLOSE_TRANS))
#define is_trans_validate_cb(op) ((op == CONFD_PROTO_NEW_VALIDATE) || \
                                  (op == CONFD_PROTO_CLOSE_VALIDATE))

int confd_delayed_reply_ok(struct confd_trans_ctx *tctx)
{
    int lastop = tctx->lastop;
    if (is_trans_cb(lastop) || is_trans_validate_cb(lastop)) {
        int put_tctx = 0;
        int ret;
        if (lastop == CONFD_PROTO_CLOSE_TRANS ||
            lastop == CONFD_PROTO_CLOSE_VALIDATE) {
            put_tctx = 1;
        }
        ret = i_trans_reply_ok(tctx);
        if (put_tctx && put_transaction(tctx)) {
            tctx_free(tctx);
        }
        return ret;
    }
    if (tctx->last_proto_op != CONFD_DATA_CB_SET_ELEM &&
        tctx->last_proto_op != CONFD_DATA_CB_CREATE &&
        tctx->last_proto_op != CONFD_DATA_CB_DELETE &&
        tctx->last_proto_op != CONFD_DATA_CB_SET_CASE &&
        tctx->last_proto_op != CONFD_DATA_CB_SET_ATTR &&
        tctx->last_proto_op != CONFD_DATA_CB_MOVE_AFTER &&
        tctx->last_proto_op != CONFD_DATA_CB_WRITE_ALL &&
        tctx->last_proto_op != CONFD_VALIDATE_VALUE) {
        trans_reply_error_extended(tctx, CONFD_ERRCODE_PROTO_USAGE,
                                   0, 0, "invalid delayed reply ok");
        return proto_cb_err();
    }
    return data_reply_ok(tctx);
}

int confd_delayed_reply_validation_warn(struct confd_trans_ctx *tctx)
{
    int ret;

    if (tctx->last_proto_op != CONFD_VALIDATE_VALUE) {
        trans_reply_error_extended(tctx, CONFD_ERRCODE_PROTO_USAGE,
                                   0, 0, "invalid validation warning");
        ret = proto_cb_err();
    } else {
        ret = trans_reply_warning(tctx);
    }
    return ret;
}

static int get_nodepath(const ETERM *et, struct xml_tag **node, int *nodelen)
{
    int i = 0;
    ETERM *nstag;
    *nodelen = erl_length(et);
    if (!(*node = confd_malloc(*nodelen * sizeof(struct xml_tag)))) {
        return 0;
    }
    while (!(ERL_IS_NIL(et))) {
        nstag = ERL_CONS_HEAD(et);
        (*node)[i].ns = ERL_INT_UVALUE(ERL_CONS_HEAD(nstag));
        (*node)[i].tag = ERL_INT_UVALUE(ERL_CONS_TAIL(nstag));
        i++;
        et = ERL_CONS_TAIL(et);
    }
    return 1;
}

static int get_filter_expr(const ETERM *et, struct confd_list_filter **filter)
{
    struct confd_list_filter *f;
    confd_value_t val;

    if (!(f = confd_malloc(sizeof(struct confd_list_filter)))) {
        return 0;
    }
    memset(f, 0, sizeof(struct confd_list_filter));
    f->type = TUINT(et, 0);
    switch (f->type) {
    case CONFD_LF_OR:
    case CONFD_LF_AND:
        if (!get_filter_expr(ERL_TUPLE_ELEMENT(et, 1), &f->expr1)) {
            goto badret;
        }
        if (!get_filter_expr(ERL_TUPLE_ELEMENT(et, 2), &f->expr2)) {
            goto badret;
        }
        break;
    case CONFD_LF_NOT:
        if (!get_filter_expr(ERL_TUPLE_ELEMENT(et, 1), &f->expr1)) {
            goto badret;
        }
        break;
    case CONFD_LF_EXISTS:
        if (!get_nodepath(ERL_TUPLE_ELEMENT(et, 1), &f->node, &f->nodelen)) {
            goto badret;
        }
        break;
    case CONFD_LF_CMP:
    case CONFD_LF_EXEC:
        f->op = TUINT(et, 1);
        if (!get_nodepath(ERL_TUPLE_ELEMENT(et, 2), &f->node, &f->nodelen)) {
            goto badret;
        }
        if (!eterm_to_val(ERL_TUPLE_ELEMENT(et, 3), &val)) {
            goto badret;
        }
        if (!(f->val = confd_value_dup(&val))) {
            goto badret;
        }
        break;
    case CONFD_LF_ORIGIN:
        if (!eterm_to_val(ERL_TUPLE_ELEMENT(et, 1), &val)) {
            goto badret;
        }
        if (!(f->val = confd_value_dup(&val))) {
            goto badret;
        }
        break;
    default:
        free(f);
        return ret_err(CONFD_ERR_INTERNAL, "Unknown filter type %d", f->type);
    }
    *filter = f;
    return 1;

badret:
    confd_free_list_filter(f);
    return 0;
}

int confd_data_get_list_filter(struct confd_trans_ctx *tctx,
                               struct confd_list_filter **filter)
{
    struct confd_list_filter *f;
    const ETERM *et;

    if (!(et = (const ETERM *)tctx->list_filter)) {
        *filter = NULL;
        return CONFD_OK;
    }
    if (!get_filter_expr(et, &f)) {
        return CONFD_ERR;
    }
    *filter = f;
    return CONFD_OK;
}


void confd_free_list_filter(struct confd_list_filter *filter)
{
    if (!filter) return;
    confd_free_list_filter(filter->expr1);
    confd_free_list_filter(filter->expr2);
    free(filter->node);
    if (filter->val) {
        confd_free_dup_value(filter->val);
    }
    free(filter);
}

static int proto_reply(struct confd_trans_ctx *tctx, int expect_data,
                       int retcode)
{

    if (confd_debug_level >= CONFD_TRACE) {
        switch (retcode) {
        case CONFD_OK:
            confd_trace_printf(" --> CONFD_OK\n");
            break;
        case CONFD_ERR:
            confd_trace_printf(" --> CONFD_ERR\n");
            break;
        case CONFD_ACCUMULATE:
            confd_trace_printf(" --> CONFD_ACCUMULATE\n");
            break;
        case CONFD_VALIDATION_WARN:
            confd_trace_printf(" --> CONFD_VALIDATION_WARN\n");
            break;
        case CONFD_DELAYED_RESPONSE:
            confd_trace_printf(" --> CONFD_DELAYED_RESPONSE\n");
            break;
        default:
            confd_trace_printf(" --> BADRETVAL\n");
        }
    }

    if (expect_data == 0 && tctx->seen_reply == 1) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Cannot send data reply on this call thandle=%d\n",
                       tctx->thandle);
    }
    switch (retcode) {
    case CONFD_DELAYED_RESPONSE:
        return CONFD_DELAYED_RESPONSE;
    case CONFD_OK:
    case CONFD_ACCUMULATE:
        if (expect_data == 1 && tctx->seen_reply == 1) {
            return CONFD_OK;
        }
        else if (expect_data == 1 && tctx->seen_reply == 0) {
            trans_reply_error_extended(tctx, CONFD_ERRCODE_PROTO_USAGE,
                                       0, 0, "expect data");
            return ret_err(CONFD_ERR_PROTOUSAGE,
                           "Expect call to return data, cannot return "
                           "CONFD_OK when no data is sent thandle=%d\n",
                           tctx->thandle);
        }
        else if ((expect_data == 0 && tctx->seen_reply == 0)) {
            return data_reply_ok(tctx);
        }
        break;
    case CONFD_ERR:
        if (expect_data == 1 && tctx->seen_reply == 1) {
            return ret_err(CONFD_ERR_PROTOUSAGE,
                           "Got ret CONFD_ERR allthough ok data reply "
                           "has already been sent on thandle:%d\n",
                           tctx->thandle);
        }
        else {
            confd_set_errno(CONFD_ERR_EXTERNAL);
            trans_reply_error(tctx);
            return CONFD_ERR;
        }
        break;
    case CONFD_VALIDATION_WARN:
        if (tctx->last_proto_op == CONFD_VALIDATE_VALUE) {
            trans_reply_warning(tctx);
            return CONFD_VALIDATION_WARN;
        }
        else {
            trans_reply_error_extended(tctx, CONFD_ERRCODE_PROTO_USAGE,
                                       0, 0, "invalid validation warning");
            return ret_err(CONFD_ERR_PROTOUSAGE, "Can only return warnings"
                           " from the validate cb");
        }
    default:
        ret_err(CONFD_ERR_PROTOUSAGE,
                "Bad return value: %d\n",retcode);
        if (tctx->seen_reply != 1)
            trans_reply_error_extended(tctx, CONFD_ERRCODE_PROTO_USAGE,
                                       0, 0, "Bad return value");
    }
    return CONFD_ERR;
}

static int nano_service_reply(struct confd_trans_ctx *tctx, int retcode,
                              struct ncs_name_value *proplist, int num_props)
{
    if (confd_debug_level >= CONFD_TRACE) {
        switch (retcode) {
        case CONFD_OK:
            confd_trace_printf(" --> CONFD_OK\n");
            break;
        case CONFD_ERR:
            confd_trace_printf(" --> CONFD_ERR\n");
            break;
        case CONFD_DELAYED_RESPONSE:
            confd_trace_printf(" --> CONFD_DELAYED_RESPONSE\n");
            break;
        default:
            confd_trace_printf(" --> BADRETVAL\n");
        }
    }

    switch (retcode) {
    case CONFD_DELAYED_RESPONSE:
        return CONFD_DELAYED_RESPONSE;
    case CONFD_OK:
        if (tctx->seen_reply == 1) {
            return CONFD_OK;
        } else {
            return ncs_service_reply_proplist(tctx, proplist, num_props);
        }
        break;
    case CONFD_ERR:
        if (tctx->seen_reply == 1) {
            return ret_err(CONFD_ERR_PROTOUSAGE,
                           "Got ret CONFD_ERR allthough ok data reply "
                           "has already been sent on thandle:%d\n",
                           tctx->thandle);
        } else {
            confd_set_errno(CONFD_ERR_EXTERNAL);
            trans_reply_error(tctx);
            return CONFD_ERR;
        }
        break;
    default:
        ret_err(CONFD_ERR_PROTOUSAGE,
                "Bad return value: %d\n",retcode);
        if (tctx->seen_reply != 1)
            trans_reply_error_extended(tctx, CONFD_ERRCODE_PROTO_USAGE,
                                       0, 0, "Bad return value");
    }
    return CONFD_ERR;
}

static int service_reply(struct confd_trans_ctx *tctx, int retcode,
                         struct ncs_name_value *proplist, int num_props)
{
    if (confd_debug_level >= CONFD_TRACE) {
        switch (retcode) {
        case CONFD_OK:
            confd_trace_printf(" --> CONFD_OK\n");
            break;
        case CONFD_ERR:
            confd_trace_printf(" --> CONFD_ERR\n");
            break;
        case CONFD_DELAYED_RESPONSE:
            confd_trace_printf(" --> CONFD_DELAYED_RESPONSE\n");
            break;
        default:
            confd_trace_printf(" --> BADRETVAL\n");
        }
    }

    switch (retcode) {
    case CONFD_DELAYED_RESPONSE:
        return CONFD_DELAYED_RESPONSE;
    case CONFD_OK:
        if (tctx->seen_reply == 1) {
            return CONFD_OK;
        } else {
            return ncs_service_reply_proplist(tctx, proplist, num_props);
        }
        break;
    case CONFD_ERR:
        if (tctx->seen_reply == 1) {
            return ret_err(CONFD_ERR_PROTOUSAGE,
                           "Got ret CONFD_ERR allthough ok data reply "
                           "has already been sent on thandle:%d\n",
                           tctx->thandle);
        } else {
            confd_set_errno(CONFD_ERR_EXTERNAL);
            trans_reply_error(tctx);
            return CONFD_ERR;
        }
        break;
    default:
        ret_err(CONFD_ERR_PROTOUSAGE,
                "Bad return value: %d\n",retcode);
        if (tctx->seen_reply != 1)
            trans_reply_error_extended(tctx, CONFD_ERRCODE_PROTO_USAGE,
                                       0, 0, "Bad return value");
    }
    return CONFD_ERR;
}

static int bad_cb_reply(struct confd_trans_ctx *tctx, int retval,
                        const char *fmt, ...)
{
    char buf[BUFSIZ];
    va_list args;
    enum confd_errcode errcode;

    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    confd_trace(CONFD_DEBUG, "%s\n", buf);
    if (confd_debug_level >= CONFD_TRACE)
        confd_trace_printf(" --> CONFD_ERR\n");
    if (retval == CONFD_ERR_PROTOUSAGE)
        errcode = CONFD_ERRCODE_PROTO_USAGE;
    else
        errcode = CONFD_ERRCODE_INTERNAL;
    trans_reply_error_extended(tctx, errcode, 0, 0, "%s", buf);
    return ret_err(retval, "%s", buf);
}


int confd_db_set_timeout(struct confd_db_ctx *dbx, int timeout_secs)
{
    ETERM *retarr[4], *rterm;
    int retval;

    retarr[0] = erl_mk_int(CONFD_PROTO_DAEMON_TIMEOUT);
    retarr[1] = erl_mk_int(dbx->qref);
    retarr[2] = erl_mk_int(dbx->did);
    retarr[3] = erl_mk_int(timeout_secs);
    rterm = erl_mk_tuple(retarr, 4);
    retval = term_write(dbx->dx->ctl_sock, rterm, -1, -1);
    erl_free_compound(rterm);
    return retval;
}

static int db_reply(struct confd_db_ctx *dbx,int retcode) {
    int ret, tupsz;
    ETERM *tup;
    ETERM *a[5];
    a[0] = erl_mk_int(CONFD_PROTO_DB_REPLY);
    a[1] = erl_mk_int(dbx->qref);
    a[2] = erl_mk_int(dbx->did);


    if (confd_debug_level >= CONFD_TRACE) {
        switch (retcode) {
        case CONFD_OK:
            confd_trace_printf(" --> CONFD_OK\n");
            break;
        case CONFD_ERR:
            confd_trace_printf(" --> CONFD_ERR\n");
            break;
        default:
            confd_trace_printf("--> UNKNOWN\n");
        }
    }

    if (dbx->uinfo != NULL)
        put_user_session(dbx->dx, dbx->uinfo);

    switch (retcode) {
    case CONFD_OK:
        free_error(&dbx->error);
        a[3] = erl_mk_atom("ok");
        tupsz = 4;
        break;
    case CONFD_ERR:
        a[3] = erl_mk_atom("error");
        a[4] = _confd_make_error(&dbx->error);
        tupsz = 5;
        confd_set_errno(CONFD_ERR_EXTERNAL);
        break;
    default:
        ret_err(CONFD_ERR_PROTOUSAGE, "Bad return value: %d\n",retcode);
        confd_db_seterr_extended(dbx, CONFD_ERRCODE_PROTO_USAGE,
                                 0, 0, "badretval");
        a[3] = erl_mk_atom("error");
        a[4] = _confd_make_error(&dbx->error);
        tupsz = 5;
    }
    if ((tup = erl_mk_tuple(a, tupsz)) == NULL) {
        confd_set_errno(CONFD_ERR_MALLOC);
        return CONFD_ERR;
    }
    ret = term_write(dbx->dx->ctl_sock, tup, -1, -1);
    erl_free_compound(tup);
    if (retcode == CONFD_OK)
        return ret;
    return retcode;
}


static void strip_cb_flag_filtered(struct confd_trans_ctx *tctx)
{
    if (tctx->list_filter == NULL &&
        tctx->cb_flags & CONFD_TRANS_CB_FLAG_FILTERED) {
        tctx->cb_flags &= ~CONFD_TRANS_CB_FLAG_FILTERED;
    }
}

/* The get_next() callback needs to return 2 values */
/* The actual key value(s) as well as the next integer to */
/* be passed as input to the get_next() callback */

int confd_data_reply_next_key(struct confd_trans_ctx *tctx,
                              const confd_value_t *v,
                              int num_vals_in_key,
                              long next)
{

    ETERM *retval;
    ETERM *a2[2];
    ETERM *nexttup[2];

    if (tctx->in_num_instances) {
        /* we're doing a num_instances through get_next */
        if (v == NULL) {
            confd_value_t v;
            v.type = C_INT32;
            v.val.i32 = tctx->num_instances;
            tctx->in_num_instances = 0; /* mark that we're done */
            if (tctx->next_kp != NULL) {
                confd_free_hkeypath(tctx->next_kp);
                tctx->next_kp = NULL;
            }
            tctx->next_dcb = NULL;
            return intern_confd_data_reply_value(tctx, &v);
        }
        else {
            tctx->num_instances++;
            tctx->nextarg = next;
            if (tctx->in_num_instances == 2) {
                int retv = CONFD_OK; /* init to avoid buggy gcc warning */
                /* this is a reply after CONFD_DELAYED_RESPONSE
                   - we need to continue invocation */
                tctx->in_num_instances = 1;
                while (tctx->in_num_instances == 1) {
                    retv = tctx->next_dcb->get_next(tctx, tctx->next_kp,
                                                    tctx->nextarg);
                    switch (retv) {
                    case CONFD_OK:
                        break;
                    case CONFD_DELAYED_RESPONSE:
                        tctx->in_num_instances = 2;
                        break;
                    default:
                        retv = proto_reply(tctx, 0, CONFD_ERR);
                        tctx->in_num_instances = 0;
                    }
                }
                return retv;
            }
            return CONFD_OK;
        }
    }

    clr_confd_err();
    if ((tctx->last_proto_op !=  CONFD_DATA_CB_GET_NEXT) &&
        (tctx->last_proto_op != CONFD_DATA_CB_FIND_NEXT) &&
        /* contrary to documentation, we allow get_next_object/find_next_object
           here (but only for the end-of-list case), for "historical reasons" */
        ((tctx->last_proto_op != CONFD_DATA_CB_GET_NEXT_OBJECT &&
          tctx->last_proto_op != CONFD_DATA_CB_FIND_NEXT_OBJECT) || v != NULL))
        return proto_cb_err();
    if (v == NULL) {
        return trans_reply_callback(tctx, erl_mk_atom("false"));
    }

    a2[1] = vals_to_termlist(v, num_vals_in_key, 1);
    if (a2[1] == NULL) {
        return CONFD_ERR;
    }

    strip_cb_flag_filtered(tctx);
    nexttup[0] = erl_mk_int(tctx->traversal_id);
    nexttup[1] = erl_mk_longlong((long long)next);
    if (tctx->cb_flags & CONFD_TRANS_CB_FLAG_FILTERED) {
        ETERM *tup[2];
        tctx->cb_flags &= ~CONFD_TRANS_CB_FLAG_FILTERED;
        tup[0] = erl_mk_atom("filtered");
        tup[1] = erl_mk_tuple(nexttup, 2);
        a2[0] = erl_mk_tuple(tup, 2);
    } else {
        a2[0] = erl_mk_tuple(nexttup, 2);
    }
    retval = erl_mk_tuple(a2, 2);
    return trans_reply_callback(tctx, retval);
}

int confd_data_reply_next_key_attrs(struct confd_trans_ctx *tctx,
                                    const confd_value_t *v,
                                    int num_vals_in_key,
                                    long next,
                                    const confd_attr_value_t *attrs,
                                    int num_attrs)
{
    ETERM *reply[3];
    ETERM *nexttup[2];

    clr_confd_err();
    if (tctx->last_proto_op != CONFD_DATA_CB_GET_NEXT)
        return proto_cb_err();

    reply[1] = vals_to_termlist(v, num_vals_in_key, 1);
    if (reply[1] == NULL) {
        return CONFD_ERR;
    }

    strip_cb_flag_filtered(tctx);
    nexttup[0] = erl_mk_int(tctx->traversal_id);
    nexttup[1] = erl_mk_longlong((long long)next);
    if (tctx->cb_flags & CONFD_TRANS_CB_FLAG_FILTERED) {
        ETERM *tup[2];
        tctx->cb_flags &= ~CONFD_TRANS_CB_FLAG_FILTERED;
        tup[0] = erl_mk_atom("filtered");
        tup[1] = erl_mk_tuple(nexttup, 2);
        reply[0] = erl_mk_tuple(tup, 2);
    } else {
        reply[0] = erl_mk_tuple(nexttup, 2);
    }

    if ((reply[2] = attr_to_term(attrs, num_attrs)) == NULL) {
        return CONFD_ERR;
    }

    return trans_reply_callback(tctx, erl_mk_tuple(reply, 3));
}

int confd_data_reply_value_array(struct confd_trans_ctx *tctx,
                                 const confd_value_t *v, int n)
{
    ETERM *reply;

    clr_confd_err();
    if (tctx->last_proto_op != CONFD_DATA_CB_GET_OBJECT)
        return proto_cb_err();
    if ((reply = vals_to_termlist(v, n, 0)) == NULL)
        return CONFD_ERR;
    return trans_reply_callback(tctx, reply);
}

int confd_data_reply_tag_value_array(struct confd_trans_ctx *tctx,
                                     const confd_tag_value_t *tv, int n)
{
    ETERM *tup[2];

    clr_confd_err();
    if (tctx->last_proto_op != CONFD_DATA_CB_GET_OBJECT)
        return proto_cb_err();
    if ((tup[1] = tag_vals_to_termlist(tv, n, 0)) == NULL)
        return CONFD_ERR;
    tup[0] = erl_mk_atom("hxml");
    return trans_reply_callback(tctx, erl_mk_tuple(tup, 2));
}

int confd_data_reply_tag_value_attrs_array(struct confd_trans_ctx *tctx,
                                           const confd_tag_value_attr_t *tva,
                                           int n)
{
    ETERM *tup[2];

    clr_confd_err();
    if (tctx->last_proto_op != CONFD_DATA_CB_GET_OBJECT)
        return proto_cb_err();
    if ((tup[1] = tag_vals_attrs_to_termlist(tva, n, 0)) == NULL)
        return CONFD_ERR;
    tup[0] = erl_mk_atom("hxml");
    return trans_reply_callback(tctx, erl_mk_tuple(tup, 2));
}

static int mk_next_object(struct confd_trans_ctx *tctx,
                          const confd_value_t *v, int n, long next,
                          ETERM **object)
{
    ETERM *tup[2], *nexttup[2];

    if (v == NULL) {
        *object = erl_mk_atom("false");
        return 1;
    }
    if ((tup[1] = vals_to_termlist(v, n, 0)) == NULL)
        return -1;
    nexttup[0] = erl_mk_int(tctx->traversal_id);
    nexttup[1] = erl_mk_longlong((long long)next);
    if (tctx->cb_flags & CONFD_TRANS_CB_FLAG_FILTERED) {
        ETERM *tup1[2];
        tctx->cb_flags &= ~CONFD_TRANS_CB_FLAG_FILTERED;
        tup1[0] = erl_mk_atom("filtered");
        tup1[1] = erl_mk_tuple(nexttup, 2);
        tup[0] = erl_mk_tuple(tup1, 2);
    } else {
        tup[0] = erl_mk_tuple(nexttup, 2);
    }
    *object = erl_mk_tuple(tup, 2);
    return 0;
}

static int mk_tag_next_object(struct confd_trans_ctx *tctx,
                              const confd_tag_value_t *tv, int n, long next,
                              ETERM **object)
{
    ETERM *tup0[2], *tup[2], *nexttup[2];

    if (tv == NULL) {
        *object = erl_mk_atom("false");
        return 1;
    }
    if ((tup0[1] = tag_vals_to_termlist(tv, n, 0)) == NULL)
        return -1;
    tup0[0] = erl_mk_atom("hxml");
    nexttup[0] = erl_mk_int(tctx->traversal_id);
    nexttup[1] = erl_mk_longlong((long long)next);
    if (tctx->cb_flags & CONFD_TRANS_CB_FLAG_FILTERED) {
        ETERM *tup1[2];
        tctx->cb_flags &= ~CONFD_TRANS_CB_FLAG_FILTERED;
        tup1[0] = erl_mk_atom("filtered");
        tup1[1] = erl_mk_tuple(nexttup, 2);
        tup[0] = erl_mk_tuple(tup1, 2);
    } else {
        tup[0] = erl_mk_tuple(nexttup, 2);
    }
    tup[1] = erl_mk_tuple(tup0, 2);
    *object = erl_mk_tuple(tup, 2);
    return 0;
}

static int mk_tag_next_object_attrs(struct confd_trans_ctx *tctx,
                                    const confd_tag_value_attr_t *tva,
                                    int n, long next,
                                    ETERM **object)
{
    ETERM *tup0[2], *tup[2], *nexttup[2];

    if (tva == NULL) {
        *object = erl_mk_atom("false");
        return 1;
    }
    if ((tup0[1] = tag_vals_attrs_to_termlist(tva, n, 0)) == NULL)
        return CONFD_ERR;
    tup0[0] = erl_mk_atom("hxml");
    nexttup[0] = erl_mk_int(tctx->traversal_id);
    nexttup[1] = erl_mk_longlong((long long)next);
    if (tctx->cb_flags & CONFD_TRANS_CB_FLAG_FILTERED) {
        ETERM *tup1[2];
        tctx->cb_flags &= ~CONFD_TRANS_CB_FLAG_FILTERED;
        tup1[0] = erl_mk_atom("filtered");
        tup1[1] = erl_mk_tuple(nexttup, 2);
        tup[0] = erl_mk_tuple(tup1, 2);
    } else {
        tup[0] = erl_mk_tuple(nexttup, 2);
    }
    tup[1] = erl_mk_tuple(tup0, 2);
    *object = erl_mk_tuple(tup, 2);
    return 0;
}

int confd_data_reply_next_object_array(struct confd_trans_ctx *tctx,
                                       const confd_value_t *v, int n,
                                       long next)
{
    ETERM *reply;

    clr_confd_err();
    if (tctx->last_proto_op != CONFD_DATA_CB_GET_NEXT_OBJECT &&
        tctx->last_proto_op != CONFD_DATA_CB_FIND_NEXT_OBJECT)
        return proto_cb_err();
    strip_cb_flag_filtered(tctx);
    if (mk_next_object(tctx, v, n, next, &reply) < 0)
        return CONFD_ERR;
    return trans_reply_callback(tctx, reply);
}

int confd_data_reply_next_object_tag_value_array(
    struct confd_trans_ctx *tctx,
    const confd_tag_value_t *tv, int n,
    long next)
{
    ETERM *reply;

    clr_confd_err();
    if (tctx->last_proto_op != CONFD_DATA_CB_GET_NEXT_OBJECT &&
        tctx->last_proto_op != CONFD_DATA_CB_FIND_NEXT_OBJECT)
        return proto_cb_err();
    strip_cb_flag_filtered(tctx);
    if (mk_tag_next_object(tctx, tv, n, next, &reply) < 0)
        return CONFD_ERR;
    return trans_reply_callback(tctx, reply);
}

int confd_data_reply_next_object_tag_value_attrs_array(
    struct confd_trans_ctx *tctx,
    const confd_tag_value_attr_t *tva,
    int n, long next)
{
    ETERM *reply;

    clr_confd_err();
    if (tctx->last_proto_op != CONFD_DATA_CB_GET_NEXT_OBJECT &&
        tctx->last_proto_op != CONFD_DATA_CB_FIND_NEXT_OBJECT)
        return proto_cb_err();
    strip_cb_flag_filtered(tctx);
    if (mk_tag_next_object_attrs(tctx, tva, n, next, &reply) < 0)
        return CONFD_ERR;
    return trans_reply_callback(tctx, reply);
}

int confd_data_reply_next_object_arrays(
    struct confd_trans_ctx *tctx,
    const struct confd_next_object *obj,
    int nobj, int timeout_millisecs)
{
    ETERM *tup[2], *olist[nobj];
    int i;

    clr_confd_err();
    if (tctx->last_proto_op != CONFD_DATA_CB_GET_NEXT_OBJECT &&
        tctx->last_proto_op != CONFD_DATA_CB_FIND_NEXT_OBJECT)
        return proto_cb_err();

    strip_cb_flag_filtered(tctx);
    if (obj == NULL) {
        return trans_reply_callback(tctx, erl_mk_atom("false"));
    }

    if (nobj == 0) {
        return ret_err(CONFD_ERR_PROTOUSAGE, "Cannot return 0 objects");
    }

    /* cheap test to catch all 'next' being the same */
    if (nobj > 1 && obj[1].v != NULL && obj[1].next != -1 &&
        obj[0].next == obj[1].next) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "'next' values must be either unique or -1");
    }
    for (i = 0; i < nobj; i++) {
        switch (mk_next_object(tctx, obj[i].v, obj[i].n,
                               obj[i].next, &olist[i])) {
        case 0:
            break;
        case 1:
            if (i == nobj - 1)
                break;
            ret_err(CONFD_ERR_PROTOUSAGE,
                    "Non-last element obj[%d] has v == NULL", i);
            i++;
            /* fall through */
        default:
            for (i-- ; i >= 0; i--)
                erl_free_compound(olist[i]);
            return CONFD_ERR;
        }
    }
    tup[0] = erl_mk_list(olist, nobj);
    tup[1] = erl_mk_int(timeout_millisecs);
    return trans_reply_callback(tctx, erl_mk_tuple(tup, 2));
}

int confd_data_reply_next_object_tag_value_arrays(
    struct confd_trans_ctx *tctx,
    const struct confd_tag_next_object *tobj,
    int nobj, int timeout_millisecs)
{
    ETERM *tup[2], *olist[nobj];
    int i;

    clr_confd_err();
    if (tctx->last_proto_op != CONFD_DATA_CB_GET_NEXT_OBJECT &&
        tctx->last_proto_op != CONFD_DATA_CB_FIND_NEXT_OBJECT)
        return proto_cb_err();

    if (tobj == NULL) {
        return trans_reply_callback(tctx, erl_mk_atom("false"));
    }

    if (nobj == 0) {
        return ret_err(CONFD_ERR_PROTOUSAGE, "Cannot return 0 objects");
    }

    /* cheap test to catch all 'next' being the same */
    strip_cb_flag_filtered(tctx);
    if (nobj > 1 && tobj[1].tv != NULL && tobj[1].next != -1 &&
        tobj[0].next == tobj[1].next) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "'next' values must be either unique or -1");
    }
    for (i = 0; i < nobj; i++) {
        switch (mk_tag_next_object(tctx, tobj[i].tv, tobj[i].n, tobj[i].next,
                                   &olist[i])) {
        case 0:
            break;
        case 1:
            if (i == nobj - 1)
                break;
            ret_err(CONFD_ERR_PROTOUSAGE,
                    "Non-last element tobj[%d] has tv == NULL", i);
            i++;
            /* fall through */
        default:
            for (i-- ; i >= 0; i--)
                erl_free_compound(olist[i]);
            return CONFD_ERR;
        }
    }
    tup[0] = erl_mk_list(olist, nobj);
    tup[1] = erl_mk_int(timeout_millisecs);
    return trans_reply_callback(tctx, erl_mk_tuple(tup, 2));
}

int confd_data_reply_next_object_tag_value_attrs_arrays(
    struct confd_trans_ctx *tctx,
    const struct confd_tag_next_object_attrs *toa,
    int nobj, int timeout_millisecs)
{
    ETERM *tup[2], *olist[nobj];
    int i;

    clr_confd_err();
    if (tctx->last_proto_op != CONFD_DATA_CB_GET_NEXT_OBJECT &&
        tctx->last_proto_op != CONFD_DATA_CB_FIND_NEXT_OBJECT)
        return proto_cb_err();

    if (toa == NULL) {
        return trans_reply_callback(tctx, erl_mk_atom("false"));
    }

    if (nobj == 0) {
        return ret_err(CONFD_ERR_PROTOUSAGE, "Cannot return 0 objects");
    }

    /* cheap test to catch all 'next' being the same */
    strip_cb_flag_filtered(tctx);
    if (nobj > 1 && toa[1].tva != NULL && toa[1].next != -1 &&
        toa[0].next == toa[1].next) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "'next' values must be either unique or -1");
    }
    for (i = 0; i < nobj; i++) {
        switch (mk_tag_next_object_attrs(tctx, toa[i].tva, toa[i].n,
                                         toa[i].next, &olist[i])) {
        case 0:
            break;
        case 1:
            if (i == nobj - 1)
                break;
            ret_err(CONFD_ERR_PROTOUSAGE,
                    "Non-last element toa[%d] has tv == NULL", i);
            i++;
            /* fall through */
        default:
            for (i-- ; i >= 0; i--)
                erl_free_compound(olist[i]);
            return CONFD_ERR;
        }
    }
    tup[0] = erl_mk_list(olist, nobj);
    tup[1] = erl_mk_int(timeout_millisecs);
    return trans_reply_callback(tctx, erl_mk_tuple(tup, 2));
}

int ncs_service_reply_proplist(struct confd_trans_ctx *tctx,
                               const struct ncs_name_value *proplist,
                               int num_props)
{
    ETERM *tl[num_props], *list;
    int i;

    for (i = 0; i < num_props; i++) {
        ETERM *tup[2];
        tup[0] = erl_mk_atom(proplist[i].name);
        tup[1] = erl_mk_binary(proplist[i].value, strlen(proplist[i].value));
        tl[i] = erl_mk_tuple(tup, 2);
    }
    if ((list = erl_mk_list(tl, num_props)) == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
    }
    return trans_reply_callback(tctx, list);
}

int ncs_nano_service_reply_proplist(struct confd_trans_ctx *tctx,
                                    const struct ncs_name_value *proplist,
                                    int num_props)
{
    return ncs_service_reply_proplist(tctx, proplist, num_props);
}

static int action_reply(struct confd_user_info *uinfo, ETERM *rterm)
{
    struct confd_action_ctx *actx = &uinfo->actx;
    int fd, ret;

    free_error(&actx->error);
    PTHREAD_MUTEX_LOCK(actx->dx->slock);
    if (actx->state == ACT_STATE_DELAYED) {
        actx->state = ACT_STATE_NONE;
        PTHREAD_MUTEX_UNLOCK(actx->dx->slock);
        fd = actx->fd;
        ret = term_write(fd, rterm, -1, -1);
        erl_free_compound(rterm);
        put_user_session(actx->dx, uinfo);
    } else {
        PTHREAD_MUTEX_UNLOCK(actx->dx->slock);
        /* send reply when callback returns */
        actx->rterm = rterm;
        ret = CONFD_OK;
    }
    return ret;
}

int confd_action_reply_values(struct confd_user_info *uinfo,
                              confd_tag_value_t *values, int nvals)
{
    struct confd_action_ctx *actx = &uinfo->actx;
    ETERM *tup[2], *retarr[4], *rterm;

    clr_confd_err();
    if (actx->last_op != CONFD_CALL_ACTION) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "confd_action_reply_values() only allowed "
                       "for action() callback");
    }
    if (actx->seen_reply) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Duplicate call of confd_action_reply_values()");
    }
    actx->seen_reply = 1;
    if ((tup[1] = tag_vals_to_termlist(values, nvals, 0)) == NULL) {
        return CONFD_ERR;
    }
    tup[0] = erl_mk_atom("hxml");

    /* Construct reply tuple */
    retarr[0] = erl_mk_int(CONFD_PROTO_CALLBACK);
    retarr[1] = erl_mk_int(actx->query_ref);
    retarr[2] = erl_mk_int(actx->dx->daemon_id);
    retarr[3] = erl_mk_tuple(tup, 2);
    rterm = erl_mk_tuple(retarr, 4);
    return action_reply(uinfo, rterm);
}

int confd_action_reply_command(struct confd_user_info *uinfo,
                               char **values, int nvals)
{
    struct confd_action_ctx *actx = &uinfo->actx;
    ETERM **arr, *retarr[4], *rterm;
    int i;

    clr_confd_err();
    if (actx->last_op != CONFD_CALL_ACTION_COMMAND) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "confd_action_reply_command() only allowed "
                       "for command() callback");
    }
    if (actx->seen_reply) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Duplicate call of confd_action_reply_command()");
    }
    /* Don't change this to stack allocation - is heap on customer request */
    if ((arr = confd_malloc(nvals * sizeof(ETERM *))) == NULL)
        return CONFD_ERR;
    actx->seen_reply = 1;
    for (i = 0; i < nvals; i++)
        arr[i] = erl_mk_binary(values[i], strlen(values[i]));

    /* Construct reply tuple */
    retarr[0] = erl_mk_int(CONFD_PROTO_CALLBACK);
    retarr[1] = erl_mk_int(actx->query_ref);
    retarr[2] = erl_mk_int(actx->dx->daemon_id);
    retarr[3] = erl_mk_list(arr, nvals);
    rterm = erl_mk_tuple(retarr, 4);
    free(arr);
    return action_reply(uinfo, rterm);
}

int confd_action_reply_rewrite(struct confd_user_info *uinfo,
                               char **values, int nvals,
                               char **unhides, int nunhides)
{
    struct confd_action_ctx *actx = &uinfo->actx;
    ETERM **arr, *retarr[4], *rterm;
    int i, x;

    clr_confd_err();
    if (actx->last_op != CONFD_CALL_ACTION_COMMAND) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "confd_action_reply_rewrite() only allowed "
                       "for command() callback");
    }
    if (actx->seen_reply) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Duplicate call of confd_action_reply_rewrite()");
    }
    /* Don't change this to stack allocation - is heap on customer request */
    if ((arr = confd_malloc((nvals+nunhides+3) * sizeof(ETERM *))) == NULL)
        return CONFD_ERR;
    actx->seen_reply = 1;
    x = 0;
    arr[x++] = erl_mk_int(nvals);
    for (i = 0; i < nvals; i++)
        arr[x++] = erl_mk_binary(values[i], strlen(values[i]));

    arr[x++] = erl_mk_int(nunhides);
    for (i = 0; i < nunhides; i++)
        arr[x++] = erl_mk_binary(unhides[i], strlen(unhides[i]));

    arr[x++] = erl_mk_int(0);

    /* Construct reply tuple */
    retarr[0] = erl_mk_int(CONFD_PROTO_CALLBACK);
    retarr[1] = erl_mk_int(actx->query_ref);
    retarr[2] = erl_mk_int(actx->dx->daemon_id);
    retarr[3] = erl_mk_list(arr, nvals+nunhides+3);
    rterm = erl_mk_tuple(retarr, 4);
    free(arr);
    return action_reply(uinfo, rterm);
}

int confd_action_reply_rewrite2(struct confd_user_info *uinfo,
                                char **values, int nvals,
                                char **unhides, int nunhides,
                                struct confd_rewrite_select **selects,
                                int nselects)
{
    struct confd_action_ctx *actx = &uinfo->actx;
    int i, x, size;
    ETERM **arr, *retarr[4], *rterm;

    size = nvals+nunhides+3;
    for(i=0 ; i < nselects ; i++) {
        size += 1+selects[i]->n;
    }

    clr_confd_err();
    if (actx->last_op != CONFD_CALL_ACTION_COMMAND) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "confd_action_reply_rewrite() only allowed "
                       "for command() callback");
    }
    if (actx->seen_reply) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Duplicate call of confd_action_reply_rewrite()");
    }
    /* Don't change this to stack allocation - is heap on customer request */
    if ((arr = confd_malloc((size) * sizeof(ETERM *))) == NULL)
        return CONFD_ERR;
    actx->seen_reply = 1;

    x = 0;
    arr[x++] = erl_mk_int(nvals);
    for (i = 0; i < nvals; i++)
        arr[x++] = erl_mk_binary(values[i], strlen(values[i]));

    arr[x++] = erl_mk_int(nunhides);
    for (i = 0; i < nunhides; i++)
        arr[x++] = erl_mk_binary(unhides[i], strlen(unhides[i]));

    arr[x++] = erl_mk_int(nselects);
    for (i = 0; i < nselects; i++) {
        int t;
        struct confd_rewrite_select *s = selects[i];

        arr[x++] = erl_mk_int(s->n);
        for(t = 0; t < s->n; t++)
            arr[x++] = erl_mk_binary(s->tokens[t], strlen(s->tokens[t]));
    }

    /* Construct reply tuple */
    retarr[0] = erl_mk_int(CONFD_PROTO_CALLBACK);
    retarr[1] = erl_mk_int(actx->query_ref);
    retarr[2] = erl_mk_int(actx->dx->daemon_id);
    retarr[3] = erl_mk_list(arr, size);
    rterm = erl_mk_tuple(retarr, 4);
    free(arr);
    return action_reply(uinfo, rterm);
}

int confd_action_reply_completion(struct confd_user_info *uinfo,
                                  struct confd_completion_value *values,
                                  int nvals)
{
    struct confd_action_ctx *actx = &uinfo->actx;
    ETERM **arr, *retarr[4], *rterm;
    ETERM *tup[3];
    int i;

    clr_confd_err();
    if (actx->last_op != CONFD_CALL_ACTION_COMPLETION) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "confd_action_reply_completion() only allowed "
                       "for completion() callback");
    }
    if (actx->seen_reply) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Duplicate call of confd_action_reply_completion()");
    }
    /* Don't change this to stack allocation - is heap on customer request */
    if ((arr = confd_malloc(nvals * sizeof(ETERM *))) == NULL)
        return CONFD_ERR;
    actx->seen_reply = 1;
    for (i = 0; i < nvals; i++) {
        switch (values[i].type) {
        case CONFD_COMPLETION:
            tup[0] = erl_mk_int('C');
            tup[1] = erl_mk_binary(values[i].value, strlen(values[i].value));
            if (values[i].extra != NULL)
                tup[2] = erl_mk_binary(values[i].extra,strlen(values[i].extra));
            else
                tup[2] = erl_mk_binary("", 0);
            arr[i] = erl_mk_tuple(tup, 3);
            break;
        case CONFD_COMPLETION_INFO:
            tup[0] = erl_mk_int('I');
            tup[1] = erl_mk_binary(values[i].value, strlen(values[i].value));
            arr[i] = erl_mk_tuple(tup, 2);
            break;
        case CONFD_COMPLETION_DESC:
            tup[0] = erl_mk_int('D');
            tup[1] = erl_mk_binary(values[i].value, strlen(values[i].value));
            arr[i] = erl_mk_tuple(tup, 2);
            break;
        case CONFD_COMPLETION_DEFAULT:
            arr[i] = erl_mk_int('U');
            break;
        }
    }

    /* Construct reply tuple */
    retarr[0] = erl_mk_int(CONFD_PROTO_CALLBACK);
    retarr[1] = erl_mk_int(actx->query_ref);
    retarr[2] = erl_mk_int(actx->dx->daemon_id);
    retarr[3] = erl_mk_list(arr, nvals);
    rterm = erl_mk_tuple(retarr, 4);
    free(arr);
    return action_reply(uinfo, rterm);
}


int confd_action_reply_range_enum(struct confd_user_info *uinfo,
                                  char **values, int keysize, int nkeys)
{
    struct confd_action_ctx *actx = &uinfo->actx;
    int i, x, size;
    ETERM **arr, *retarr[4], *rterm;

    size = nkeys*keysize+2;

    clr_confd_err();
    if (actx->last_op != CONFD_CALL_ACTION_COMPLETION) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "confd_action_reply_enum() only allowed "
                       "for command() callback");
    }
    if (actx->seen_reply) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Duplicate call of confd_action_reply_enum()");
    }
    /* Don't change this to stack allocation - is heap on customer request */
    if ((arr = confd_malloc(size * sizeof(ETERM *))) == NULL)
        return CONFD_ERR;
    actx->seen_reply = 1;
    x = 0;
    arr[x++] = erl_mk_int(keysize);
    arr[x++] = erl_mk_int(nkeys);

    for (i = 0; i < nkeys*keysize; i++)
        arr[x++] = erl_mk_binary(values[i], strlen(values[i]));

    /* Construct reply tuple */
    retarr[0] = erl_mk_int(CONFD_PROTO_CALLBACK);
    retarr[1] = erl_mk_int(actx->query_ref);
    retarr[2] = erl_mk_int(actx->dx->daemon_id);
    retarr[3] = erl_mk_list(arr, size);
    rterm = erl_mk_tuple(retarr, 4);
    free(arr);
    return action_reply(uinfo, rterm);
}

int confd_notification_reply_log_times(
    struct confd_notification_ctx *nctx,
    struct confd_datetime *creation,
    struct confd_datetime *aged)
{
    confd_value_t creationv, agedv;
    ETERM *retarr[5], *rterm;
    int ret;

    clr_confd_err();
    if (nctx->seen_reply) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Duplicate call of "
                       "confd_notification_reply_log_times()");
    }
    nctx->seen_reply = 1;
    creationv.type = C_DATETIME;
    creationv.val.datetime = *creation;
    if (aged != NULL) {
        agedv.type = C_DATETIME;
        agedv.val.datetime = *aged;
    } else {
        agedv.type = C_NOEXISTS;
    }
    /* Construct reply tuple */
    retarr[0] = erl_mk_int(CONFD_PROTO_NOTIF_GET_LOG_TIMES);
    retarr[1] = erl_mk_int(nctx->query_ref);
    retarr[2] = erl_mk_int(nctx->dx->daemon_id);
    retarr[3] = val_to_term(&creationv);
    retarr[4] = val_to_term(&agedv);
    rterm = erl_mk_tuple(retarr, 5);
    free_error(&nctx->error);
    ret = term_write(nctx->dx->ctl_sock, rterm, -1, -1);
    erl_free_compound(rterm);
    return ret;
}

void confd_notification_set_fd(
    struct confd_notification_ctx *nctx, int fd)
{
    nctx->fd = fd;
}

void confd_notification_set_snmp_src_addr(struct confd_notification_ctx *nctx,
                                          const struct confd_ip *src_addr)
{
    nctx->src_addr = *src_addr;
}

int confd_notification_set_snmp_notify_name(
    struct confd_notification_ctx *nctx,
    const char *notify_name)
{
    char *new_name;

    if (notify_name == NULL)
        new_name = strdup("");
    else
        new_name = strdup(notify_name);
    if (new_name == NULL)
        return ret_err(CONFD_ERR_MALLOC, "Failed to allocate\n");
    if (nctx->name != NULL)
        free(nctx->name);
    nctx->name = new_name;
    return CONFD_OK;
}

static int notif_send(struct confd_notification_ctx *nctx,
                      struct confd_datetime *time,
                      confd_tag_value_t *values, int nvalues,
                      ETERM *epath)
{
    ETERM *tup[2], *arr[7], *term;
    confd_value_t timev;
    char idbuf[32];
    int ret;

    if ((tup[1] = tag_vals_to_termlist(values, nvalues, 0)) == NULL) {
        return CONFD_ERR;
    }
    timev.type = C_DATETIME;
    timev.val.datetime = *time;
    tup[0] = erl_mk_atom("hxml");
    arr[0] = erl_mk_int(CONFD_PROTO_NOTIF_SEND);
    arr[1] = erl_mk_atom(nctx->name);
    if (nctx->subid == 0) {
        arr[2] = erl_mk_atom("undefined");
        idbuf[0] = '\0';
    } else {
        arr[2] = erl_mk_int(nctx->subid);
        snprintf(idbuf, sizeof(idbuf), " (replay=%d)", nctx->subid);
    }
    arr[3] = val_to_term(&timev);
    arr[4] = erl_mk_int(nctx->flags);
    arr[5] = erl_mk_tuple(tup, 2);
    arr[6] = epath;
    term = erl_mk_tuple(arr, 7);
    confd_trace(CONFD_TRACE,
                "NOTIFICATION_SEND %s%s\n", nctx->name, idbuf);
    ret = term_write(nctx->fd, term, CONFD_PROTO_REQUEST, -1);
    erl_free_compound(term);
    return ret;
}

int confd_notification_send(struct confd_notification_ctx *nctx,
                            struct confd_datetime *time,
                            confd_tag_value_t *values, int nvalues)
{
    clr_confd_err();
    return notif_send(nctx, time, values, nvalues, erl_mk_empty_list());
}

int confd_notification_send_path(struct confd_notification_ctx *nctx,
                                 struct confd_datetime *time,
                                 confd_tag_value_t *values, int nvalues,
                                 const char *fmt, ...)
{
    ETERM *epath;
    int isrel;
    va_list args;

    clr_confd_err();
    va_start(args, fmt);
    epath = parse_path(&isrel, fmt, args);
    va_end(args);
    if (epath == NULL || isrel) {
        confd_set_errno(CONFD_ERR_BADPATH);
        return CONFD_ERR;
    }
    return notif_send(nctx, time, values, nvalues, epath);
}

static int notif_replay_complete2(
    struct confd_notification_ctx *nctx, int fd)
{
    ETERM *arr[6], *term;
    char *role;
    int ret;

    arr[0] = erl_mk_int(CONFD_PROTO_NOTIF_REPLAY_COMPLETE);
    arr[1] = erl_mk_atom(nctx->name);
    arr[2] = erl_mk_int(nctx->subid);
    arr[3] = erl_mk_int(nctx->dx->daemon_id);
    if (fd == nctx->fd) {
        role = "replay";
        arr[4] = erl_mk_int(nctx->live_fd);
    } else {
        role = "live";
        arr[4] = erl_mk_int(nctx->fd);
    }
    arr[5] = erl_mk_atom(role);
    term = erl_mk_tuple(arr, 6);
    confd_trace(CONFD_TRACE,
                "NOTIFICATION_REPLAY_COMPLETE %s (replay=%d, %s socket)\n",
                nctx->name, nctx->subid, role);
    ret = term_write(fd, term, CONFD_PROTO_REQUEST, -1);
    erl_free_compound(term);
    return ret;
}

int confd_notification_replay_complete(
    struct confd_notification_ctx *nctx)
{
    ETERM *arr[3], *term;
    int ret, ret2;

    clr_confd_err();
    if (nctx->fd == nctx->live_fd) {
        arr[0] = erl_mk_int(CONFD_PROTO_NOTIF_REPLAY_COMPLETE);
        arr[1] = erl_mk_atom(nctx->name);
        arr[2] = erl_mk_int(nctx->subid);
        term = erl_mk_tuple(arr, 3);
        confd_trace(CONFD_TRACE,
                    "NOTIFICATION_REPLAY_COMPLETE %s (replay=%d)\n",
                    nctx->name, nctx->subid);
        ret = term_write(nctx->fd, term, CONFD_PROTO_REQUEST, -1);
        erl_free_compound(term);
    } else {
        /* special replay_complete must be sent on both sockets */
        ret = notif_replay_complete2(nctx, nctx->fd);
        ret2 = notif_replay_complete2(nctx, nctx->live_fd);
        if (ret == CONFD_OK)
            ret = ret2;
    }
    /* ctx allocated at replay start */
    confd_notification_free_ctx(nctx);
    return ret;
}

int confd_notification_replay_failed(
    struct confd_notification_ctx *nctx)
{
    ETERM *arr[4], *term;
    int ret;

    clr_confd_err();
    arr[0] = erl_mk_int(CONFD_PROTO_NOTIF_REPLAY_FAILED);
    arr[1] = erl_mk_atom(nctx->name);
    arr[2] = erl_mk_int(nctx->subid);
    arr[3] = _confd_make_error(&nctx->error);
    term = erl_mk_tuple(arr, 4);
    confd_trace(CONFD_TRACE,
                "NOTIFICATION_REPLAY_FAILED %s (replay=%d)\n",
                nctx->name, nctx->subid);
    ret = term_write(nctx->fd, term, CONFD_PROTO_REQUEST, -1);
    erl_free_compound(term);
    /* ctx allocated at replay start */
    confd_notification_free_ctx(nctx);
    return ret;
}


static ETERM* encode_oid(struct confd_snmp_oid *op)
{
    ETERM *arr[op->len];
    int i;
    for (i=0; i<op->len; i++) {
        arr[i] = erl_mk_uint(op->oid[i]);
    }
    return erl_mk_list(arr, op->len);
}

int confd_notification_send_snmp(
    struct confd_notification_ctx *nctx, const char *notification,
    struct confd_snmp_varbind *varbinds, int num_vars)
{
    return confd_notification_send_snmp_inform(nctx, notification, varbinds,
                                               num_vars, NULL, 0);
}

int confd_notification_send_snmp_inform(
    struct confd_notification_ctx *nctx, const char *notification,
    struct confd_snmp_varbind *varbinds, int num_vars,
    const char *cb_id, int ref)
{
    ETERM *tup[3], *items[num_vars];
    ETERM *arr[8], *term;
    int i, ret;

    for (i=0; i<num_vars; i++) {
        struct confd_snmp_varbind *vb = varbinds + i;
        switch(vb->type) {
        case CONFD_SNMP_VARIABLE: {
            tup[0] = erl_mk_binary(vb->var.name,
                                   strlen(vb->var.name));
            if ((tup[1] = val_to_term(&vb->val)) == NULL)
                return CONFD_ERR;
            items[i] = erl_mk_tuple(tup,2);
            break;
        }
        case CONFD_SNMP_OID: {
            tup[0] = encode_oid(&vb->var.oid);
            if ((tup[1] = val_to_term(&vb->val))==NULL)
                return CONFD_ERR;
            items[i] = erl_mk_tuple(tup,2);
            break;
        }
        case CONFD_SNMP_COL_ROW: {
            tup[0] = erl_mk_binary(vb->var.cr.column,
                                   strlen(vb->var.cr.column));
            tup[1] = encode_oid(&vb->var.cr.rowindex);
            if ((tup[2] = val_to_term(&vb->val))==NULL)
                return CONFD_ERR;
            items[i] = erl_mk_tuple(tup,3);
            break;
        }
        default:
            return CONFD_ERR;
        }
    }
    arr[0] = erl_mk_int(CONFD_PROTO_NOTIF_SEND_SNMP);
    arr[1] = erl_mk_binary(nctx->name, strlen(nctx->name));
    arr[2] = erl_mk_binary(nctx->ctx_name, strlen(nctx->ctx_name));
    arr[3] = erl_mk_binary(notification, strlen(notification));
    arr[4] = erl_mk_int(nctx->flags);
    arr[5] = erl_mk_list(items, num_vars);
    if (cb_id != NULL) {
        ETERM *rec_tup[2];
        rec_tup[0] = erl_mk_atom(cb_id);
        rec_tup[1] = erl_mk_int(ref);
        arr[6] = erl_mk_tuple(rec_tup, 2);
    } else {
        arr[6] = erl_mk_atom("none");
    }
    switch (nctx->src_addr.af) {
    case AF_INET:
        arr[7] = ip4_to_term(&nctx->src_addr.ip.v4);
        break;
    case AF_INET6:
        arr[7] = ip6_to_term(&nctx->src_addr.ip.v6);
        break;
    default:
        arr[7] = erl_mk_atom("none");
    }
    term = erl_mk_tuple(arr, 8);
    ret = term_write(nctx->fd, term, CONFD_PROTO_REQUEST, -1);
    erl_free_compound(term);
    return ret;
}

int confd_notification_flush(struct confd_notification_ctx *nctx)
{
    ETERM *term, *reply;
    int ret;

    term = erl_mk_int(CONFD_PROTO_NOTIF_FLUSH);
    ret = term_write(nctx->fd, term, CONFD_PROTO_REQUEST, -1);
    erl_free_term(term);
    if (ret == CONFD_OK) {
        if ((reply = term_read(nctx->fd, &ret, -1)) != NULL)
            erl_free_compound(reply);
    }
    return ret;
}


void confd_trans_set_fd(struct confd_trans_ctx *tctx, int fd)
{
    if (tctx->lastop == CONFD_PROTO_NEW_VALIDATE)
        tctx->vfd = fd;
    else
        tctx->fd = fd;
}


void confd_action_set_fd(struct confd_user_info *uinfo, int fd)
{
    uinfo->actx.fd = fd;
}


void confd_db_seterr(struct confd_db_ctx *dbx, const char *fmt, ...)
{
    SETERR(&dbx->error);
}

void confd_db_seterr_extended(struct confd_db_ctx *dbx,
                              enum confd_errcode code,
                              u_int32_t apptag_ns,
                              u_int32_t apptag_tag,
                              const char *fmt, ...)
{
    SETERR_EXTENDED(&dbx->error);
}

int confd_db_seterr_extended_info(struct confd_db_ctx *dbx,
                                  enum confd_errcode code,
                                  u_int32_t apptag_ns,
                                  u_int32_t apptag_tag,
                                  confd_tag_value_t *error_info, int n,
                                  const char *fmt, ...)
{
    SETERR_EXTENDED_INFO(&dbx->error, dbx->dx->flags);
}

void confd_trans_seterr(struct confd_trans_ctx *tctx, const char *fmt, ...)
{
    SETERR(&tctx->error);
}

void confd_trans_seterr_extended(struct confd_trans_ctx *tctx,
                                 enum confd_errcode code,
                                 u_int32_t apptag_ns,
                                 u_int32_t apptag_tag,
                                 const char *fmt, ...)
{
    SETERR_EXTENDED(&tctx->error);
}

int confd_trans_seterr_extended_info(struct confd_trans_ctx *tctx,
                                     enum confd_errcode code,
                                     u_int32_t apptag_ns,
                                     u_int32_t apptag_tag,
                                     confd_tag_value_t *error_info, int n,
                                     const char *fmt, ...)
{
    SETERR_EXTENDED_INFO(&tctx->error, tctx->dx->flags);
}

void confd_action_seterr(struct confd_user_info *uinfo, const char *fmt, ...)
{
    SETERR(&uinfo->actx.error);
}

void confd_action_seterr_extended(struct confd_user_info *uinfo,
                                  enum confd_errcode code,
                                  u_int32_t apptag_ns,
                                  u_int32_t apptag_tag,
                                  const char *fmt, ...)
{
    SETERR_EXTENDED(&uinfo->actx.error);
}

int confd_action_seterr_extended_info(struct confd_user_info *uinfo,
                                      enum confd_errcode code,
                                      u_int32_t apptag_ns,
                                      u_int32_t apptag_tag,
                                      confd_tag_value_t *error_info, int n,
                                      const char *fmt, ...)
{
    SETERR_EXTENDED_INFO(&uinfo->actx.error, uinfo->actx.dx->flags);
}

void confd_notification_seterr(
    struct confd_notification_ctx *nctx,
    const char *fmt, ...)
{
    SETERR(&nctx->error);
}

void confd_notification_seterr_extended(
    struct confd_notification_ctx *nctx,
    enum confd_errcode code,
    u_int32_t apptag_ns,
    u_int32_t apptag_tag,
    const char *fmt, ...)
{
    SETERR_EXTENDED(&nctx->error);
}

int confd_notification_seterr_extended_info(
    struct confd_notification_ctx *nctx,
    enum confd_errcode code,
    u_int32_t apptag_ns,
    u_int32_t apptag_tag,
    confd_tag_value_t *error_info, int n,
    const char *fmt, ...)
{
    SETERR_EXTENDED_INFO(&nctx->error, nctx->flags);
}


void confd_auth_seterr(struct confd_auth_ctx *actx,
                       const char *fmt, ...)
{
    va_list args;
    char buf[BUFSIZ];

    if (fmt != NULL) {
        va_start(args, fmt);
        vsnprintf(buf, sizeof(buf), fmt, args);
        va_end(args);
        if ((actx->errstr = strdup(buf)) == NULL)
            confd_trace(CONFD_DEBUG, "Cannot allocate error string\n");
    }
}


void confd_error_seterr(struct confd_user_info *uinfo,
                        const char *fmt, ...)
{
    va_list args;
    char buf[BUFSIZ];

    if (fmt != NULL) {
        va_start(args, fmt);
        vsnprintf(buf, sizeof(buf), fmt, args);
        va_end(args);
        if ((uinfo->errstr = strdup(buf)) == NULL)
            confd_trace(CONFD_DEBUG, "Cannot allocate error string\n");
    }
}


static unsigned char* bufdup(const unsigned char *src, int n,
                             void *(*mallf)(size_t size))
{
    unsigned char *np = (unsigned char*) mallf(n+1);
    if (np != NULL) {
        memcpy(np, src, n);
        np[n] = '\0';
    }
    return np;
}

static struct confd_snmp_oid *oiddup(const struct confd_snmp_oid *src,
                                     void *(*mallf)(size_t size))
{
    struct confd_snmp_oid *np = mallf(sizeof(struct confd_snmp_oid));
    int i;

    if (np == NULL) return NULL;
    for (i = 0; i < src->len; i++)
        np->oid[i] = src->oid[i];
    np->len = src->len;
    return np;
}

confd_value_t *confd_value_dup_to_mallf(const confd_value_t *v,
                                        confd_value_t *newv,
                                        void *(*mallf)(size_t size),
                                        void (*freef)(void *ptr))
{
    int i;

    if (newv == NULL) return NULL;
    newv->type = v->type;
    switch (v->type) {
    case C_BUF:
    case C_BINARY:
    case C_HEXSTR:
    case C_BITBIG:
        newv->val.buf.ptr = bufdup(v->val.buf.ptr, v->val.buf.size, mallf);
        if (newv->val.buf.ptr == NULL) return NULL;
        newv->val.buf.size = v->val.buf.size;
        break;
    case C_STR: {
        size_t len = strlen(v->val.s) + 1;
        if ((newv->val.s = mallf(len)) == NULL)
            return NULL;
        memcpy(newv->val.s, v->val.s, len);
        break;
    }
    case C_QNAME: {
        unsigned char *name = mallf(v->val.qname.name.size);
        if (name == NULL) return NULL;
        memcpy(name, v->val.qname.name.ptr, v->val.qname.name.size);
        newv->val.qname.name.ptr  = name;
        newv->val.qname.name.size = v->val.qname.name.size;
        if (v->val.qname.prefix.size > 0) {
            unsigned char *prefix = mallf(v->val.qname.prefix.size);
            if (prefix == NULL) {
                freef(name);
                return NULL;
            }
            memcpy(prefix, v->val.qname.prefix.ptr, v->val.qname.prefix.size);
            newv->val.qname.prefix.ptr  = prefix;
            newv->val.qname.prefix.size = v->val.qname.prefix.size;
        } else {
            newv->val.qname.prefix.size = 0;
            newv->val.qname.prefix.ptr  = NULL;
        }
        break;
    }
    case C_LIST: {
        newv->val.list.size = v->val.list.size;
        newv->val.list.ptr = mallf(sizeof (confd_value_t) * v->val.list.size);
        for (i=0; i<v->val.list.size; i++) {
            confd_value_dup_to_mallf(&v->val.list.ptr[i],
                                     &newv->val.list.ptr[i],
                                     mallf, freef);
        }
        break;
    }
    case C_OBJECTREF: {
        confd_hkeypath_t *hkp = mallf(sizeof (confd_hkeypath_t));
        if (!hkp) return NULL;
        newv->val.hkp = hkp;
        for (i = 0; i < v->val.hkp->len; i++) {
            int j = 0;
            confd_value_t *vp = &v->val.hkp->v[i][j];
            while (vp->type != C_NOEXISTS) {
                confd_value_dup_to_mallf(vp, &newv->val.hkp->v[i][j],
                                         mallf, freef);
                j++;
                vp = &v->val.hkp->v[i][j];
            }
            newv->val.hkp->v[i][j].type = C_NOEXISTS;
        }
        newv->val.hkp->len = v->val.hkp->len;
        break;
    }
    case C_OID: {
        newv->val.oidp = oiddup(v->val.oidp, mallf);
        if (newv->val.oidp == NULL) return NULL;
        break;
    }

    default:
        /* woot!! union copy */
        newv->val = v->val;
        break;
    }
    return newv;
}

confd_value_t *confd_value_dup_to(const confd_value_t *v,
                                  confd_value_t *newv)
{
    return confd_value_dup_to_mallf(v, newv, confd_malloc, free);
}

/* use this function on value aquired from the */
/* above dup function                          */

void confd_free_dup_to_value(confd_value_t *v)
{
    switch (v->type) {
    case C_STR:
        free(v->val.s);
        break;
    default:
        confd_free_value(v);
        break;
    }
}

confd_value_t *confd_value_dup(const confd_value_t *v)
{
    confd_value_t *newv = (confd_value_t*)
        confd_malloc(sizeof (confd_value_t));
    return confd_value_dup_to(v, newv);
}

/* use this function on value aquired from the */
/* above dup function                          */

void confd_free_dup_value(confd_value_t *v)
{
    switch (v->type) {
    case C_STR:
        free(v->val.s);
        break;
    default:
        confd_free_value(v);
        break;
    }
    free(v);
}


confd_hkeypath_t *confd_hkeypath_dup(const confd_hkeypath_t *src)
{
    return confd_hkeypath_dup_len(src, src->len);
}

/* Note: cannot have lists as keys, thus no C_LIST branch */
confd_hkeypath_t *confd_hkeypath_dup_len(const confd_hkeypath_t *src, int len)
{
    confd_hkeypath_t *nkp;
    int offset = src->len - len;
    int i,j, endofrow;

    if (offset < 0)
        return NULL;
    nkp = (confd_hkeypath_t *)confd_malloc(sizeof(confd_hkeypath_t));
    if (nkp == NULL)
        return NULL;
    memcpy(&nkp->v[0], &src->v[offset], (len + 1) * sizeof(src->v[0]));
    nkp->len = len;

    for (i=0; i < nkp->len; i++) {
        j = 0;
        endofrow = 0;
        while (! endofrow) {
            confd_value_t *vp = &nkp->v[i][j];
            switch (vp->type) {
            case C_BUF:
            case C_BINARY:
            case C_HEXSTR:
            case C_BITBIG:
                vp->val.buf.ptr = bufdup(vp->val.buf.ptr,vp->val.buf.size,
                                         confd_malloc);
                if (!vp->val.buf.ptr) return NULL;
                break;
            case C_STR:
                /* must become C_BUF to be freed by confd_free_hkeypath() */
                CONFD_SET_CBUF(vp, strdup(vp->val.s), strlen(vp->val.s));
                if (!vp->val.buf.ptr) return NULL;
                break;
            case C_OBJECTREF:
                vp->val.hkp = confd_hkeypath_dup(vp->val.hkp);
                break;
            case C_OID:
                vp->val.oidp = oiddup(vp->val.oidp, confd_malloc);
                if (!vp->val.oidp) return NULL;
                break;
            case C_NOEXISTS:
                endofrow = 1;
                break;
            default:
                break;
            }
            j++;
        }
    }

    return nkp;
}


static time_t login2time(const ETERM *login)
{
    if (login == NULL)
        return 0;
    else if (ERL_IS_INTEGER(login))
        return ERL_INT_VALUE(login);
    else
        return ERL_LL_VALUE(login);
}

static void update_uinfo(const ETERM *utup, struct confd_user_info *uinfo)
{
    int usid = TUINT(utup, 0);
    ETERM *uterm = TE(utup, 1);
    ETERM *clearpass = TE(utup, 2);
    ETERM *context = TE(utup, 3);
    enum confd_proto proto = (enum confd_proto)TINT(utup, 4);
    ETERM *ipterm = TE(utup, 5);
    int port = TUINT(utup, 6);
    ETERM *login = TE(utup, 7);
    ETERM *snmp_v3_ctx = TE(utup, 8);
    int flags = TINT(utup, 9);

    if (ERL_TUPLE_SIZE(ipterm) == 4) {
        uinfo->af = AF_INET;
        term_to_ip4(&uinfo->ip.v4, ipterm);
    }
    else {
        uinfo->af = AF_INET6;
        term_to_ip6(&uinfo->ip.v6, ipterm);
    }
    uinfo->port = port;
    bin_copy(uinfo->username, sizeof(uinfo->username), uterm);
    uinfo->usid = usid;
    bin_copy(uinfo->context, sizeof(uinfo->context), context);
    uinfo->proto = proto;
    uinfo->logintime = login2time(login);
    uinfo->lmode = 0;
    if (snmp_v3_ctx != NULL)
        bin_copy(uinfo->snmp_v3_ctx, sizeof(uinfo->snmp_v3_ctx), snmp_v3_ctx);
    else
        uinfo->snmp_v3_ctx[0] = '\0';
    bin_copy(uinfo->clearpass, sizeof(uinfo->clearpass), clearpass);
    uinfo->flags = flags;
}

void _confd_mk_uinfo(const ETERM *utup, struct confd_user_info *uinfo)
{
    memset(uinfo, 0, sizeof(struct confd_user_info));
    update_uinfo(utup, uinfo);
}

static struct confd_user_info *add_user_session(struct confd_daemon_ctx *dx,
                                                const ETERM *utup, int new,
                                                int *is_updatep)
{
    struct confd_user_info new_uinfo, *uinfo;
    int is_update = 0;

    _confd_mk_uinfo(utup, &new_uinfo);
    PTHREAD_MUTEX_LOCK(dx->slock);
    /* old user session for this usid may be either
       - same as this one, we received an update (e.g. new flags)
       - different one, left over from before a confd restart
         ("can't happen" with per-daemon table)
       we always replace/overwrite, but must preserve local data in the
       first case - we use the logintime to differentiate */
    if ((uinfo = (struct confd_user_info *)hashtable_search(
             dx->user_sessions, INT2VOID(new_uinfo.usid))) == NULL) {
        if ((uinfo = confd_malloc(sizeof(struct confd_user_info))) != NULL) {
            *uinfo = new_uinfo;
            hashtable_insert(dx->user_sessions,INT2VOID(new_uinfo.usid), uinfo);
        }
    } else {
        if (uinfo->logintime == new_uinfo.logintime) {
            /* update */
            update_uinfo(utup, uinfo);
            is_update = 1;
        } else {
            *uinfo = new_uinfo;
        }
    }
    if (uinfo != NULL) {
        uinfo->refc++;
        if (is_updatep != NULL)
            *is_updatep = is_update;
        if (!is_update) {
            confd_trace(CONFD_TRACE, "%s user session: %d for user:%s ctx:%s%s",
                        new ? "New" : "Picked up old",
                        uinfo->usid, uinfo->username, uinfo->context,
                        new > 1 ? "" : "\n");
        }
    }
    PTHREAD_MUTEX_UNLOCK(dx->slock);
    return uinfo;
}

static struct confd_user_info *get_user_session(struct confd_daemon_ctx *dx,
                                                int usid)
{
    struct confd_user_info *uinfo;

    PTHREAD_MUTEX_LOCK(dx->slock);
    if ((uinfo = (struct confd_user_info*) hashtable_search(
             dx->user_sessions, INT2VOID(usid))) != NULL)
        uinfo->refc++;
    PTHREAD_MUTEX_UNLOCK(dx->slock);
    return uinfo;
}

static void put_user_session(struct confd_daemon_ctx *dx,
                             struct confd_user_info *uinfo)
{
    PTHREAD_MUTEX_LOCK(dx->slock);
    uinfo->refc--;
    if (uinfo->refc == 0) {
        hashtable_remove(dx->user_sessions, INT2VOID(uinfo->usid));
        free(uinfo);
    }
    PTHREAD_MUTEX_UNLOCK(dx->slock);
}


/* returns: 1 = nothing to do, 2 = accumulated, -1 = malloc failed */
static int accumulate1(int retv, struct confd_trans_ctx *tctx,
                       const confd_hkeypath_t *hkp, enum confd_tr_op op,
                       const ETERM *callpoint)
{
    struct confd_tr_item *item;
    if (retv != CONFD_ACCUMULATE)
        return 1;
    if ((item = confd_malloc(sizeof (struct confd_tr_item))) == NULL)
        return -1;
    memset(item, 0, sizeof (struct confd_tr_item));
    if ((item->callpoint = (char*) bufdup((unsigned char*)
                                          ERL_ATOM_PTR(callpoint),
                                          ERL_ATOM_SIZE(callpoint),
                                          confd_malloc)) == NULL)
        return -1;
    item->op = op;
    if ((item->hkp = confd_hkeypath_dup(hkp)) == NULL)
        return -1;
    if (tctx->accumulated == NULL) {
        tctx->accumulated = item;
        tctx->lastack = item;
    }
    else {
        tctx->lastack->next = item;
        tctx->lastack = item;
    }
    return 2;
}

/* returns: 1 = nothing to do, 2 = accumulated, -1 = malloc failed */
static int accumulate2(int retv, struct confd_trans_ctx *tctx,
                       const confd_hkeypath_t *hkp, enum confd_tr_op op,
                       const confd_value_t *cpath, int cp_len,
                       u_int32_t attr, const confd_value_t *val, int nkeys,
                       const ETERM *callpoint)
{
    int rval = accumulate1(retv, tctx, hkp, op, callpoint);
    int i;

    if (rval == 2) {
        if (val != NULL) {
            if (op == C_MOVE_AFTER) {
                if ((tctx->lastack->val =
                     confd_malloc((nkeys+1) * sizeof(confd_value_t))) == NULL)
                    return -1;
                for (i = 0; i <= nkeys; i++) {
                    if (confd_value_dup_to(&val[i],
                                           &tctx->lastack->val[i]) == NULL)
                        return -1;
                }
            } else {
                if ((tctx->lastack->val = confd_value_dup(val)) == NULL)
                    return -1;
            }
        }
        if (cpath != NULL) {
            int sz = (cp_len + 1) * sizeof(confd_value_t);
            if ((tctx->lastack->choice = confd_malloc(sz)) == NULL)
                return -1;
            memcpy(tctx->lastack->choice, cpath, sz);
        }
        tctx->lastack->attr = attr;
        return 2;
    }
    return rval;
}

static int action_result(struct confd_user_info *uinfo, int retval)
{
    struct confd_action_ctx *actx = &uinfo->actx;
    int usid = uinfo->usid;
    ETERM *tup, *retarr[5];

    if (confd_debug_level >= CONFD_TRACE) {
        switch (retval) {
        case CONFD_OK:
            confd_trace_printf( " --> CONFD_OK\n");
            break;
        case CONFD_ERR:
            confd_trace_printf(" --> CONFD_ERR\n");
            break;
        case CONFD_DELAYED_RESPONSE:
            confd_trace_printf(" --> CONFD_DELAYED_RESPONSE\n");
            break;
        default:
            confd_trace_printf(" --> BADRETVAL\n");
        }
    }
    switch (retval) {
    case CONFD_OK:
        if (actx->seen_reply > 0)
            return CONFD_OK;
        if (actx->last_op == CONFD_CALL_ACTION_COMPLETION) {
            confd_action_seterr_extended(uinfo, CONFD_ERRCODE_PROTO_USAGE,
                                         0, 0, "expect data");
            retval = ret_err(CONFD_ERR_PROTOUSAGE,
                             "confd_action_reply_completion() is required "
                             "for completion() callback usid=%d\n", usid);
        }
        break;
    case CONFD_ERR:
        if (actx->seen_reply > 0) {
            return ret_err(CONFD_ERR_PROTOUSAGE,
                           "Got ret CONFD_ERR although ok data reply "
                           "has already been sent usid=%d\n", usid);
        } else {
            confd_set_errno(CONFD_ERR_EXTERNAL);
        }
        break;
    case CONFD_DELAYED_RESPONSE:
        if (actx->seen_reply > 0) {
            return ret_err(CONFD_ERR_PROTOUSAGE,
                           "Got ret CONFD_DELAYED_RESPONSE although ok data "
                           "reply has already been sent usid=%d\n", usid);
        }
        actx->state = ACT_STATE_DELAYED;  /* for data reply */
        return CONFD_DELAYED_RESPONSE;
    default:
        confd_action_seterr_extended(uinfo, CONFD_ERRCODE_PROTO_USAGE,
                                     0, 0, "Bad return value: %d", retval);
        retval = ret_err(CONFD_ERR_PROTOUSAGE,
                         "Bad return value: %d\n", retval);
        if (actx->seen_reply > 0) {
            return retval;
        }
    }

    actx->seen_reply = 1;
    if (retval == CONFD_OK) {
        retarr[0] = erl_mk_int(CONFD_PROTO_CALLBACK);
        retarr[1] = erl_mk_int(actx->query_ref);
        retarr[2] = erl_mk_int(actx->dx->daemon_id);
        retarr[3] = erl_mk_tuple(&tup, 0);
        actx->rterm = erl_mk_tuple(retarr, 4);
        free_error(&actx->error);
    }
    return retval;
}

static int action_action_callback(struct confd_user_info *uinfo, ETERM *argl)
{
    struct confd_action_ctx *actx = &uinfo->actx;
    const struct confd_action_cbs *acb = actx->acb;
    ETERM *tag, *path, *params;
    struct xml_tag name;
    confd_hkeypath_t keypath, *kp = NULL;
    int len, retval = CONFD_ERR;
    int internal_error = 0;

    /* 3 args [Name, Path, Params] */

    tag = ERL_CONS_HEAD(argl);
    name.ns = ERL_INT_UVALUE(ERL_CONS_HEAD(tag));
    name.tag = ERL_INT_UVALUE(ERL_CONS_TAIL(tag));
    argl = ERL_CONS_TAIL(argl);
    path = ERL_CONS_HEAD(argl);
    if (ERL_IS_EMPTY_LIST(path)) {
        kp = NULL;
    } else {
        kp = &keypath;
        if (!populate_keypath(path, kp))
            return CONFD_ERR;
    }
    argl = ERL_CONS_TAIL(argl);
    params = ERL_CONS_HEAD(argl);
    len = erl_length(params);

    if (confd_debug_level >= CONFD_TRACE) {
        char *tagstr = confd_hash2str(name.tag);
        char tbuf[BUFSIZ];
        if (kp != NULL)
            confd_pp_kpath(tbuf, BUFSIZ, kp);
        confd_trace_printf("TRACE CALL action(usid=%d,%s,%s)",
                           uinfo->usid, tagstr == NULL ? "" : tagstr,
                           kp == NULL ? "" : tbuf);
    }

    if (len == 0) {
        retval = acb->action(uinfo, &name, kp, NULL, 0);
    } else {
        confd_tag_value_t *tv;

        if ((tv = confd_malloc(sizeof(*tv) * len)) != NULL) {
            if ((retval = etermlist_to_tag_vals(params, tv, len)) == len) {
                retval = acb->action(uinfo, &name, kp, tv, len);
                free_tag_value_array(tv, len);
            }
            else {
                internal_error = retval != CONFD_ERR;
            }
            free(tv);
        }
    }
    if (kp != NULL)
        confd_free_eterm_keypath(kp);

    return internal_error == 0 ?
        action_result(uinfo, retval):
        confd_internal_error("Internal error, corrupt tag value list\n");
}

static int action_command_callback(struct confd_user_info *uinfo, ETERM *argl)
{
    struct confd_action_ctx *actx = &uinfo->actx;
    const struct confd_action_cbs *acb = actx->acb;
    char *name, *path;
    ETERM *params;
    int len, retval;

    /* 3 args [Name, Path, Params] */

    name = bin_dup(ERL_CONS_HEAD(argl));
    argl = ERL_CONS_TAIL(argl);
    path = bin_dup(ERL_CONS_HEAD(argl));
    argl = ERL_CONS_TAIL(argl);
    params = ERL_CONS_HEAD(argl);
    len = erl_length(params);

    {
        char *argv[len+2];      /* cmd + params + NULL */
        int i;

        if (confd_debug_level >= CONFD_TRACE) {
            confd_trace_printf("TRACE CALL action command(usid=%d,%s)",
                               uinfo->usid, path);
        }

        argv[0] = name;
        for (i = 0; i < len; i++) {
            if (!ERL_IS_CONS(params)) {
                return ret_err(CONFD_ERR_INTERNAL,
                               "Got bad params for action callback\n");
            }
            argv[i+1] = bin_dup(ERL_CONS_HEAD(params));
            params = ERL_CONS_TAIL(params);
        }
        argv[len + 1] = NULL;
        retval = acb->command(uinfo, path, len + 1, argv);
        free(name);
        free(path);
        for (i = 0; i < len; i++)
            free(argv[i+1]);
    }
    return action_result(uinfo, retval);
}

static int action_completion_callback(struct confd_user_info *uinfo,
                                      ETERM *argl)
{
    struct confd_action_ctx *actx = &uinfo->actx;
    const struct confd_action_cbs *acb = actx->acb;
    char cli_style, completion_char;
    ETERM *val;
    char *token, *cmdpath = NULL, *id = NULL;
    confd_hkeypath_t keypath, *kp = &keypath;
    confd_value_t simpleType;
    struct confd_qname *tp = &simpleType.val.qname;
    int retval;

    /* 7 args [Style, Token, CompletionChar, KP, CmdPath, Id, SimpleType] */

    cli_style = ERL_INT_VALUE(ERL_CONS_HEAD(argl));
    argl = ERL_CONS_TAIL(argl);
    token = (char *)ERL_BIN_PTR(ERL_CONS_HEAD(argl));
    argl = ERL_CONS_TAIL(argl);
    completion_char = ERL_INT_VALUE(ERL_CONS_HEAD(argl));
    argl = ERL_CONS_TAIL(argl);
    val = ERL_CONS_HEAD(argl);
    if (ERL_IS_EMPTY_LIST(val)) {
        kp = NULL;
    } else {
        if (!populate_keypath(val, kp))
            return CONFD_ERR;
    }
    argl = ERL_CONS_TAIL(argl);
    val = ERL_CONS_HEAD(argl);
    if (ERL_BIN_SIZE(val) == 0)
        cmdpath = NULL;
    else
        cmdpath = (char *)ERL_BIN_PTR(val);
    argl = ERL_CONS_TAIL(argl);
    val = ERL_CONS_HEAD(argl);
    if (ERL_BIN_SIZE(val) == 0)
        id = NULL;
    else
        id = (char *)ERL_BIN_PTR(val);
    argl = ERL_CONS_TAIL(argl);
    val = ERL_CONS_HEAD(argl);
    if (ERL_TUPLE_SIZE(val) == 0) {
        tp = NULL;
    } else {
        eterm_to_val(val, &simpleType);
    }

    if (confd_debug_level >= CONFD_TRACE) {
        confd_trace_printf("TRACE CALL action completion(usid=%d,%s)",
                           uinfo->usid, token);
    }

    retval = acb->completion(uinfo, cli_style, token, completion_char,
                             kp, cmdpath, id, tp, NULL);

    if (kp != NULL)
        confd_free_eterm_keypath(kp);

    return action_result(uinfo, retval);
}

static int action_callback(struct confd_daemon_ctx *dx, int qref, int tid,
                           char *opaque, int cb, ETERM *argl)
{
    int usid = TID2USID(tid);
    struct confd_user_info *uinfo;
    struct confd_action_ctx *actx;
    int retval;

    if ((uinfo = get_user_session(dx, usid)) == NULL) {
        return confd_internal_error("Got action callback for non existing "
                                    "user session %d\n", usid);
    }
    put_user_session(dx, uinfo);    /* already ref'ed from NEW_ACTION */
    actx = &uinfo->actx;
    PTHREAD_MUTEX_LOCK(actx->dx->slock);
    if (actx->state == ACT_STATE_ABORTED) {
        PTHREAD_MUTEX_UNLOCK(actx->dx->slock);
        /* We got abort between init() and callback - action requestor
           is gone, but we must reply to keep the protocol synced    */
        action_reply_busy(actx->fd, CONFD_PROTO_CALLBACK, qref, dx->daemon_id,
                          "Action aborted");
        put_user_session(dx, uinfo);
        return CONFD_OK;
    }
    actx->state = ACT_STATE_ACTION;
    PTHREAD_MUTEX_UNLOCK(actx->dx->slock);
    clear_error(&actx->error);
    actx->last_op = cb;
    actx->seen_reply = 0;
    actx->query_ref = qref;

    actx->actionpoint_opaque = opaque;
    switch (cb) {
    case CONFD_CALL_ACTION:
        retval = action_action_callback(uinfo, argl);
        break;
    case CONFD_CALL_ACTION_COMMAND:
        retval = action_command_callback(uinfo, argl);
        break;
    case CONFD_CALL_ACTION_COMPLETION:
        retval = action_completion_callback(uinfo, argl);
        break;
    case CONFD_CALL_ACTION_SYNC:
        /* dummy callback to keep the protocol synced on abort before real cb
           it "should" be caught by the ACT_STATE_ABORTED above, but in case it
           doesn't (in particular if there is no abort callback registered, and
           thus no invocation that sets ACT_STATE_ABORTED), we catch it here  */
        action_reply_busy(actx->fd, CONFD_PROTO_CALLBACK, qref, dx->daemon_id,
                          "Action aborted");
        actx->state = ACT_STATE_ABORTED;
        put_user_session(dx, uinfo);
        return CONFD_OK;
        break;
    default:
        retval = confd_internal_error("unknown action callback %d", cb);
    }
    actx->actionpoint_opaque = NULL;

    if (retval != CONFD_DELAYED_RESPONSE) {
        /* send reply now */
        if (actx->rterm != NULL) {
            int fd = actx->fd;
            ETERM *rterm = actx->rterm;
            actx->state = ACT_STATE_NONE;
            term_write(fd, rterm, -1, -1);
            erl_free_compound(rterm);
        } else {
            action_reply_error(actx);
        }
        put_user_session(dx, uinfo);
    }
    return retval;
}


int confd_action_set_timeout(struct confd_user_info *uinfo, int timeout_secs)
{
    ETERM *retarr[5], *rterm;
    struct confd_action_ctx *actx = &uinfo->actx;
    int retval;

    if (actx->state != ACT_STATE_ACTION) {
        return ret_err(CONFD_ERR_PROTOUSAGE, actx->state == ACT_STATE_INIT ?
                       "Timeout can not be set in init() callback\n" :
                       "Timeout can only be set in action callback\n");
    }

    retarr[0] = erl_mk_int(CONFD_PROTO_CALLBACK_TIMEOUT);
    retarr[1] = erl_mk_int(actx->query_ref);
    retarr[2] = erl_mk_int(actx->dx->daemon_id);
    retarr[3] = erl_mk_int(timeout_secs);
    rterm = erl_mk_tuple(retarr, 4);
    retval = term_write(actx->fd, rterm, -1, -1);
    erl_free_compound(rterm);
    return retval;
}



int confd_action_delayed_reply_error(struct confd_user_info *uinfo,
                                     const char *errstr)
{
     int retval;
     struct confd_action_ctx *actx = &uinfo->actx;

     if (actx->seen_reply > 0) {
         return ret_err(CONFD_ERR_PROTOUSAGE,
                        "Cannot do action delayed reply "
                        "when data reply has already been sent usid=%d\n",
                        uinfo->usid);
     }
     if (actx->state == ACT_STATE_NONE || actx->state == ACT_STATE_ABORTED) {
         return ret_err(CONFD_ERR_PROTOUSAGE,
                        "Cannot do action delayed reply "
                        "when no callback has been invoked usid=%d\n",
                        uinfo->usid);
     }
     actx->seen_reply = 1;
     if (errstr != NULL)
         confd_action_seterr(uinfo, "%s", errstr);
     retval = action_reply_error(actx);
     put_user_session(actx->dx, uinfo);
     return retval;
}



int confd_action_delayed_reply_ok(struct confd_user_info *uinfo)
{
     ETERM *tup, *retarr[5], *rterm;
     int fd, retval;
     struct confd_action_ctx *actx = &uinfo->actx;

     if (actx->last_op == CONFD_CALL_ACTION_COMPLETION) {
         return ret_err(CONFD_ERR_PROTOUSAGE,
                        "confd_action_reply_completion() is required "
                        "for completion() callback");
     }
     if (actx->seen_reply > 0) {
         return ret_err(CONFD_ERR_PROTOUSAGE,
                        "Cannot do action delayed reply "
                        "when data reply has already been sent usid=%d\n",
                        uinfo->usid);
     }
     if (actx->state == ACT_STATE_NONE || actx->state == ACT_STATE_ABORTED) {
         return ret_err(CONFD_ERR_PROTOUSAGE,
                        "Cannot do action delayed reply "
                        "when no callback has been invoked usid=%d\n",
                        uinfo->usid);
     }
     actx->seen_reply = 1;
     retarr[0] = erl_mk_int(CONFD_PROTO_CALLBACK);
     retarr[1] = erl_mk_int(actx->query_ref);
     retarr[2] = erl_mk_int(actx->dx->daemon_id);
     retarr[3] = erl_mk_tuple(&tup, 0);
     rterm = erl_mk_tuple(retarr, 4);
     free_error(&actx->error);
     fd = actx->fd;
     actx->state = ACT_STATE_NONE;
     retval = term_write(fd, rterm, -1, -1);
     erl_free_compound(rterm);
     put_user_session(actx->dx, uinfo);
     return retval;
}


static ETERM *get_callpoint(ETERM *callpoint, char **opaque)
{
    if (ERL_IS_TUPLE(callpoint)) {
        *opaque = (char *)ERL_ATOM_PTR(ERL_TUPLE_ELEMENT(callpoint, 1));
        return ERL_TUPLE_ELEMENT(callpoint, 0);
    }
    *opaque = NULL;
    return callpoint;
}

static int populate_choicepath(ETERM *choice_path, confd_value_t *cpath,
                               int len, confd_hkeypath_t *kp)
{
    const ETERM *hd, *tl = choice_path;
    u_int32_t ns;
    int i = 0;

    for (i = 0; i < len; i++) {
        if (!ERL_IS_CONS(tl))
            return confd_internal_error("Internal error, bad choice path\n");
        hd = ERL_CONS_HEAD(tl);
        tl = ERL_CONS_TAIL(tl);
        if (ERL_IS_LIST(hd)) {
            /* a namespace-qualified xmltag */
            if (eterm_to_val(hd, &cpath[i]) == NULL)
                return CONFD_ERR;
        } else if (IS_INTEGER_OR_UNSIGNED_INTEGER(hd)) {
            /* an unqualified xmltag */
            CONFD_SET_XMLTAG(&cpath[i], ERL_INT_UVALUE(hd), 0);
        } else {
            return confd_internal_error("Internal error, bad choice path\n");
        }
    }
    /* qualify unqualified tags */
    for (i = 0; kp->v[i][0].type != C_XMLTAG; i++)
        ;
    ns = CONFD_GET_XMLTAG_NS(&kp->v[i][0]);
    for (i = len - 1; i >=0; i--) {
        if (cpath[i].val.xmltag.ns == 0)
            cpath[i].val.xmltag.ns = ns;
        else
            ns = cpath[i].val.xmltag.ns;
    }
    CONFD_SET_NOEXISTS(&cpath[len]);
    return CONFD_OK;
}

static int validate_callback(struct confd_daemon_ctx *dx, int qref,
                             struct confd_trans_ctx *tctx, ETERM *point,
                             int index, ETERM *argl)
{
    struct confd_valpoint_cb *vcb;
    confd_hkeypath_t keypath;
    int retv = CONFD_ERR;
    confd_value_t new_val;

    if ((vcb = tag_to_valcbs(dx, point, index)) == NULL) {
        char tbuf[MAX_CALLPOINT_LEN];
        bin_copy(tbuf, MAX_CALLPOINT_LEN, point);
        return ret_err(CONFD_ERR_INTERNAL,
                       "No validation point found for %s\n",tbuf);
    }
    tctx->vcb_opaque = vcb->cb_opaque;

    /* 2 args [KeyPath, NewVal] */

    if (!populate_keypath(ERL_CONS_HEAD(argl), &keypath))
        return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
    argl = ERL_CONS_TAIL(argl);
    if (eterm_to_val(ERL_CONS_HEAD(argl), &new_val)==NULL) {
        retv = CONFD_ERR;
    } else {
        kp_trace2(tctx, "validate", &keypath, &new_val);
        retv = vcb->validate(tctx, &keypath, &new_val);
        retv = proto_reply(tctx, 0 , retv);
        confd_free_eterm_val(&new_val);
    }
    confd_free_eterm_keypath(&keypath);
    return retv;
}

static int get_proplist(ETERM *argl, struct ncs_name_value **proplist,
                        int *num_props)
{
    int i, n;
    struct ncs_name_value *pl;
    ETERM *arg;

    if (ERL_IS_ATOM(argl)) {
        /* atom 'undefined' */
        n = 0;
    } else {
        n = erl_length(argl);
    }
    if (n == 0) {
        *proplist = NULL;
        *num_props = 0;
    } else {
        if ((pl = confd_malloc(n * sizeof(struct ncs_name_value))) ==
            NULL) {
            return 0;
        }
        for (i = 0; i < n; i++) {
            arg = ERL_CONS_HEAD(argl);
            pl[i].name = (char *)ERL_ATOM_PTR(TE(arg, 0));
            pl[i].value = (char *)ERL_BIN_PTR(TE(arg, 1));
            argl = ERL_CONS_TAIL(argl);
        }
        *proplist = pl;
        *num_props = n;
    }
    return 1;
}

static int service_callback(struct confd_daemon_ctx *dx, int qref,
                         struct confd_trans_ctx *tctx, ETERM *point,
                         int index, int cb, ETERM *argl)
{
    struct ncs_service_cbs *scb;
    confd_hkeypath_t keypath;
    struct ncs_name_value *proplist = NULL;
    int num_props;
    int retv = CONFD_ERR;

    if ((scb = tag_to_servcbs(dx, point, index)) == NULL) {
        char tbuf[MAX_CALLPOINT_LEN];
        bin_copy(tbuf, MAX_CALLPOINT_LEN, point);
        return bad_cb_reply(tctx, CONFD_ERR_INTERNAL,
                            "No service callbacks for %s", tbuf);
    }
    tctx->cb_opaque = scb->cb_opaque;

    switch (cb) {
    case CONFD_SERVICE_CB_PRE_MODIFICATION:
    case CONFD_SERVICE_CB_POST_MODIFICATION: {
        enum ncs_service_operation op;

        /* Three args [Type, KeyPath, Proplist] */

        ETERM *arg = ERL_CONS_HEAD(argl);
        switch (*(ERL_ATOM_PTR(arg))) {
        case 'c': op = NCS_SERVICE_CREATE; break;
        case 'u': op = NCS_SERVICE_UPDATE; break;
        case 'd': op = NCS_SERVICE_DELETE; break;
        default:
            confd_internal_error("Got unknown service op %s\n",
                                 ERL_ATOM_PTR(arg));
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        }
        argl = ERL_CONS_TAIL(argl);
        arg = ERL_CONS_HEAD(argl);
        if (!populate_keypath(arg, &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        argl = ERL_CONS_TAIL(argl);
        arg = ERL_CONS_HEAD(argl);
        if (!get_proplist(arg, &proplist, &num_props))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        if (cb == CONFD_SERVICE_CB_PRE_MODIFICATION) {
            kp_trace_service(tctx, "pre_modification", &keypath);
            if (scb->pre_modification == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                    "No pre_modification() callback installed");
            } else {
                retv = service_reply(tctx,
                                     scb->pre_modification(tctx, op, &keypath,
                                                           proplist, num_props),
                                     proplist, num_props);
            }
        } else {
            kp_trace_service(tctx, "post_modification", &keypath);
            if (scb->post_modification == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                   "No post_modification() callback installed");
            } else {
                retv = service_reply(tctx,
                                     scb->post_modification(tctx, op, &keypath,
                                                            proplist,num_props),
                                     proplist, num_props);
            }
        }
        if (proplist != NULL)
            free(proplist);
        confd_free_eterm_keypath(&keypath);
        return retv;
    }
    case CONFD_SERVICE_CB_PRE_LOCK_CREATE:
    case CONFD_SERVICE_CB_CREATE: {
        int thandle;

        /* Three args [KeyPath, Proplist, TransInTrans] */

        ETERM *arg = ERL_CONS_HEAD(argl);
        if (!populate_keypath(arg, &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        argl = ERL_CONS_TAIL(argl);
        arg = ERL_CONS_HEAD(argl);
        if (!get_proplist(arg, &proplist, &num_props))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        argl = ERL_CONS_TAIL(argl);
        arg = ERL_CONS_HEAD(argl);
        thandle = ERL_INT_VALUE(arg);
        if (cb == CONFD_SERVICE_CB_PRE_LOCK_CREATE) {
            kp_trace_service(tctx, "pre_lock_create", &keypath);
            if (scb->pre_lock_create == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                    "No pre_lock_create() callback installed");
            } else {
                retv = service_reply(tctx,
                                     scb->pre_lock_create(tctx, &keypath,
                                                          proplist, num_props,
                                                          thandle),
                                     proplist, num_props);
            }
        } else {
            kp_trace_service(tctx, "create", &keypath);
            if (scb->create == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                    "No create() callback installed");
            } else {
                retv = service_reply(tctx,
                                     scb->create(tctx, &keypath,
                                                 proplist, num_props,
                                                 thandle),
                                     proplist, num_props);
            }
        }
        if (proplist != NULL)
            free(proplist);
        confd_free_eterm_keypath(&keypath);
        return retv;
    }
    }
    return bad_cb_reply(tctx, CONFD_ERR_INTERNAL, "Bad callback op %d\n", cb);
}

static int nano_service_callback(struct confd_daemon_ctx *dx, int qref,
                                 struct confd_trans_ctx *tctx, ETERM *point,
                                 int index, int cb, ETERM *argl)
{
    struct ncs_nano_service_cbs *nscb;
    confd_hkeypath_t keypath;
    confd_hkeypath_t skeypath;
    struct ncs_name_value *proplist = NULL;
    int num_props;
    struct ncs_name_value *comp_proplist = NULL;
    int num_comp_props;
    int retv = CONFD_ERR;

    if ((nscb = tag_to_nanoservcbs(dx, point, index)) == NULL) {
        char tbuf[MAX_CALLPOINT_LEN];
        bin_copy(tbuf, MAX_CALLPOINT_LEN, point);
        return bad_cb_reply(tctx, CONFD_ERR_INTERNAL,
                            "No nano service callbacks for %s", tbuf);
    }
    tctx->cb_opaque = nscb->cb_opaque;

    switch (cb) {
    case CONFD_NANO_SERVICE_CB_CREATE:
    case CONFD_NANO_SERVICE_CB_DELETE: {
        int thandle;

        /*Five args [KeyPath, Proplist, TransInTrans, CompPropList, SKeyPath] */

        ETERM *arg = ERL_CONS_HEAD(argl);
        if (!populate_keypath(arg, &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        ETERM *estate = ERL_CONS_HEAD(arg);

        ETERM *t1 = ERL_CONS_TAIL(arg);
        ETERM *t2 = ERL_CONS_TAIL(t1);
        ETERM *ecomponent = ERL_CONS_HEAD(t2);

        argl = ERL_CONS_TAIL(argl);
        arg = ERL_CONS_HEAD(argl);
        if (!get_proplist(arg, &proplist, &num_props))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        argl = ERL_CONS_TAIL(argl);
        arg = ERL_CONS_HEAD(argl);
        thandle = ERL_INT_VALUE(arg);
        argl = ERL_CONS_TAIL(argl);
        arg = ERL_CONS_HEAD(argl);
        if (!get_proplist(arg, &comp_proplist, &num_comp_props))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        argl = ERL_CONS_TAIL(argl);
        arg = ERL_CONS_HEAD(argl);
        if (!populate_keypath(arg, &skeypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());

        confd_value_t stateval;
        if (eterm_to_val(ERL_TUPLE_ELEMENT(estate,0), &stateval)==NULL) {
            return bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                "No state defined for nano service");
        }
        confd_value_t comptypeval;
        if (eterm_to_val(ERL_TUPLE_ELEMENT(ecomponent,0), &comptypeval)==NULL) {
            return bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                "No component type defined for nano service");
        }
        confd_value_t compnameval;
        if (eterm_to_val(ERL_TUPLE_ELEMENT(ecomponent,1), &compnameval)==NULL) {
            return bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                "No component name defined for nano service");
        }


        if (cb == CONFD_NANO_SERVICE_CB_DELETE) {
            kp_trace_service(tctx, "nano_delete", &keypath);
            if (nscb->nano_delete == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                    "No delete() nano callback installed");
            } else {
                retv = nano_service_reply(tctx,
                                          nscb->nano_delete(tctx, &keypath,
                                                            &comptypeval,
                                                            &compnameval,
                                                            &stateval,
                                                            proplist, num_props,
                                                            comp_proplist,
                                                            num_comp_props,
                                                            &skeypath,
                                                            thandle),
                                          proplist, num_props);
            }
        } else {
            kp_trace_service(tctx, "nano create", &keypath);
            if (nscb->nano_create == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                    "No create() nano callback installed");
            } else {
                retv = nano_service_reply(tctx,
                                          nscb->nano_create(tctx, &keypath,
                                                            &comptypeval,
                                                            &compnameval,
                                                            &stateval,
                                                            proplist, num_props,
                                                            comp_proplist,
                                                            num_comp_props,
                                                            &skeypath,
                                                            thandle),
                                          proplist, num_props);
            }
        }
        if (proplist != NULL)
            free(proplist);
        if (comp_proplist != NULL)
            free(comp_proplist);
        confd_free_eterm_keypath(&keypath);
        confd_free_eterm_keypath(&skeypath);
        return retv;
    }
    }
    return bad_cb_reply(tctx, CONFD_ERR_INTERNAL,
                        "Bad nano callback op %d\n", cb);
}

static int data_callback(struct confd_daemon_ctx *dx, int qref,
                         struct confd_trans_ctx *tctx, ETERM *point,
                         int index, int cb, ETERM *argl)
{
    struct confd_data_cbs *dcb;
    confd_hkeypath_t keypath;
    int retv = CONFD_ERR;

    if ((dcb = tag_to_datacbs(dx, point, index)) == NULL) {
        char tbuf[MAX_CALLPOINT_LEN];
        bin_copy(tbuf, MAX_CALLPOINT_LEN, point);
        return bad_cb_reply(tctx, CONFD_ERR_INTERNAL,
                            "No data callbacks for %s", tbuf);
    }
    tctx->cb_opaque = dcb->cb_opaque;

    switch (cb) {
    case CONFD_DATA_CB_GET_NEXT: {
        confd_value_t next;

        /* 3/4 args [KeyPath, Next, Index]
                    [KeyPath, Next, Index, Filter] */

        ETERM *arg = ERL_CONS_HEAD(argl);
        argl = ERL_CONS_TAIL(argl);
        if (!populate_keypath(arg, &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());

        arg = ERL_CONS_HEAD(argl);
        argl = ERL_CONS_TAIL(argl);
        next.type = C_INT64;
        if (ERL_IS_TUPLE(arg)) {
            /* {TravId, Next} */
            tctx->traversal_id = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(arg, 0));
            arg = ERL_TUPLE_ELEMENT(arg, 1);
        } else {
            /* First, Next == -1, set new traversal_id */
            tctx->traversal_id = tctx->ntravid++;
        }
        if (ERL_IS_INTEGER(arg))
            next.val.i64 = ERL_INT_VALUE(arg);
        else if (ERL_IS_UNSIGNED_INTEGER(arg))
            next.val.i64 = ERL_INT_UVALUE(arg);
        else
            next.val.i64 = ERL_LL_VALUE(arg);

        arg = ERL_CONS_HEAD(argl);
        argl = ERL_CONS_TAIL(argl);
        tctx->secondary_index = ERL_INT_UVALUE(arg);

        if (!ERL_IS_NIL(argl)) {
            arg = ERL_CONS_HEAD(argl);
            argl = ERL_CONS_TAIL(argl);
            tctx->list_filter = arg;
        }

        kp_trace2(tctx,"get_next", &keypath, &next);
        if (dcb->get_next == NULL) {
            retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                "No get_next() callback installed");
        } else {
            tctx->cb_flags &= ~CONFD_TRANS_CB_FLAG_FILTERED;
            retv = proto_reply(tctx, 1,
                               dcb->get_next(tctx, &keypath, next.val.i64));
        }
        tctx->list_filter = NULL;
        confd_free_eterm_keypath(&keypath);
        return retv;
    }
    case CONFD_DATA_CB_FIND_NEXT: {
        enum confd_find_next_type type;
        ETERM *ekeys;
        int nkeys;

        /* 3/4 args [KeyPath, {Type, Keys[, TravId]}, Index]
                    [KeyPath, {Type, Keys[, TravId]}, Index, Filter] */

        ETERM *arg = ERL_CONS_HEAD(argl);
        argl = ERL_CONS_TAIL(argl);
        if (!populate_keypath(arg, &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());

        arg = ERL_CONS_HEAD(argl);
        argl = ERL_CONS_TAIL(argl);

        type = ERL_INT_UVALUE(TE(arg, 0));
        ekeys = TE(arg, 1);
        if (ERL_TUPLE_SIZE(arg) == 3) {
                tctx->traversal_id = ERL_INT_VALUE(TE(arg, 2));
        } else {
            tctx->traversal_id = tctx->ntravid++;
        }
        nkeys = ERL_TUPLE_SIZE(ekeys);
        {
            confd_value_t keys[nkeys];
            int i;
            retv = CONFD_OK;
            for (i = 0; i < nkeys && retv == CONFD_OK; i++) {
                if (eterm_to_val(TE(ekeys, i), &keys[i]) == NULL) {
                    retv = bad_cb_reply(tctx, confd_errno,
                                        "%s", confd_lasterr());
                }
            }
            if (retv == CONFD_OK) {
                arg = ERL_CONS_HEAD(argl);
                argl = ERL_CONS_TAIL(argl);
                tctx->secondary_index = ERL_INT_UVALUE(arg);

                if (!ERL_IS_NIL(argl)) {
                    arg = ERL_CONS_HEAD(argl);
                    argl = ERL_CONS_TAIL(argl);
                    tctx->list_filter = arg;
                }
                kp_trace_find(tctx, "find_next", &keypath, type, keys, nkeys);
                if (dcb->find_next == NULL) {
                    retv =
                        bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                     "No find_next() callback installed");
                } else {
                    tctx->cb_flags &= ~CONFD_TRANS_CB_FLAG_FILTERED;
                    retv = proto_reply(tctx, 1,
                                       dcb->find_next(tctx, &keypath,
                                                      type, keys, nkeys));
                }
                for (i = 0; i < nkeys; i++)
                    confd_free_eterm_val(&keys[i]);
            }
        }
        tctx->list_filter = NULL;
        confd_free_eterm_keypath(&keypath);
        return retv;
    }
    case CONFD_DATA_CB_NUM_INSTANCES: {
        /* One arg [KeyPath] */

        if (!populate_keypath(ERL_CONS_HEAD(argl), &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        kp_trace(tctx,"num_instances", &keypath);
        if (dcb->num_instances == NULL) {
            /* use get_next instead */
            confd_trace(CONFD_TRACE,
                        "No num_instances cb installed, using get_next\n");
            if (dcb->get_next == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                    "No get_next() callback installed");
            } else {
                tctx->in_num_instances = 1;
                tctx->num_instances = 0;
                tctx->nextarg = -1;
                tctx->traversal_id = tctx->ntravid++;
                while (tctx->in_num_instances == 1) {
                    retv = dcb->get_next(tctx, &keypath, tctx->nextarg);
                    switch (retv) {
                    case CONFD_OK:
                        break;
                    case CONFD_DELAYED_RESPONSE:
                        /* continue when delayed reply is received */
                        tctx->next_dcb = dcb;
                        tctx->next_kp = confd_hkeypath_dup(&keypath);
                        tctx->in_num_instances = 2;
                        break;
                    default:
                        retv = proto_reply(tctx, 0, CONFD_ERR);
                        tctx->in_num_instances = 0;
                    }
                }
            }
        } else {
            retv = proto_reply(tctx, 1, dcb->num_instances(tctx, &keypath));
        }
        confd_free_eterm_keypath(&keypath);
        return retv;
    }
    case CONFD_DATA_CB_GET_ELEM: {
        /* One arg [KeyPath] */

        if (!populate_keypath(ERL_CONS_HEAD(argl), &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        kp_trace(tctx, "get_elem", &keypath);
        if (dcb->get_elem == NULL) {
            retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                "No get_elem() callback installed");
        } else {
            retv = proto_reply(tctx, 1, dcb->get_elem(tctx, &keypath));
        }
        confd_free_eterm_keypath(&keypath);
        return retv;
    }
    case CONFD_DATA_CB_GET_OBJECT: {
        /* One arg [KeyPath] */

        if (!populate_keypath(ERL_CONS_HEAD(argl), &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        kp_trace(tctx, "get_object", &keypath);
        if (dcb->get_object == NULL) {
            /* It's internal if we call get_object w/o registration */
            retv = bad_cb_reply(tctx, CONFD_ERR_INTERNAL,
                                "No get_object() callback installed");
        } else {
            retv = proto_reply(tctx, 1, dcb->get_object(tctx, &keypath));
        }
        confd_free_eterm_keypath(&keypath);
        return retv;
    }
    case CONFD_DATA_CB_GET_NEXT_OBJECT: {
        /* 3/4 args [KeyPath, Next, Index]
                    [KeyPath, Next, Index, Filter] */

        confd_value_t next;
        ETERM *arg = ERL_CONS_HEAD(argl);
        argl = ERL_CONS_TAIL(argl);
        if (!populate_keypath(arg, &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());

        arg = ERL_CONS_HEAD(argl);
        argl = ERL_CONS_TAIL(argl);
        next.type = C_INT64;
        if (ERL_IS_TUPLE(arg)) {
            /* {TravId, Next} */
            tctx->traversal_id = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(arg, 0));
            arg = ERL_TUPLE_ELEMENT(arg, 1);
        } else {
            /* First, Next == -1, set new traversal_id */
            tctx->traversal_id = tctx->ntravid++;
        }
        if (ERL_IS_INTEGER(arg))
            next.val.i64 = ERL_INT_VALUE(arg);
        else if (ERL_IS_UNSIGNED_INTEGER(arg))
            next.val.i64 = ERL_INT_UVALUE(arg);
        else
            next.val.i64 = ERL_LL_VALUE(arg);

        arg = ERL_CONS_HEAD(argl);
        argl = ERL_CONS_TAIL(argl);
        tctx->secondary_index = ERL_INT_UVALUE(arg);

        if (!ERL_IS_NIL(argl)) {
            arg = ERL_CONS_HEAD(argl);
            argl = ERL_CONS_TAIL(argl);
            tctx->list_filter = arg;
        }
        kp_trace2(tctx, "get_next_object", &keypath, &next);
        if (dcb->get_next_object == NULL) {
            /* It's internal if we call get_next_object w/o registration */
            retv = bad_cb_reply(tctx, CONFD_ERR_INTERNAL,
                                "No get_next_object() callback installed");
        } else {
            tctx->cb_flags &= ~CONFD_TRANS_CB_FLAG_FILTERED;
            retv = proto_reply(tctx, 1, dcb->get_next_object(tctx, &keypath,
                                                             next.val.i64));
        }
        tctx->list_filter = NULL;
        confd_free_eterm_keypath(&keypath);
        return retv;
    }
    case CONFD_DATA_CB_FIND_NEXT_OBJECT: {
        enum confd_find_next_type type;
        ETERM *ekeys;
        int nkeys;

        /* 3/4 args [KeyPath, {Type, Keys[, TravId]}, Index]
                    [KeyPath, {Type, Keys[, TravId]}, Index, Filter] */

        ETERM *arg = ERL_CONS_HEAD(argl);
        argl = ERL_CONS_TAIL(argl);
        if (!populate_keypath(arg, &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());

        arg = ERL_CONS_HEAD(argl);
        argl = ERL_CONS_TAIL(argl);

        type = ERL_INT_UVALUE(TE(arg, 0));
        ekeys = TE(arg, 1);
        if (ERL_TUPLE_SIZE(arg) == 3) {
                tctx->traversal_id = ERL_INT_VALUE(TE(arg, 2));
        } else {
            tctx->traversal_id = tctx->ntravid++;
        }
        nkeys = ERL_TUPLE_SIZE(ekeys);
        {
            confd_value_t keys[nkeys];
            int i;
            retv = CONFD_OK;
            for (i = 0; i < nkeys && retv == CONFD_OK; i++) {
                if (eterm_to_val(TE(ekeys, i), &keys[i]) == NULL) {
                    retv = bad_cb_reply(tctx, confd_errno,
                                        "%s", confd_lasterr());
                }
            }
            if (retv == CONFD_OK) {
                arg = ERL_CONS_HEAD(argl);
                argl = ERL_CONS_TAIL(argl);
                tctx->secondary_index = ERL_INT_UVALUE(arg);
                if (!ERL_IS_NIL(argl)) {
                    arg = ERL_CONS_HEAD(argl);
                    argl = ERL_CONS_TAIL(argl);
                    tctx->list_filter = arg;
                }
                kp_trace_find(tctx, "find_next_object", &keypath,
                              type, keys, nkeys);
                if (dcb->find_next_object == NULL) {
                    /* It's internal if we call find_next_object w/o reg. */
                    retv =
                        bad_cb_reply(tctx, CONFD_ERR_INTERNAL,
                                     "No find_next_object() "
                                     "callback installed");
                } else {
                    tctx->cb_flags &= ~CONFD_TRANS_CB_FLAG_FILTERED;
                    retv = proto_reply(tctx, 1,
                                       dcb->find_next_object(tctx, &keypath,
                                                             type,
                                                             keys, nkeys));
                }
                for (i = 0; i < nkeys; i++)
                    confd_free_eterm_val(&keys[i]);
            }
        }
        tctx->list_filter = NULL;
        confd_free_eterm_keypath(&keypath);
        return retv;
    }
    case CONFD_DATA_CB_SET_ELEM: {
        /* 2 args [KeyPath, NewVal] */

        confd_value_t new_val;
        if (!populate_keypath(ERL_CONS_HEAD(argl), &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        argl = ERL_CONS_TAIL(argl);
        if (eterm_to_val(ERL_CONS_HEAD(argl), &new_val)==NULL) {
            retv = bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        } else {
            kp_trace2(tctx, "set_elem", &keypath, &new_val);
            if (dcb->set_elem == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                    "No set_elem() callback installed");
            } else {
                retv = dcb->set_elem(tctx, &keypath, &new_val);
                if (accumulate2(retv, tctx, &keypath, C_SET_ELEM,
                                NULL, 0, 0, &new_val, 0, point) < 0)
                    retv = CONFD_ERR;
                else
                    retv = proto_reply(tctx, 0 , retv);
            }
            confd_free_eterm_val(&new_val);
        }
        confd_free_eterm_keypath(&keypath);
        return retv;
    }

    case CONFD_DATA_CB_CREATE:
    case CONFD_DATA_CB_EXISTS_OPTIONAL:
    case CONFD_DATA_CB_DELETE: {
        /* 1 args, [KeyPath] */

        if (!populate_keypath(ERL_CONS_HEAD(argl), &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        if (cb == CONFD_DATA_CB_CREATE) {
            kp_trace(tctx, "create", &keypath);
            if (dcb->create == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                    "No create() callback installed");
            } else {
                retv = dcb->create(tctx,  &keypath);
                if (accumulate1(retv, tctx, &keypath, C_CREATE, point) < 0)
                    retv = CONFD_ERR;
                else
                    retv = proto_reply(tctx, 0, retv);
            }
        }
        else if (cb == CONFD_DATA_CB_DELETE) {
            kp_trace(tctx, "delete", &keypath);
            if (dcb->remove == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                    "No remove() callback installed");
            } else {
                retv = dcb->remove(tctx,  &keypath);
                if (accumulate1(retv, tctx, &keypath, C_REMOVE, point) < 0)
                    retv = CONFD_ERR;
                else
                    retv = proto_reply(tctx, 0, retv);
            }
        }
        else {
            kp_trace(tctx, "exists_optional", &keypath);
            if (dcb->exists_optional == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                    "No exists_optional() callback installed");
            } else {
                retv = dcb->exists_optional(tctx,  &keypath);
                retv = proto_reply(tctx, 1, retv);
            }
        }
        confd_free_eterm_keypath(&keypath);
        return retv;
        break;
    }

    case CONFD_DATA_CB_GET_CASE: {
        /* 2 args [KeyPath, ChoicePath] */

        ETERM *choice_path;
        int cp_len;

        if (!populate_keypath(ERL_CONS_HEAD(argl), &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        argl = ERL_CONS_TAIL(argl);
        choice_path = ERL_CONS_HEAD(argl);
        cp_len = erl_length(choice_path);
        {
            confd_value_t cpath[cp_len + 1]; /* one elem for C_NOEXISTS */

            if (populate_choicepath(choice_path, cpath, cp_len, &keypath) !=
                CONFD_OK) {
                retv = bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
            } else {
                kp_trace_choice_case(tctx, "get_case", &keypath,
                                     cpath, cp_len, NULL);
                if (dcb->get_case == NULL) {
                    retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                        "No get_case() callback installed");
                } else {
                    retv = dcb->get_case(tctx, &keypath, cpath);
                    retv = proto_reply(tctx, 1, retv);
                }
            }
        }
        confd_free_eterm_keypath(&keypath);
        return retv;
    }

    case CONFD_DATA_CB_SET_CASE: {
        /* 3 args [KeyPath, ChoicePath, CaseVal] */

        ETERM *choice_path;
        int cp_len;

        if (!populate_keypath(ERL_CONS_HEAD(argl), &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        argl = ERL_CONS_TAIL(argl);
        choice_path = ERL_CONS_HEAD(argl);
        cp_len = erl_length(choice_path);
        {
            confd_value_t cpath[cp_len + 1]; /* one elem for C_NOEXISTS */
            confd_value_t casev, *casep = &casev;

            if (populate_choicepath(choice_path, cpath, cp_len, &keypath) !=
                CONFD_OK) {
                retv = bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
            } else {
                argl = ERL_CONS_TAIL(argl);
                if (eterm_to_val(ERL_CONS_HEAD(argl), &casev) == NULL) {
                    retv = bad_cb_reply(tctx, confd_errno,
                                        "%s", confd_lasterr());
                } else {
                    kp_trace_choice_case(tctx, "set_case", &keypath,
                                         cpath, cp_len, &casev);
                    if (dcb->set_case == NULL) {
                        retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                            "No set_case() callback installed");
                    } else {
                        if (casev.type == C_NOEXISTS)
                            casep = NULL;
                        retv = dcb->set_case(tctx, &keypath, cpath, casep);
                        if (accumulate2(retv, tctx, &keypath, C_SET_CASE,
                                        cpath, cp_len, 0, casep, 0, point) < 0)
                            retv = CONFD_ERR;
                        else
                            retv = proto_reply(tctx, 0, retv);
                    }
                }
            }
        }
        confd_free_eterm_keypath(&keypath);
        return retv;
    }

    case CONFD_DATA_CB_GET_ATTRS: {
        /* 2 args [KeyPath, AttrList] */
        ETERM *attrl;
        int n;

        if (!populate_keypath(ERL_CONS_HEAD(argl), &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        argl = ERL_CONS_TAIL(argl);
        attrl = ERL_CONS_HEAD(argl);
        n = erl_length(attrl);
        {
            u_int32_t attrs[n];
            int i;

            for (i = 0; i < n; i++) {
                attrs[i] = ERL_INT_UVALUE(ERL_CONS_HEAD(attrl));
                attrl = ERL_CONS_TAIL(attrl);
            }
            kp_trace(tctx, "get_attrs", &keypath);
            if (dcb->get_attrs == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                    "No get_attrs() callback installed");
            } else {
                retv = dcb->get_attrs(tctx, &keypath, &attrs[0], n);
                retv = proto_reply(tctx, 1, retv);
            }
        }
        confd_free_eterm_keypath(&keypath);
        return retv;
    }

    case CONFD_DATA_CB_SET_ATTR: {
        /* 3 args [KeyPath, Attr, Value] */

        u_int32_t attr;
        confd_value_t attr_val;
        confd_value_t *attr_vp = &attr_val;

        if (!populate_keypath(ERL_CONS_HEAD(argl), &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        argl = ERL_CONS_TAIL(argl);
        attr = ERL_INT_UVALUE(ERL_CONS_HEAD(argl));
        argl = ERL_CONS_TAIL(argl);
        if (eterm_to_val(ERL_CONS_HEAD(argl), &attr_val)==NULL) {
            retv = bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        } else {
            if (attr_val.type == C_NOEXISTS)
                attr_vp = NULL;
            kp_trace(tctx, "set_attr", &keypath);
            if (dcb->set_attr == NULL) {
                retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                    "No set_attr() callback installed");
            } else {
                retv = dcb->set_attr(tctx, &keypath, attr, attr_vp);
                if (accumulate2(retv, tctx, &keypath, C_SET_ATTR,
                                NULL, 0, attr, attr_vp, 0, point) < 0)
                    retv = CONFD_ERR;
                else
                    retv = proto_reply(tctx, 0, retv);
            }
            confd_free_eterm_val(&attr_val);
        }
        confd_free_eterm_keypath(&keypath);
        return retv;
    }

    case CONFD_DATA_CB_MOVE_AFTER: {
        /* 2 args [KeyPath, PrevKeys] */

        ETERM *ekeys;
        int i, n;

        if (!populate_keypath(ERL_CONS_HEAD(argl), &keypath))
            return bad_cb_reply(tctx, confd_errno, "%s", confd_lasterr());
        argl = ERL_CONS_TAIL(argl);
        ekeys = ERL_CONS_HEAD(argl);
        n = ERL_TUPLE_SIZE(ekeys);
        retv = CONFD_OK;
        {
            confd_value_t keys[n+1];
            confd_value_t *keyp;

            if (n == 0) {
                keyp = NULL;
            } else {
                keyp = &keys[0];
                for (i = 0; i < n && retv == CONFD_OK; i++) {
                    if (eterm_to_val(ERL_TUPLE_ELEMENT(ekeys, i), &keys[i])
                        == NULL) {
                        retv = bad_cb_reply(tctx, confd_errno,
                                            "%s", confd_lasterr());
                    }
                }
                CONFD_SET_NOEXISTS(&keys[n]);
            }
            if (retv == CONFD_OK) {
                kp_trace(tctx, "move_after", &keypath);
                if (dcb->move_after == NULL) {
                    retv =
                        bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                     "No move_after() callback installed");
                } else {
                    retv = dcb->move_after(tctx, &keypath, keyp);
                    if (accumulate2(retv, tctx, &keypath, C_MOVE_AFTER,
                                    NULL, 0, 0, keyp, n, point) < 0)
                        retv = CONFD_ERR;
                    else
                        retv = proto_reply(tctx, 0, retv);
                }
                for (i = 0; i < n; i++)
                    confd_free_eterm_val(&keys[i]);
            }
        }
        confd_free_eterm_keypath(&keypath);
        return retv;
    }

    case CONFD_DATA_CB_WRITE_ALL: {
        /* no args */

        keypath.len = 0;
        kp_trace(tctx, "write_all", &keypath);
        if (dcb->write_all == NULL) {
            retv = bad_cb_reply(tctx, CONFD_ERR_PROTOUSAGE,
                                "No write_all() callback installed");
        } else {
            retv = dcb->write_all(tctx,  NULL);
            /* No accumulate possible */
            retv = proto_reply(tctx, 0, retv);
        }
        return retv;
    }

    }

    return bad_cb_reply(tctx, CONFD_ERR_INTERNAL, "Bad callback op %d\n", cb);
}

static void set_request_data(struct confd_trans_ctx *tctx, ETERM *rdata)
{
    ETERM *hd;

    while (! ERL_IS_EMPTY_LIST(rdata)) {
        hd = ERL_CONS_HEAD(rdata);
        if (bin_eq(TE(hd, 0), "snmp_request_id"))
            tctx->request_data.snmp.request_id = TUINT(hd, 1);
        rdata = ERL_CONS_TAIL(rdata);
    }
}

/* The usid for a transaction may/will change at trans_lock
   when using running writable-through-candidate */
static int update_usess(struct confd_trans_ctx *tctx, int usid, char *op)
{
    struct confd_user_info *uinfo;

    if (usid != tctx->uinfo->usid) {
        if ((uinfo = get_user_session(tctx->dx, usid)) == NULL) {
            return confd_internal_error(
                        "Got %s with non existing user session %d\n",
                        op, usid);
        }
        put_user_session(tctx->dx, tctx->uinfo);
        tctx->uinfo = uinfo;
    }
    return CONFD_OK;
}

static int proto_callback(struct confd_daemon_ctx *dx, const ETERM *et)
{
    ETERM *point;
    char *opaque;
    int cb;
    ETERM *request_data;
    ETERM *argl;
    int index, qref, tid, usid, hide_inactive;
    struct confd_trans_ctx *tctx;
    int retv = CONFD_ERR;

    qref = TUINT(et, 1);
    /* unused did is seceond elem */
    tid = TUINT(et, 3);
    point = get_callpoint(ERL_TUPLE_ELEMENT(et, 4), &opaque);
    index = TUINT(et, 5);
    cb = TUINT(et, 6);
    request_data = ERL_TUPLE_ELEMENT(et, 7);
    usid = TUINT(et, 8);
    hide_inactive = TUINT(et, 9);
    argl = ERL_TUPLE_ELEMENT(et, 10);

    if (cb == CONFD_CALL_ACTION ||
        cb == CONFD_CALL_ACTION_COMMAND ||
        cb == CONFD_CALL_ACTION_COMPLETION ||
        cb == CONFD_CALL_ACTION_SYNC) {
        /* it's an action callback (no trans) */
        return action_callback(dx, qref, tid, opaque, cb, argl);
    }

    if ((tctx = tid_to_trans(dx, tid)) == NULL) {
        return confd_internal_error("No trans found with tid=%d\n",tid);
    }
    tctx->seen_reply = 0;
    tctx->query_ref = qref;
    tctx->lastop = CONFD_PROTO_CALLBACK;
    tctx->last_proto_op = cb;
    update_usess(tctx, usid, "worker callback");
    set_request_data(tctx, request_data);
    clear_error(&tctx->error);

    if (cb == CONFD_VALIDATE_VALUE) {
        /* it's a validation callback */
        tctx->validate_opaque = opaque;
        retv = validate_callback(dx, qref, tctx, point, index, argl);
        tctx->validate_opaque = NULL;
        return retv;
    }

    tctx->hide_inactive = hide_inactive;
    tctx->callpoint_opaque = opaque;

    switch (cb) {
    case CONFD_SERVICE_CB_PRE_MODIFICATION:
    case CONFD_SERVICE_CB_POST_MODIFICATION:
    case CONFD_SERVICE_CB_PRE_LOCK_CREATE:
    case CONFD_SERVICE_CB_CREATE:
        /* It's a service callback */
        retv = service_callback(dx, qref, tctx, point, index, cb, argl);
        break;
    case CONFD_NANO_SERVICE_CB_CREATE:
    case CONFD_NANO_SERVICE_CB_DELETE:
        /* It's a nano service callback */
        retv = nano_service_callback(dx, qref, tctx, point, index, cb, argl);
        break;
    default:
        /* It's a data callback */
        retv = data_callback(dx, qref, tctx, point, index, cb, argl);
        break;
    }

    tctx->callpoint_opaque = NULL;
    return retv;
}


#define CALL_AUTH_CB() do {                                     \
        confd_trace(CONFD_TRACE,                                \
                    "CALL auth(user=%s, ctx=%s, success=%s)",   \
                    uinfo.username, uinfo.context,              \
                    actx.success ? "true" : "false");           \
        retval = dx->auth_cb.auth(&actx);                       \
    }  while (0)

static int auth_callback(struct confd_daemon_ctx *dx, int qref,
                         ETERM *utup, ETERM *method, ETERM *result)
{
    int op = CONFD_PROTO_AUTH_CB;
    int did = dx->daemon_id;
    struct confd_user_info uinfo;
    struct confd_auth_ctx actx;
    int retval;
    ETERM *a[4];
    ETERM *af[2];
    ETERM *tup;

    memset(&actx, 0, sizeof(actx));
    _confd_mk_uinfo(utup, &uinfo);
    actx.uinfo = &uinfo;
    actx.method = (char *)ERL_BIN_PTR(method);

    if (bin_eq(TE(result, 0), "true")) {
        ETERM *groupl = TE(result, 1);
        int ngroups = erl_length(groupl);
        char *groups[ngroups];
        int i;

        for (i = 0; i < ngroups; i++) {
            groups[i] = (char *)ERL_BIN_PTR(ERL_CONS_HEAD(groupl));
            groupl = ERL_CONS_TAIL(groupl);
        }
        actx.success = 1;
        actx.ainfo.succ.ngroups = ngroups;
        actx.ainfo.succ.groups = &groups[0];
        CALL_AUTH_CB();
    } else {
        ETERM *reason = TE(result, 2);

        actx.ainfo.fail.logno = TUINT(result, 1);
        actx.ainfo.fail.reason = (char *)ERL_BIN_PTR(reason);
        CALL_AUTH_CB();
    }

    if (confd_debug_level >= CONFD_TRACE) {
        switch (retval) {
        case CONFD_OK:
            confd_trace_printf( " --> CONFD_OK\n");
            break;
        case CONFD_ERR:
            confd_trace_printf(" --> CONFD_ERR\n");
            break;
        default:
            confd_trace_printf(" --> BADRETVAL\n");
        }
    }

    a[0] = erl_mk_int(op);
    a[1] = erl_mk_int(qref);
    a[2] = erl_mk_int(did);
    if (retval == CONFD_OK) {
        a[3] = erl_mk_atom("true");
    } else {
        af[0] = erl_mk_atom("false");
        if (actx.errstr != NULL) {
            af[1] = erl_mk_binary(actx.errstr, strlen(actx.errstr));
            free(actx.errstr);
        } else {
            af[1] = erl_mk_binary("", 0);
        }
        a[3] = erl_mk_tuple(af, 2);
    }
    if ((tup = erl_mk_tuple(a, 4)) == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
    }
    retval = term_write(dx->ctl_sock, tup, -1, -1);
    erl_free_compound(tup);
    return retval;
}

static int access_callback_result(struct confd_daemon_ctx *dx, int qref,
                                  int op, int retval, int result,
                                  enum confd_debug_level debug_level)
{
    int did = dx->daemon_id;
    struct confd_error error;
    ETERM *a[4];
    ETERM *tup;

    if (debug_level >= CONFD_TRACE) {
        switch (retval) {
        case CONFD_OK:
            confd_trace_printf( " --> CONFD_OK\n");
            break;
        case CONFD_ERR:
            confd_trace_printf(" --> CONFD_ERR\n");
            break;
        default:
            confd_trace_printf(" --> BADRETVAL\n");
        }
    }

    clear_error(&error);
    if (retval == CONFD_OK && result == -1) {
        /* No call to confd_access_reply_result() */
        set_error(&error, CONFD_ERRCODE_PROTO_USAGE, 0, 0,
                  "No access check result returned");
        reply_error(dx->ctl_sock, op, qref, did, &error);
        return ret_err(CONFD_ERR_PROTOUSAGE, "No access check result returned");
    }
    if (retval != CONFD_OK) {
        if (retval == CONFD_ERR) {
            set_error(&error, CONFD_ERRCODE_APPLICATION,
                      0, 0, "");
            ret_err(CONFD_ERR_EXTERNAL, "%s", ""); /* avoid silly gcc warning */
        } else {
            set_error(&error, CONFD_ERRCODE_PROTO_USAGE,
                       0, 0, "Bad return value");
            ret_err(CONFD_ERR_PROTOUSAGE,
                    "Bad application return value: %d\n",
                    retval);
        }
        reply_error(dx->ctl_sock, op, qref, did, &error);
        return CONFD_ERR;
    }

    a[0] = erl_mk_int(op);
    a[1] = erl_mk_int(qref);
    a[2] = erl_mk_int(did);
    switch (result) {
    case CONFD_ACCESS_RESULT_ACCEPT:   a[3] = erl_mk_atom("accept");   break;
    case CONFD_ACCESS_RESULT_REJECT:   a[3] = erl_mk_atom("reject");   break;
    case CONFD_ACCESS_RESULT_CONTINUE: a[3] = erl_mk_atom("continue"); break;
    case CONFD_ACCESS_RESULT_DEFAULT:  a[3] = erl_mk_atom("default");  break;
    default:  /* "can't happen" */     a[3] = erl_mk_atom("reject");   break;
    }
    if ((tup = erl_mk_tuple(a, 4)) == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
    }
    retval = term_write(dx->ctl_sock, tup, -1, -1);
    erl_free_compound(tup);
    return retval;
}

static int cmd_access_callback(struct confd_daemon_ctx *dx, int qref,
                               struct confd_user_info *uinfo,
                               ETERM *groupl, ETERM *cmdl, int cmdop)
{
    struct confd_authorization_ctx actx;
    int ngroups = erl_length(groupl);
    char *groups[ngroups];
    int ntokens = erl_length(cmdl);
    char *cmdtokens[ntokens];
    int i;
    int retval;

    actx.uinfo = uinfo;
    actx.ngroups = ngroups;
    for (i = 0; i < ngroups; i++) {
        groups[i] = (char *)ERL_BIN_PTR(ERL_CONS_HEAD(groupl));
        groupl = ERL_CONS_TAIL(groupl);
    }
    actx.groups = &groups[0];
    actx.dx = dx;
    actx.result = -1;
    actx.query_ref = qref;
    for (i = 0; i < ntokens; i++) {
        cmdtokens[i] = (char *)ERL_BIN_PTR(ERL_CONS_HEAD(cmdl));
        cmdl = ERL_CONS_TAIL(cmdl);
    }
    if (confd_debug_level >= CONFD_TRACE) {
        char tbuf[BUFSIZ];
        char *tp = tbuf;
        for (i = 0; i < ntokens; i++)
            tp += confd_snprintf(tp, BUFSIZ - (tp - tbuf), "%s ", cmdtokens[i]);
        confd_trace_printf("TRACE CALL chk_cmd_access(usid=%d, cmd=%s)",
                           uinfo != NULL ? uinfo->usid : 0, tbuf);
    }
    retval = dx->authorization_cbs.chk_cmd_access(&actx, &cmdtokens[0],
                                                  ntokens, cmdop);
    return access_callback_result(dx, qref, CONFD_PROTO_CHK_CMD_ACCESS,
                                  retval, actx.result, confd_debug_level);
}

static int data_access_callback(struct confd_daemon_ctx *dx, int qref,
                                struct confd_user_info *uinfo,
                                ETERM *groupl, u_int32_t ns, ETERM *ekp,
                                int dataop, int how)
{
    struct confd_authorization_ctx actx;
    int ngroups = erl_length(groupl);
    char *groups[ngroups];
    confd_hkeypath_t keypath, *kp;
    int i;
    int retval;

    actx.uinfo = uinfo;
    actx.ngroups = ngroups;
    for (i = 0; i < ngroups; i++) {
        groups[i] = (char *)ERL_BIN_PTR(ERL_CONS_HEAD(groupl));
        groupl = ERL_CONS_TAIL(groupl);
    }
    actx.groups = &groups[0];
    actx.dx = dx;
    actx.result = -1;
    actx.query_ref = qref;
    if (ERL_IS_ATOM(ekp)) {     /* atom 'all' */
        kp = NULL;
    } else {
        kp = &keypath;
        if (!populate_keypath(ekp, kp))
            return CONFD_ERR;
    }
    if (confd_debug_level >= CONFD_TRACE) {
        char tbuf[BUFSIZ];
        if (kp == NULL)
            confd_strlcpy(tbuf, "all", sizeof(tbuf));
        else
            confd_pp_kpath(tbuf, sizeof(tbuf), kp);
        confd_trace_printf("TRACE CALL chk_data_access(usid=%d, ns=%d path=%s)",
                           uinfo->usid, ns, tbuf);
    }
    retval = dx->authorization_cbs.chk_data_access(&actx, ns, kp, dataop, how);
    if (kp != NULL)
        confd_free_eterm_keypath(kp);
    return access_callback_result(dx, qref, CONFD_PROTO_CHK_DATA_ACCESS,
                                  retval, actx.result, confd_debug_level);
}

int confd_access_reply_result(struct confd_authorization_ctx *actx,
                               int result)
{
    char *rstr;

    switch (result) {
    case CONFD_ACCESS_RESULT_ACCEPT:
        rstr = "ACCEPT";
        break;
    case CONFD_ACCESS_RESULT_REJECT:
        rstr = "REJECT";
        break;
    case CONFD_ACCESS_RESULT_CONTINUE:
        rstr = "CONTINUE";
        break;
    case CONFD_ACCESS_RESULT_DEFAULT:
        rstr = "DEFAULT";
        break;
    default:
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Bad access check result %d", result);
    }

    if (confd_debug_level >= CONFD_TRACE)
        confd_trace_printf(" (%s) ", rstr);
    actx->result = result;
    return CONFD_OK;
}

int confd_authorization_set_timeout(struct confd_authorization_ctx *actx,
                                    int timeout_secs)
{
    ETERM *retarr[4], *rterm;
    int retval;

    retarr[0] = erl_mk_int(CONFD_PROTO_DAEMON_TIMEOUT);
    retarr[1] = erl_mk_int(actx->query_ref);
    retarr[2] = erl_mk_int(actx->dx->daemon_id);
    retarr[3] = erl_mk_int(timeout_secs);
    rterm = erl_mk_tuple(retarr, 4);
    retval = term_write(actx->dx->ctl_sock, rterm, -1, -1);
    erl_free_compound(rterm);
    return retval;
}


static const char *err_type(int type)
{
    switch (type) {
    case CONFD_ERRTYPE_VALIDATION: return "validation";
    case CONFD_ERRTYPE_BAD_VALUE:  return "bad_value";
    case CONFD_ERRTYPE_CLI:        return "cli";
    case CONFD_ERRTYPE_MISC:       return "misc";
    case CONFD_ERRTYPE_OPERATION:  return "operation";
    default:                       return "UNKNOWN";
    }
}

#define CALL_ERROR_CB() do {                                            \
        confd_trace(CONFD_TRACE,                                        \
                    "CALL format_error(usid=%d, type=%s code=%d)",      \
                    uinfo->usid, err_type(errinfo->type), code);        \
        dx->error_cb.format_error(uinfo, errinfo, default_msg);         \
        ret = CONFD_OK;                                                 \
    }  while (0)

static int error_callback_validation(struct confd_daemon_ctx *dx,
                                     struct confd_user_info *uinfo, int code,
                                     struct confd_errinfo *errinfo,
                                     ETERM *error, char *default_msg)
{
    struct confd_errinfo_validation *val_err = &errinfo->info.validation;
    struct confd_trans_ctx tctx;
    ETERM *trans, *term;
    confd_hkeypath_t **kpp, *kp;
    confd_value_t v;
    int ret = CONFD_ERR;
    int tix;

    val_err->code = code;

    if (errinfo->type == CONFD_ERRTYPE_VALIDATION) {
        trans = TE(error, 0);
        val_err->test = bin_eq(TE(error, 1), "true") ? 1 : 0;
        tix = 2;

        memset(&tctx, 0, sizeof(tctx));
        tctx.fd = -1;
        tctx.vfd = -1;
        tctx.dx = dx;
        /* element 0 of trans (type) not used */
        tctx.dbname = (enum confd_dbname)TUINT(trans, 1);
        tctx.uinfo = uinfo;    /* element 2 is usid */
        tctx.mode = (enum confd_trans_mode)TUINT(trans, 3);
        tctx.thandle = TUINT(trans, 4);
        set_request_data(&tctx, TE(trans, 5));
        tctx.hide_inactive = TUINT(trans, 6);
        val_err->tctx = &tctx;
    } else {                    /* CONFD_ERRTYPE_OPERATION */
        /* no trans/test provided */
        val_err->test = 0;
        tix = 0;
        val_err->tctx = NULL;
    }

    switch (val_err->code) {
    case CONFD_ERR_NOTSET:
        /* keypath */
        kpp = &val_err->info.notset.kp;
        if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) != NULL) {
            if (populate_keypath(ERL_TUPLE_ELEMENT(error, tix), *kpp)) {
                CALL_ERROR_CB();
                confd_free_eterm_keypath(*kpp);
            }
            free(*kpp);
        }
        break;

    case CONFD_ERR_TOO_FEW_ELEMS:
        /* keypath, n, min */
        kpp = &val_err->info.too_few_elems.kp;
        if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) != NULL) {
            if (populate_keypath(ERL_TUPLE_ELEMENT(error, tix), *kpp)) {
                val_err->info.too_few_elems.n = TUINT(error, tix+1);
                val_err->info.too_few_elems.min = TUINT(error, tix+2);
                CALL_ERROR_CB();
                confd_free_eterm_keypath(*kpp);
            }
            free(*kpp);
        }
        break;

    case CONFD_ERR_TOO_MANY_ELEMS:
        /* keypath, n, max */
        kpp = &val_err->info.too_many_elems.kp;
        if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) != NULL) {
            if (populate_keypath(ERL_TUPLE_ELEMENT(error, tix), *kpp)) {
                val_err->info.too_many_elems.n = TUINT(error, tix+1);
                val_err->info.too_many_elems.max = TUINT(error, tix+2);
                CALL_ERROR_CB();
                confd_free_eterm_keypath(*kpp);
            }
            free(*kpp);
        }
        break;

    case CONFD_ERR_NON_UNIQUE: {
        /* [keypath], [keypath], [value] */
        int n_elems = erl_length(ERL_TUPLE_ELEMENT(error, tix));
        int i;
        ETERM *kps1, *kps2, *vals, *hd;
        confd_value_t *vp;

        val_err->info.non_unique.n_elems = n_elems;
        if ((val_err->info.non_unique.kps1 =
             confd_malloc(n_elems * sizeof(confd_hkeypath_t))) != NULL) {
            if ((val_err->info.non_unique.kps2 =
                 confd_malloc(n_elems * sizeof(confd_hkeypath_t))) != NULL) {
                if ((val_err->info.non_unique.vals =
                     confd_malloc(n_elems * sizeof(confd_value_t))) != NULL) {
                    kps1 = ERL_TUPLE_ELEMENT(error, tix);
                    kps2 = ERL_TUPLE_ELEMENT(error, tix+1);
                    vals = ERL_TUPLE_ELEMENT(error, tix+2);

                    for (i = 0; i < n_elems; i++) {

                        hd = ERL_CONS_HEAD(kps1);
                        kp = &val_err->info.non_unique.kps1[i];
                        if (!populate_keypath(hd, kp))
                            break;
                        kps1 = ERL_CONS_TAIL(kps1);

                        hd = ERL_CONS_HEAD(kps2);
                        kp = &val_err->info.non_unique.kps2[i];
                        if (!populate_keypath(hd, kp))
                            break;
                        kps2 = ERL_CONS_TAIL(kps2);

                        hd = ERL_CONS_HEAD(vals);
                        vp = &val_err->info.non_unique.vals[i];
                        if (eterm_to_val(hd, vp) == NULL)
                            break;
                        vals = ERL_CONS_TAIL(vals);

                    }

                    if (i == n_elems) {
                        CALL_ERROR_CB();
                        for (i = 0; i < n_elems; i++) {
                            confd_free_eterm_keypath(
                                &val_err->info.non_unique.kps1[i]);
                            confd_free_eterm_keypath(
                                &val_err->info.non_unique.kps2[i]);
                            confd_free_eterm_val(
                                &val_err->info.non_unique.vals[i]);
                        }
                    }
                    free(val_err->info.non_unique.vals);
                }
                free(val_err->info.non_unique.kps2);
            }
            free(val_err->info.non_unique.kps1);
        }
    }
        break;

    case CONFD_ERR_BAD_KEYREF: {
        /* keypath, ref */
        ETERM *ref;

        kpp = &val_err->info.bad_keyref.kp;
        if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) != NULL) {
            if (populate_keypath(ERL_TUPLE_ELEMENT(error, tix), *kpp)) {
                kpp = &val_err->info.bad_keyref.ref;
                ref = ERL_TUPLE_ELEMENT(error, tix+1);
                if (ERL_IS_EMPTY_LIST(ref)) {
                    *kpp = NULL;
                    CALL_ERROR_CB();
                } else {
                    if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) !=
                        NULL) {
                        if (populate_keypath(ref, *kpp)) {
                            CALL_ERROR_CB();
                            confd_free_eterm_keypath(
                                val_err->info.bad_keyref.ref);
                        }
                        free(val_err->info.bad_keyref.ref);
                    }
                }
                confd_free_eterm_keypath(val_err->info.bad_keyref.kp);
            }
            free(val_err->info.bad_keyref.kp);
        }
    }
        break;

    case CONFD_ERR_UNSET_CHOICE: {
        /* choicepath, keypath */
        ETERM *choice_path;
        int cp_len;

        choice_path = ERL_TUPLE_ELEMENT(error, tix);
        cp_len = erl_length(choice_path);
        /* need the keypath for the choicepath */
        kpp = &val_err->info.unset_choice.kp;
        if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) != NULL) {
            if (populate_keypath(ERL_TUPLE_ELEMENT(error, tix+1), *kpp)) {
                confd_value_t cpath[cp_len + 1]; /* one elem for C_NOEXISTS */

                if (populate_choicepath(choice_path, cpath, cp_len, *kpp) ==
                    CONFD_OK) {
                    val_err->info.unset_choice.choice = cpath;
                    CALL_ERROR_CB();
                }
                confd_free_eterm_keypath(*kpp);
            }
            free(*kpp);
        }
    }
        break;

    case CONFD_ERR_MUST_FAILED:
        /* expr, keypath, message, apptag, value */
        val_err->info.must_failed.expr =
            (char *)ERL_BIN_PTR(ERL_TUPLE_ELEMENT(error, tix));
        kpp = &val_err->info.must_failed.kp;
        if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) != NULL) {
            if (populate_keypath(ERL_TUPLE_ELEMENT(error, tix+1), *kpp)) {
                term = ERL_TUPLE_ELEMENT(error, tix+2);
                val_err->info.must_failed.error_message =
                    ERL_IS_BINARY(term) ? (char *)ERL_BIN_PTR(term) : NULL;
                term = ERL_TUPLE_ELEMENT(error, tix+3);
                val_err->info.must_failed.error_app_tag =
                    ERL_IS_BINARY(term) ? (char *)ERL_BIN_PTR(term) : NULL;
                if (eterm_to_val(ERL_TUPLE_ELEMENT(error, tix+4), &v) != NULL) {
                    val_err->info.must_failed.val =
                        v.type != C_NOEXISTS ? &v : NULL;
                    CALL_ERROR_CB();
                    confd_free_eterm_val(&v);
                }
                confd_free_eterm_keypath(*kpp);
            }
            free(*kpp);
        }
        break;

    case CONFD_ERR_MISSING_INSTANCE:
        /* keypath, instance */
        kpp = &val_err->info.missing_instance.kp;
        if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) != NULL) {
            if (populate_keypath(ERL_TUPLE_ELEMENT(error, tix), *kpp)) {
                kpp = &val_err->info.missing_instance.instance;
                if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) != NULL) {
                    if (populate_keypath(ERL_TUPLE_ELEMENT(error, tix+1),
                                         *kpp)) {
                        CALL_ERROR_CB();
                        confd_free_eterm_keypath(
                            val_err->info.missing_instance.instance);
                    }
                    free(val_err->info.missing_instance.instance);
                }
                confd_free_eterm_keypath(val_err->info.missing_instance.kp);
            }
            free(val_err->info.missing_instance.kp);
        }
        break;

    case CONFD_ERR_INVALID_INSTANCE:
        /* keypath, instance */
        kpp = &val_err->info.invalid_instance.kp;
        if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) != NULL) {
            if (populate_keypath(ERL_TUPLE_ELEMENT(error, tix), *kpp)) {
                kpp = &val_err->info.invalid_instance.instance;
                if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) != NULL) {
                    if (populate_keypath(ERL_TUPLE_ELEMENT(error, tix+1),
                                         *kpp)) {
                        CALL_ERROR_CB();
                        confd_free_eterm_keypath(
                            val_err->info.invalid_instance.instance);
                    }
                    free(val_err->info.invalid_instance.instance);
                }
                confd_free_eterm_keypath(val_err->info.invalid_instance.kp);
            }
            free(val_err->info.invalid_instance.kp);
        }
        break;

    case CONFD_ERR_STALE_INSTANCE:
        /* keypath, instance */
        kpp = &val_err->info.stale_instance.kp;
        if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) != NULL) {
            if (populate_keypath(ERL_TUPLE_ELEMENT(error, tix), *kpp)) {
                kpp = &val_err->info.stale_instance.instance;
                if ((*kpp = confd_malloc(sizeof(confd_hkeypath_t))) != NULL) {
                    if (populate_keypath(ERL_TUPLE_ELEMENT(error, tix+1),
                                         *kpp)) {
                        CALL_ERROR_CB();
                        confd_free_eterm_keypath(
                            val_err->info.stale_instance.instance);
                    }
                    free(val_err->info.stale_instance.instance);
                }
                confd_free_eterm_keypath(val_err->info.stale_instance.kp);
            }
            free(val_err->info.stale_instance.kp);
        }
        break;

    case CONFD_ERR_POLICY_FAILED:
        /* error_message */
        val_err->info.policy_failed.error_message =
            (char *)ERL_BIN_PTR(ERL_TUPLE_ELEMENT(error, tix));
        CALL_ERROR_CB();
        break;

    case CONFD_ERR_POLICY_COMPILATION_FAILED:
        /* name, expr, msg */
        val_err->info.policy_compilation_failed.name =
            (char *)ERL_BIN_PTR(ERL_TUPLE_ELEMENT(error, tix));
        val_err->info.policy_compilation_failed.expr =
            (char *)ERL_BIN_PTR(ERL_TUPLE_ELEMENT(error, tix+1));
        val_err->info.policy_compilation_failed.msg =
            (char *)ERL_BIN_PTR(ERL_TUPLE_ELEMENT(error, tix+2));
        CALL_ERROR_CB();
        break;

    case CONFD_ERR_POLICY_EVALUATION_FAILED:
        /* name, expr, msg */
        val_err->info.policy_evaluation_failed.name =
            (char *)ERL_BIN_PTR(ERL_TUPLE_ELEMENT(error, tix));
        val_err->info.policy_evaluation_failed.expr =
            (char *)ERL_BIN_PTR(ERL_TUPLE_ELEMENT(error, tix+1));
        val_err->info.policy_evaluation_failed.msg =
            (char *)ERL_BIN_PTR(ERL_TUPLE_ELEMENT(error, tix+2));
        CALL_ERROR_CB();
        break;

    default:
        ret = confd_internal_error("Got error callback for unknown validation "
                                   "error code %d\n", val_err->code);
        break;

    }
    if (ret == CONFD_OK && confd_debug_level >= CONFD_TRACE)
        confd_trace_printf(" --> CONFD_OK\n");
    return ret;
}


static int error_callback_other(struct confd_daemon_ctx *dx,
                                struct confd_user_info *uinfo, int code,
                                struct confd_errinfo *errinfo,
                                ETERM *error, char *default_msg)
{
    int nparams = erl_length(error);
    struct confd_errinfo_param params[nparams];
    ETERM *plist, *param;
    int ret = CONFD_ERR;
    int i;

    plist = error;
    for (i = 0; i < nparams; i++) {
        param = ERL_CONS_HEAD(plist);
        plist = ERL_CONS_TAIL(plist);
        if (ERL_IS_LIST(param)) {
            params[i].type = CONFD_ERRINFO_KEYPATH;
            if ((params[i].val.kp = confd_malloc(sizeof(confd_hkeypath_t))) ==
                NULL)
                return CONFD_ERR;
            if (!populate_keypath(param, params[i].val.kp))
                return CONFD_ERR;
        } else {
            params[i].type = CONFD_ERRINFO_STRING;
            params[i].val.str = (char *)ERL_BIN_PTR(param);
        }
    }

    switch (errinfo->type) {
    case CONFD_ERRTYPE_BAD_VALUE:
        errinfo->info.bad_value.code = code;
        errinfo->info.bad_value.n_params = nparams;
        errinfo->info.bad_value.params = &params[0];
        break;
    case CONFD_ERRTYPE_CLI:
        errinfo->info.cli.code = code;
        errinfo->info.cli.n_params = nparams;
        errinfo->info.cli.params = &params[0];
        break;
    case CONFD_ERRTYPE_MISC:
        errinfo->info.misc.code = code;
        errinfo->info.misc.n_params = nparams;
        errinfo->info.misc.params = &params[0];
        break;
    default:
        return confd_internal_error("Got error callback for unknown type %d\n",
                                    errinfo->type);
    }

    CALL_ERROR_CB();

    plist = error;
    for (i = 0; i < nparams; i++) {
        param = ERL_CONS_HEAD(plist);
        plist = ERL_CONS_TAIL(plist);
        if (ERL_IS_LIST(param)) {
            confd_free_eterm_keypath(params[i].val.kp);
            free(params[i].val.kp);
        }
    }

    return ret;
}

static int error_callback(struct confd_daemon_ctx *dx, int qref,
                          struct confd_user_info *uinfo, int type, int code,
                          ETERM *error, char *default_msg)
{
    int op = CONFD_PROTO_ERROR_CB;
    int did = dx->daemon_id;
    struct confd_errinfo errinfo;
    int ret;
    ETERM *a[5];
    ETERM *tup;
    struct confd_error err;

    clear_error(&err);
    uinfo->errstr = NULL;
    errinfo.type = type;
    switch (type) {
    case CONFD_ERRTYPE_VALIDATION:
    case CONFD_ERRTYPE_OPERATION:
        ret = error_callback_validation(dx, uinfo, code,
                                        &errinfo, error, default_msg);
        break;
    default:
        ret = error_callback_other(dx, uinfo, code,
                                   &errinfo, error, default_msg);
        break;
    }
    if (ret == CONFD_OK) {
        a[0] = erl_mk_int(op);
        a[1] = erl_mk_int(qref);
        a[2] = erl_mk_int(did);
        a[3] = erl_mk_atom("ok");
        if (uinfo->errstr != NULL) {
            a[4] = erl_mk_binary(uinfo->errstr, strlen(uinfo->errstr));
            free(uinfo->errstr);
            uinfo->errstr = NULL;
        } else {
            a[4] = erl_mk_binary(default_msg, strlen(default_msg));
        }
        if ((tup = erl_mk_tuple(a, 5)) == NULL) {
            return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
        }
        ret = term_write(dx->ctl_sock, tup, -1, -1);
        erl_free_compound(tup);
    } else {
        if (confd_errno == CONFD_ERR_INTERNAL) {
            set_error(&err, CONFD_ERRCODE_INTERNAL, 0, 0,
                      "Unknown error code");
        } else {
            set_error(&err, CONFD_ERRCODE_RESOURCE_DENIED, 0, 0,
                      "Failed to alloc");
        }
        reply_error(dx->ctl_sock, op, qref, did, &err);
    }
    return ret;
}


static int init_dbctx(struct confd_db_ctx *dbctx,
                      struct confd_daemon_ctx *dx,
                      ETERM *et, int op,
                      int usid)
{
    dbctx->qref = TUINT(et, 1);
    dbctx->lastop = op;
    dbctx->did = TUINT(et, 2);
    dbctx->dx = dx;
    clear_error(&dbctx->error);
    if ((dbctx->uinfo = get_user_session(dx, usid)) == NULL) {
        confd_internal_error("Got %d op on non existing user sess %d",
                             op, usid);
        return 0;
    }
    return 1;
}

static char *dbname2str(enum confd_dbname s)
{
    switch (s) {
    case CONFD_CANDIDATE: return ("candidate");
    case CONFD_RUNNING: return ("running");
    case CONFD_STARTUP: return ("startup");
    case CONFD_OPERATIONAL: return ("operational");
    case CONFD_TRANSACTION: return ("transaction");
    case CONFD_PRE_COMMIT_RUNNING: return ("pre_commit_running");
    case CONFD_INTENDED: return ("intended");
    case CONFD_NO_DB: return ("not set");
    }
    return ("Unknown");
}

int confd_aaa_reload(const struct confd_trans_ctx *tctx)
{
    int ret;
    ETERM *e = erl_mk_atom("aaa_reload");
    ret = term_write(tctx->fd, e, -1, -1);
    erl_free_compound(e);
    return ret;
}

static void free_accumulated(struct confd_trans_ctx *tctx)
{
    if (tctx->accumulated != NULL) {
        struct confd_tr_item *x = tctx->accumulated;
        while (x) {
            struct confd_tr_item *next = x->next;
            free(x->callpoint);
            confd_free_hkeypath(x->hkp);
            if (x->val != NULL) {
                if (x->op == C_MOVE_AFTER) {
                    int i;
                    for (i = 0; x->val[i].type != C_NOEXISTS; i++)
                        confd_free_value(&x->val[i]);
                } else {
                    confd_free_value(x->val);
                }
                free(x->val);
            }
            if (x->choice != NULL) {
                free(x->choice);
            }
            free(x);
            x = next;
        }
    }
    tctx->accumulated = NULL;
}


int confd_fd_ready(struct confd_daemon_ctx *dx, int sock)
{
    ETERM *et;
    int op, qref, did, tid, usid, thandle;
    struct confd_trans_ctx *tctx;
    int ret = CONFD_OK;
    enum confd_dbname dbname;
    struct confd_db_ctx dbctx;
    struct confd_user_info *uinfo;
    ETERM *request_data;
    int hide_inactive;

    clr_confd_err();
    if ((et = term_read(sock, &ret, -1)) == NULL)
        return ret;

    op = TUINT(et, 0);
    switch (op) {

    case CONFD_PROTO_NEW_USESS: {
        ETERM *hd, *tl;
        int i, is_update;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        tl = TE(et, 3);

        /*  NOTE: This may include updates of sessions received earlier */
        uinfo = NULL;
        for (i = erl_length(tl); i > 0; i--) {
            hd = ERL_CONS_HEAD(tl);
            tl = ERL_CONS_TAIL(tl);
            uinfo = add_user_session(dx, hd, i == 1 ? 2 : 1, &is_update);
            if (uinfo == NULL) { /* malloc failed */
                ret = CONFD_ERR;
                goto doret;
            }
            if (!is_update && dx->usess_cb.start != NULL)
                dx->usess_cb.start(dx, uinfo);
        }
        if (!init_dbctx(&dbctx, dx, et, op, uinfo->usid)) {
            ret = db_reply(&dbctx, CONFD_ERR);
        } else {
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    }

    case CONFD_PROTO_CLOSE_USESS: {
        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        usid = TUINT(et, 3);
        confd_trace(CONFD_TRACE, "Close user sess %d\n", usid);
        if (!init_dbctx(&dbctx, dx, et, op, usid)) {
            /* usess not found */
            ret = db_reply(&dbctx, CONFD_ERR);
        } else {
            if (dx->usess_cb.stop != NULL)
                dx->usess_cb.stop(dx, dbctx.uinfo);
            ret = db_reply(&dbctx, CONFD_OK);
            put_user_session(dx, dbctx.uinfo);
        }
        break;
    }

    case  CONFD_PROTO_NEW_TRANS: {
        enum confd_trans_mode mode;
        int put_tctx = 0;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        /* 3 not used */
        dbname = (enum confd_dbname) TUINT(et, 4);
        usid = TUINT(et, 5);
        mode = (enum confd_trans_mode)TUINT(et, 6);
        thandle = TUINT(et, 7);
        request_data = TE(et, 8);
        hide_inactive = TUINT(et, 9);

        if (dx->trans_cb.init == NULL) {
            /* "can't happen" since we check in confd_register_done() */
            ret = ret_err(CONFD_ERR_PROTOUSAGE,
                          "No transaction init() callback registered");
            goto doret;
        }
        /* If we have an existing transaction, reuse it, otherwise alloc*/
        if ((tctx = get_transaction(dx, thandle)) != NULL) {
            /* reuse trans */
            if ((ret = update_usess(tctx, usid, "new_trans")) != CONFD_OK)
                goto doret;
            tctx->query_ref = qref;
            tctx->mode = mode;
            tctx->lastop = op;
            clear_error(&tctx->error);
            set_request_data(tctx, request_data);
            tctx->hide_inactive = hide_inactive;
            confd_trace(CONFD_TRACE,
                        "CALL trans init(thandle=%d,mode=%s,db=%s)",
                        tctx->thandle,
                        tctx->mode == CONFD_READ ? "\"r\"" : "\"rw\"",
                        dbname2str(tctx->dbname));
            ret = dx->trans_cb.init(tctx);
            if (ret == CONFD_ERR)
                put_tctx = 1;
            ret = trans_reply(tctx, ret);
        }
        else if ((tctx = alloc_transaction(dx, thandle)) != NULL) {
            if ((uinfo = get_user_session(dx, usid)) == NULL) {
                return confd_internal_error(
                    "Got new-trans on non existing user session %d\n",usid);
            }
            tctx->query_ref = qref;
            tctx->mode = mode;
            tctx->dbname = dbname;
            tctx->lastop = op;
            clear_error(&tctx->error);
            tctx->uinfo = uinfo;
            set_request_data(tctx, request_data);
            tctx->hide_inactive = hide_inactive;
            confd_trace(CONFD_TRACE,
                        "CALL trans init(thandle=%d,mode=%s,db=%s)",
                        tctx->thandle,
                        tctx->mode == CONFD_READ ? "\"r\"" : "\"rw\"",
                        dbname2str(tctx->dbname));
            ret = dx->trans_cb.init(tctx);
            if (ret == CONFD_ERR)
                put_tctx = 1;
            ret = trans_reply(tctx, ret);
        }
        else {
            confd_trace(CONFD_DEBUG, "Cannot alloc trans\n");
            ret = CONFD_ERR;
        }
        if (put_tctx && put_transaction(tctx)) {
            tctx_free(tctx);
        }
        break;
    }

    case  CONFD_PROTO_NEW_VALIDATE: {
        int testonly;
        int put_tctx = 0;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        dbname = (enum confd_dbname) TUINT(et, 3);
        usid = TUINT(et, 4);
        thandle = TUINT(et, 5);
        testonly = bin_eq(TE(et, 6), "true");
        request_data = TE(et, 7);

        if (dx->trans_validate_cb.init == NULL) {
            /* "can't happen" since we check in confd_register_done() */
            ret = ret_err(CONFD_ERR_PROTOUSAGE,
                          "No validation init() callback registered");
            goto doret;
        }
        /* If we have an existing transaction, reuse it, otherwise alloc*/
        if ((tctx = get_transaction(dx, thandle)) != NULL) {
            /* reuse trans */
            if ((ret = update_usess(tctx, usid, "new_validate")) != CONFD_OK)
                goto doret;
            tctx->query_ref = qref;
            tctx->lastop = op;
            clear_error(&tctx->error);
            tctx->validation_info = testonly ? CONFD_VALIDATION_FLAG_TEST : 0;
            set_request_data(tctx, request_data);
            confd_trace(CONFD_TRACE, "CALL  validate init(thandle=%d)",
                        tctx->thandle);
            ret = dx->trans_validate_cb.init(tctx);
            if (ret == CONFD_ERR)
                put_tctx = 1;
            ret = trans_reply(tctx, ret);
        }
        else if ((tctx = alloc_transaction(dx, thandle)) != NULL) {
            if ((uinfo = get_user_session(dx, usid)) == NULL) {
                return confd_internal_error(
                   "Got new-validation on non existing user session %d\n",usid);
            }
            tctx->query_ref = qref;
            tctx->mode = CONFD_READ;  /* FIXME */
            tctx->dbname = dbname;
            tctx->lastop = op;
            clear_error(&tctx->error);
            tctx->uinfo = uinfo;
            tctx->validation_info = testonly ? CONFD_VALIDATION_FLAG_TEST : 0;
            set_request_data(tctx, request_data);
            tctx->hide_inactive = 1;
            confd_trace(CONFD_TRACE, "CALL  validate init(thandle=%d)",
                        tctx->thandle);
            ret = dx->trans_validate_cb.init(tctx);
            if (ret == CONFD_ERR)
                put_tctx = 1;
            ret = trans_reply(tctx, ret);
        }
        else {
            confd_trace(CONFD_DEBUG, "Cannot alloc trans\n");
            ret = CONFD_ERR;
        }
        if (put_tctx && put_transaction(tctx)) {
            tctx_free(tctx);
        }
        break;
    }

    case  CONFD_PROTO_NEW_ACTION: {
        ETERM *actionpoint;
        int index, thandle;
        struct confd_action_cbs *acb;
        struct confd_action_ctx *actx;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        usid = TUINT(et, 3);
        actionpoint = ERL_TUPLE_ELEMENT(et, 4);
        index = TUINT(et, 5);
        thandle = TUINT(et, 6);
        if ((uinfo = get_user_session(dx, usid)) == NULL) {
            return confd_internal_error(
                "Got new-action on non existing user session %d\n",usid);
        }
        if ((acb = tag_to_actcbs(dx, actionpoint, index)) == NULL) {
            char tbuf[MAX_CALLPOINT_LEN];
            bin_copy(tbuf, MAX_CALLPOINT_LEN, actionpoint);
            ret = confd_internal_error("No actionpoint found for %s\n",tbuf);
            put_user_session(dx, uinfo);
            goto doret;
        }
        actx = &uinfo->actx;
        PTHREAD_MUTEX_LOCK(dx->slock);
        if (actx->state != ACT_STATE_NONE && actx->state != ACT_STATE_ABORTED) {
            PTHREAD_MUTEX_UNLOCK(dx->slock);
            action_reply_busy(sock, op, qref, did,
                              "action already executing");
            ret = ret_err(CONFD_ERR_EXTERNAL,
                          "action already executing for user session %d", usid);
            put_user_session(dx, uinfo);
            goto doret;
        }
        actx->state = ACT_STATE_INIT;
        PTHREAD_MUTEX_UNLOCK(dx->slock);
        actx->fd = -1;
        actx->dx = dx;
        actx->t_opaque = NULL;
        clear_error(&actx->error);
        actx->cb_opaque = acb->cb_opaque;
        actx->thandle = thandle;
        actx->last_op = op;
        actx->seen_reply = 0;
        actx->rterm = NULL;
        actx->query_ref = qref;
        actx->acb = acb;
        confd_trace(CONFD_TRACE, "CALL action init(usid=%d)", usid);
        ret = new_action_reply(uinfo, acb->init(uinfo));
        if (ret != CONFD_OK) {
            put_user_session(dx, uinfo);
        }
        break;
    }

    case  CONFD_PROTO_ABORT_ACTION: {
        struct confd_action_cbs *acb;
        struct confd_action_ctx *actx;
        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        usid = TUINT(et, 3);
        if ((uinfo = get_user_session(dx, usid)) == NULL) {
            return confd_internal_error(
                "Got abort-action on non existing user session %d\n",usid);
        }
        actx = &(uinfo->actx);
        PTHREAD_MUTEX_LOCK(actx->dx->slock);
        if (actx->state == ACT_STATE_NONE) {
            PTHREAD_MUTEX_UNLOCK(actx->dx->slock);
            confd_trace(CONFD_TRACE, "Ignoring action abort(usid=%d), "
                        "no action executing", usid);
        } else {
            if (actx->state == ACT_STATE_INIT)
                actx->state = ACT_STATE_ABORTED;
            PTHREAD_MUTEX_UNLOCK(actx->dx->slock);
            acb = actx->acb;
            if (acb && acb->abort) {
                confd_trace(CONFD_TRACE, "CALL action abort(usid=%d)", usid);
                acb->abort(uinfo);
                if (confd_debug_level >= CONFD_TRACE) {
                    confd_trace_printf(" --> CONFD_OK\n");
                }
            } else {
                confd_trace(CONFD_TRACE, "NULL action abort(usid=%d)\n", usid);
            }
        }
        ret = async_ctl_reply(dx, op, qref);
        put_user_session(dx, uinfo);
        break;
    }

    case  CONFD_PROTO_NOTIF_GET_LOG_TIMES: {
        ETERM *streamname;
        int index;
        struct confd_notification_stream_cbs *ncbs;
        struct confd_notification_ctx nctx;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        streamname = ERL_TUPLE_ELEMENT(et, 3);
        index = TUINT(et, 4);
        if ((ncbs = tag_to_notifcbs(dx, streamname, index)) == NULL) {
            char tbuf[MAX_STREAMNAME_LEN];
            bin_copy(tbuf, MAX_STREAMNAME_LEN, streamname);
            ret = confd_internal_error(
                "No stream registration found for %s\n",tbuf);
            goto doret;
        }
        nctx.name = &ncbs->streamname[0];
        nctx.ctx_name = NULL;
        nctx.fd = ncbs->fd;
        nctx.dx = dx;
        clear_error(&nctx.error);
        nctx.cb_opaque = ncbs->cb_opaque;
        nctx.subid = 0;
        nctx.seen_reply = 0;
        nctx.query_ref = qref;
        confd_trace(CONFD_TRACE,
                    "CALL notification stream get_log_times(stream=%s)",
                    nctx.name);
        ret = notif_get_log_times_reply(&nctx,
                                        ncbs->get_log_times(&nctx));
        break;
    }

    case  CONFD_PROTO_NOTIF_REPLAY: {
        ETERM *streamname;
        int index;
        int subid;
        ETERM *estart, *estop;
        struct confd_notification_stream_cbs *ncbs;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        streamname = ERL_TUPLE_ELEMENT(et, 3);
        index = TUINT(et, 4);
        subid = TUINT(et, 5);
        estart = ERL_TUPLE_ELEMENT(et, 6);
        estop = ERL_TUPLE_ELEMENT(et, 7);
        if ((ncbs = tag_to_notifcbs(dx, streamname, index)) == NULL) {
            char tbuf[MAX_STREAMNAME_LEN];
            bin_copy(tbuf, MAX_STREAMNAME_LEN, streamname);
            ret = confd_internal_error(
                "No stream registration found for %s\n",tbuf);
            goto doret;
        }
        ret = notif_replay(dx, qref, ncbs, subid, estart, estop);
        break;
    }

    case  CONFD_PROTO_NOTIF_SNMP_INFORM_TARGETS:
    case  CONFD_PROTO_NOTIF_SNMP_INFORM_RESULT: {
        ETERM *cb_id;
        int index;
        struct confd_notification_snmp_inform_cbs *cb;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        cb_id = ERL_TUPLE_ELEMENT(et, 3);
        index = TUINT(et, 4);
        if ((cb = tag_to_snmp_informcbs(dx, cb_id, index)) == NULL) {
            char tbuf[MAX_CALLPOINT_LEN];
            bin_copy(tbuf, MAX_CALLPOINT_LEN, cb_id);
            ret = confd_internal_error("No snmp inform "
                          "registration found for %s\n",tbuf);
            goto doret;
        }
        ret = notif_snmp_inform(dx, qref, cb, op, et);
        break;
    }

    case  CONFD_PROTO_NOTIF_RECV_SNMP: {
        ETERM *sub_id;
        int index;
        ETERM *notification, *varbinds, *srcaddr;
        u_int16_t srcport;
        struct confd_notification_sub_snmp_cb *cb;
        int n;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        sub_id = ERL_TUPLE_ELEMENT(et, 3);
        index = TUINT(et, 4);
        notification = ERL_TUPLE_ELEMENT(et, 5);
        varbinds = ERL_TUPLE_ELEMENT(et, 6);
        srcaddr = ERL_TUPLE_ELEMENT(et, 7);
        srcport = TUINT(et, 8);
        if ((cb = tag_to_sub_snmpcbs(dx, sub_id, index)) == NULL) {
            char tbuf[MAX_CALLPOINT_LEN];
            bin_copy(tbuf, MAX_CALLPOINT_LEN, sub_id);
            ret = confd_internal_error("No snmp notification "
                          "subscription found for %s\n",tbuf);
            goto doret;
        }
        n = erl_length(varbinds);
        ret = notif_recv_snmp(dx, qref, cb, notification,
                              varbinds, n, srcaddr, srcport);
        break;
    }

    case CONFD_PROTO_AUTH_CB: {
        ETERM *utup;
        ETERM *method;
        ETERM *result;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        utup = ERL_TUPLE_ELEMENT(et, 3);
        method = ERL_TUPLE_ELEMENT(et, 4);
        result = ERL_TUPLE_ELEMENT(et, 5);
        if (dx->auth_cb.auth == NULL) {
            ret = confd_internal_error("No authentication callback "
                                       "registration found\n");
            goto doret;
        }
        ret = auth_callback(dx, qref, utup, method, result);
        break;
    }

    case CONFD_PROTO_CHK_CMD_ACCESS: {
        ETERM *groups;
        ETERM *cmd;
        int cmdop;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        usid = TUINT(et, 3);
        groups = TE(et, 4);
        cmd = TE(et, 5);
        cmdop = TUINT(et, 6);
        if (usid == 0) {
            /* e.g. check of "logout" permission in CLI when too many
               sessions - there is no session for the current user yet */
            uinfo = NULL;
        } else {
            if ((uinfo = get_user_session(dx, usid)) == NULL) {
                /* assume race condition - the user session has terminated,
                   but the callback invocation from aaa progresses anyway
                   - fake a "reject" reply to keep socket protocol synced */
                ret = access_callback_result(
                    dx, qref, CONFD_PROTO_CHK_CMD_ACCESS, CONFD_OK,
                    CONFD_ACCESS_RESULT_REJECT, CONFD_SILENT);
                goto doret;
            }
        }
        if (dx->authorization_cbs.chk_cmd_access == NULL) {
            ret = confd_internal_error("No chk_cmd_access callback "
                                       "registration found\n");
            if (uinfo != NULL)
                put_user_session(dx, uinfo);
            goto doret;
        }
        ret = cmd_access_callback(dx, qref, uinfo, groups, cmd, cmdop);
        if (uinfo != NULL)
            put_user_session(dx, uinfo);
        break;
    }

    case CONFD_PROTO_CHK_DATA_ACCESS: {
        ETERM *groups;
        u_int32_t ns;
        ETERM *kp;
        int dataop;
        int how;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        usid = TUINT(et, 3);
        groups = TE(et, 4);
        ns = TUINT(et, 5);
        kp = TE(et, 6);
        dataop = TUINT(et, 7);
        how = TUINT(et, 8);
        if ((uinfo = get_user_session(dx, usid)) == NULL) {
            /* assume race condition - the user session has terminated,
               but the callback invocation from aaa progresses anyway
               - fake a "reject" reply to keep socket protocol synced */
            ret = access_callback_result(
                dx, qref, CONFD_PROTO_CHK_DATA_ACCESS, CONFD_OK,
                CONFD_ACCESS_RESULT_REJECT, CONFD_SILENT);
            goto doret;
        }
        if (dx->authorization_cbs.chk_data_access == NULL) {
            ret = confd_internal_error("No chk_data_access callback "
                                       "registration found\n");
            put_user_session(dx, uinfo);
            goto doret;
        }
        ret = data_access_callback(dx, qref, uinfo, groups, ns, kp, dataop,how);
        put_user_session(dx, uinfo);
        break;
    }

    case  CONFD_PROTO_ERROR_CB: {
        int type, code;
        ETERM *error;
        char *default_msg;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        usid = TUINT(et, 3);
        type = TUINT(et, 4);
        code = TUINT(et, 5);
        error = ERL_TUPLE_ELEMENT(et, 6);
        default_msg = (char *)ERL_BIN_PTR(ERL_TUPLE_ELEMENT(et, 7));
        if ((dx->error_cb.error_types & type) == 0 ||
            dx->error_cb.format_error == NULL) {
            ret = confd_internal_error("No error callback registration "
                                       "found for error type %d\n", type);
            goto doret;
        }
        if ((uinfo = get_user_session(dx, usid)) == NULL) {
            ret = confd_internal_error(
                "Got error callback on non existing user session %d\n",usid);
            goto doret;
        }
        ret = error_callback(dx, qref, uinfo, type, code, error, default_msg);
        put_user_session(dx, uinfo);
        break;
    }

    case CONFD_PROTO_TRANS_LOCK: {
        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        tid = TUINT(et, 3);
        request_data = TE(et, 4);
        usid = TUINT(et, 5);
        hide_inactive = TUINT(et, 6);

        if ((tctx = tid_to_trans(dx, tid)) != NULL) {
            if ((ret = update_usess(tctx, usid, "trans_lock")) != CONFD_OK)
                goto doret;
            tctx->query_ref = qref;
            tctx->seen_reply = 0;
            tctx->lastop = CONFD_PROTO_TRANS_LOCK;
            clear_error(&tctx->error);
            set_request_data(tctx, request_data);
            tctx->hide_inactive = hide_inactive;
            if (dx->trans_cb.trans_lock != NULL) {
                confd_trace(CONFD_TRACE, "CALL trans_lock(thandle=%d)",
                            tctx->thandle);
                ret = trans_reply(tctx, dx->trans_cb.trans_lock(tctx));
            }
            else {
                confd_trace(CONFD_TRACE, "NULL trans_lock(thandle=%d)\n",
                            tctx->thandle);
                ret = i_trans_reply_ok(tctx);
            }
        }
        else {
            ret = confd_internal_error("No trans found with tid=%d\n",tid);
        }
        break;
    }

    case CONFD_PROTO_TRANS_UNLOCK: {
        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        tid = TUINT(et, 3);
        request_data = TE(et, 4);
        usid = TUINT(et, 5);
        hide_inactive = TUINT(et, 6);

        if ((tctx = tid_to_trans(dx, tid)) != NULL) {
            if ((ret = update_usess(tctx, usid, "trans_unlock")) != CONFD_OK)
                goto doret;
            tctx->query_ref = qref;
            tctx->seen_reply = 0;
            tctx->lastop = CONFD_PROTO_TRANS_UNLOCK;
            clear_error(&tctx->error);
            set_request_data(tctx, request_data);
            tctx->hide_inactive = hide_inactive;
            if (dx->trans_cb.trans_unlock != NULL) {
                confd_trace(CONFD_TRACE, "CALL trans_unlock(thandle=%d)",
                            tctx->thandle);
                ret = trans_reply(tctx, dx->trans_cb.trans_unlock(tctx));
            }
            else {
                confd_trace(CONFD_TRACE, "NULL trans_unlock(thandle=%d)\n",
                            tctx->thandle);
                ret = i_trans_reply_ok(tctx);
            }
        }
        else {
            ret = confd_internal_error("No trans found with tid=%d\n",tid);
        }
        break;
    }

    case CONFD_PROTO_WRITE_START: {
        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        tid = TUINT(et, 3);
        request_data = TE(et, 4);
        usid = TUINT(et, 5);
        hide_inactive = TUINT(et, 6);

        if ((tctx = tid_to_trans(dx, tid)) != NULL) {
            if ((ret = update_usess(tctx, usid, "write_start")) != CONFD_OK)
                goto doret;
            tctx->query_ref = qref;
            tctx->seen_reply = 0;
            tctx->lastop = CONFD_PROTO_WRITE_START;
            clear_error(&tctx->error);
            set_request_data(tctx, request_data);
            tctx->hide_inactive = hide_inactive;
            if (dx->trans_cb.write_start != NULL) {
                confd_trace(CONFD_TRACE, "CALL write_start(thandle=%d)",
                            tctx->thandle);
                ret = trans_reply(tctx, dx->trans_cb.write_start(tctx));
            }
            else {
                confd_trace(CONFD_TRACE, "NULL write_start(thandle=%d)\n",
                            tctx->thandle);
                ret = i_trans_reply_ok(tctx);
            }
        }
        else {
            ret = confd_internal_error("No trans found with tid=%d\n",tid);
        }
        break;
    }

    case CONFD_PROTO_PREPARE: {
        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        tid = TUINT(et, 3);
        request_data = TE(et, 4);
        usid = TUINT(et, 5);
        hide_inactive = TUINT(et, 6);

        if ((tctx = tid_to_trans(dx, tid)) != NULL) {
            if ((ret = update_usess(tctx, usid, "prepare")) != CONFD_OK)
                goto doret;
            tctx->query_ref = qref;
            tctx->seen_reply = 0;
            tctx->lastop = CONFD_PROTO_PREPARE;
            clear_error(&tctx->error);
            set_request_data(tctx, request_data);
            tctx->hide_inactive = hide_inactive;
            if (dx->trans_cb.prepare != NULL) {
                confd_trace(CONFD_TRACE, "CALL trans prepare(thandle=%d)",
                            tctx->thandle);
                ret = trans_reply(tctx, dx->trans_cb.prepare(tctx));
            }
            else {
                confd_trace(CONFD_TRACE,"NULL trans prepare(thandle=%d)\n",
                            tctx->thandle);
                ret = i_trans_reply_ok(tctx);
            }
        }
        else {
            ret = confd_internal_error("No trans found with tid=%d\n",tid);
        }
        break;
    }

    case CONFD_PROTO_ABORT: {

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        tid = TUINT(et, 3);
        request_data = TE(et, 4);
        usid = TUINT(et, 5);
        hide_inactive = TUINT(et, 6);

        if ((tctx = tid_to_trans(dx, tid)) != NULL) {
            if ((ret = update_usess(tctx, usid, "abort")) != CONFD_OK)
                goto doret;
            tctx->query_ref = qref;
            tctx->seen_reply = 0;
            tctx->lastop = CONFD_PROTO_ABORT;
            clear_error(&tctx->error);
            set_request_data(tctx, request_data);
            tctx->hide_inactive = hide_inactive;
            if (dx->trans_cb.abort != NULL) {
                confd_trace(CONFD_TRACE, "CALL trans abort(thandle=%d)",
                            tctx->thandle);
                ret = trans_reply(tctx,dx->trans_cb.abort(tctx));
            }
            else {
                confd_trace(CONFD_TRACE, "NULL trans abort(thandle=%d)\n",
                            tctx->thandle);
                ret = i_trans_reply_ok(tctx);
            }
        }
        else {
            ret = confd_internal_error("No trans found with tid=%d\n",tid);
        }
        break;
    }

    case CONFD_PROTO_COMMIT: {
        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        tid = TUINT(et, 3);
        request_data = TE(et, 4);
        usid = TUINT(et, 5);
        hide_inactive = TUINT(et, 6);

        if ((tctx = tid_to_trans(dx, tid)) != NULL) {
            if ((ret = update_usess(tctx, usid, "commit")) != CONFD_OK)
                goto doret;
            tctx->query_ref = qref;
            tctx->seen_reply = 0;
            tctx->lastop = CONFD_PROTO_COMMIT;
            clear_error(&tctx->error);
            set_request_data(tctx, request_data);
            tctx->hide_inactive = hide_inactive;
            if (dx->trans_cb.commit != NULL) {
                confd_trace(CONFD_TRACE, "CALL trans commit(thandle=%d)",
                            tctx->thandle);
                ret = trans_reply(tctx, dx->trans_cb.commit(tctx));
            }
            else {
                confd_trace(CONFD_TRACE, "NULL trans commit(thandle=%d)\n",
                            tctx->thandle);
                ret = i_trans_reply_ok(tctx);
            }
        }
        else {
            ret = confd_internal_error("No trans found with tid=%d\n",tid);
        }
        break;
    }

    case CONFD_PROTO_INTERRUPT: {
        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        tid = TUINT(et, 3);

        /* this is async on control socket - must not modify tctx,
           OK if no tctx exists, must get/put a reference if exists */
        if ((tctx = get_transaction(dx, tid)) != NULL) {
            if (dx->trans_cb.interrupt != NULL) {
                confd_trace(CONFD_TRACE, "CALL trans interrupt(thandle=%d)",
                            tctx->thandle);
                dx->trans_cb.interrupt(tctx);
                if (confd_debug_level >= CONFD_TRACE) {
                    confd_trace_printf(" --> CONFD_OK\n");
                }
            }
            else {
                confd_trace(CONFD_TRACE, "NULL trans interrupt(thandle=%d)\n",
                            tctx->thandle);
            }
            if (put_transaction(tctx)) {
                tctx_free(tctx);
            }
        }
        ret = async_ctl_reply(dx, op, qref);
        break;
    }

    case CONFD_PROTO_CLOSE_TRANS: {
        int put_tctx;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        tid = TUINT(et, 3);
        request_data = TE(et, 4);
        usid = TUINT(et, 5);
        hide_inactive = TUINT(et, 6);

        if ((tctx = tid_to_trans(dx, tid)) != NULL) {
            if ((ret = update_usess(tctx, usid, "close_trans")) != CONFD_OK)
                goto doret;
            tctx->query_ref = qref;
            tctx->seen_reply = 0;
            tctx->lastop = CONFD_PROTO_CLOSE_TRANS;
            clear_error(&tctx->error);
            set_request_data(tctx, request_data);
            tctx->hide_inactive = hide_inactive;
            if (dx->trans_cb.finish != NULL) {
                confd_trace(CONFD_TRACE, "CALL trans finish(thandle=%d)",
                            tctx->thandle);
                ret = dx->trans_cb.finish(tctx);
                free_accumulated(tctx);
                if (ret == CONFD_DELAYED_RESPONSE)
                    put_tctx = 0;
                else
                    put_tctx = 1;
                ret = trans_reply(tctx,ret);
            }
            else {
                confd_trace(CONFD_TRACE, "NULL trans finish(thandle=%d)\n",
                            tctx->thandle);
                free_accumulated(tctx);
                put_tctx = 1;
                ret = i_trans_reply_ok(tctx);
            }
            if (put_tctx && put_transaction(tctx)) {
                tctx_free(tctx);
            }
        }
        else {
            ret = confd_internal_error("No trans found with tid=%d\n",tid);
        }
        break;
    }

    case CONFD_PROTO_CLOSE_VALIDATE: {
        int put_tctx;
        int commit;

        qref = TUINT(et, 1);
        did = TUINT(et, 2);
        tid = TUINT(et, 3);
        commit = bin_eq(TE(et, 4), "true");
        request_data = TE(et, 5);
        usid = TUINT(et, 6);

        if ((tctx = tid_to_trans(dx, tid)) != NULL) {
            if ((ret = update_usess(tctx, usid, "close_validate")) != CONFD_OK)
                goto doret;
            tctx->query_ref = qref;
            tctx->seen_reply = 0;
            tctx->lastop = CONFD_PROTO_CLOSE_VALIDATE;
            clear_error(&tctx->error);
            if (commit)
                tctx->validation_info |= CONFD_VALIDATION_FLAG_COMMIT;
            set_request_data(tctx, request_data);
            if (dx->trans_validate_cb.stop != NULL) {
                confd_trace(CONFD_TRACE,"CALL validation stop(thandle=%d)",
                            tctx->thandle);
                ret = dx->trans_validate_cb.stop(tctx);
                if (ret == CONFD_DELAYED_RESPONSE)
                    put_tctx = 0;
                else
                    put_tctx = 1;
                ret = trans_reply(tctx, ret);
            }
            else {
                confd_trace(CONFD_TRACE,
                            "NULL validation stop(thandle=%d)\n",
                            tctx->thandle);
                put_tctx = 1;
                ret = i_trans_reply_ok(tctx);
            }
            if (put_tctx && put_transaction(tctx)) {
                tctx_free(tctx);
            }
        }
        else {
            ret = confd_internal_error("No trans found with tid=%d\n",tid);
        }
        break;
    }



    case CONFD_PROTO_CALLBACK:
        ret = proto_callback(dx, et);
        break;
    case CONFD_PROTO_CANDIDATE_COMMIT: {
        int timeout;
        usid = TUINT(et, 3);
        timeout = TUINT(et, 4);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.candidate_commit != NULL) {
            confd_trace(CONFD_TRACE, "CALL candidate_commit(timeout=%d)",
                        timeout);
            ret = db_reply(&dbctx,dx->db_cb.candidate_commit(&dbctx, timeout));
        }
        else {
            confd_trace(CONFD_TRACE, "Warn: NULL candidate_commit(%d)",
                        timeout);
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    }
    case  CONFD_PROTO_CANDIDATE_ROLLBACK_RUNNING:
        usid = TUINT(et, 3);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.candidate_rollback_running != NULL) {
            confd_trace(CONFD_TRACE,"CALL candidate_rollback_running()");
            ret =
                db_reply(&dbctx,dx->db_cb.candidate_rollback_running(&dbctx));
        }
        else {
            confd_trace(CONFD_TRACE,"Warn: NULL candidate_rollback_running()");
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    case  CONFD_PROTO_CANDIDATE_CONFIRMING_COMMIT:
        usid = TUINT(et, 3);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.candidate_confirming_commit != NULL) {
            confd_trace(CONFD_TRACE,"CALL candidate_confirming_commit()");
            ret = db_reply(&dbctx,
                           dx->db_cb.candidate_confirming_commit(&dbctx));
        }
        else {
            confd_trace(CONFD_TRACE,"Warn NULL candidate_confirming_commit()");
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    case  CONFD_PROTO_CANDIDATE_RESET:
        usid = TUINT(et, 3);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.candidate_reset != NULL) {
            confd_trace(CONFD_TRACE, "CALL candidate_reset()");
            ret = db_reply(&dbctx, dx->db_cb.candidate_reset(&dbctx));
        }
        else {
            confd_trace(CONFD_TRACE,"Warn NULL candidate_reset()");
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    case  CONFD_PROTO_CANDIDATE_VALIDATE:
        usid = TUINT(et, 3);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.candidate_validate != NULL) {
            confd_trace(CONFD_TRACE, "CALL db candidate_validate()");
            ret = db_reply(&dbctx,dx->db_cb.candidate_validate(&dbctx));
        }
        else {
            confd_trace(CONFD_TRACE, "NULL db candidate_validate()");
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    case  CONFD_PROTO_CANDIDATE_CHK_NOT_MODIFIED:
        usid = TUINT(et, 3);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.candidate_chk_not_modified != NULL) {
            confd_trace(CONFD_TRACE,
                        "CALL db candidate_chk_not_modified()");
            ret = db_reply(&dbctx,dx->db_cb.candidate_chk_not_modified(
                               &dbctx));
        }
        else {
            confd_trace(CONFD_TRACE,
                        "Warn NULL db candidate_chk_not_modified()");
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    case  CONFD_PROTO_ADD_CHECKPOINT_RUNNING:
        usid = TUINT(et, 3);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.add_checkpoint_running != NULL) {
            confd_trace(CONFD_TRACE, "CALL add_checkpoint_running()");
            ret = db_reply(&dbctx,dx->db_cb.add_checkpoint_running(
                               &dbctx));
        }
        else {
            confd_trace(CONFD_TRACE,"Warn NULL add_checkpoint_running()");
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    case  CONFD_PROTO_DEL_CHECKPOINT_RUNNING:
        usid = TUINT(et, 3);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.del_checkpoint_running != NULL) {
            confd_trace(CONFD_TRACE, "CALL del_checkpoint_running()");
            ret = db_reply(&dbctx,dx->db_cb.del_checkpoint_running(&dbctx));
        }
        else {
            confd_trace(CONFD_TRACE,"Warn NULL del_checkpoint_running()");
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    case  CONFD_PROTO_ACTIVATE_CHECKPOINT_RUNNING:
        usid = TUINT(et, 3);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.activate_checkpoint_running != NULL) {
            confd_trace(CONFD_TRACE,"CALL activate_checkpoint_running()");
            ret=db_reply(&dbctx,dx->db_cb.activate_checkpoint_running(&dbctx));
        }
        else {
            confd_trace(CONFD_TRACE,
                        "Warn NULL activate_checkpoint_running()");
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    case  CONFD_PROTO_COPY_RUNNING_TO_STARTUP:
        usid = TUINT(et, 3);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.copy_running_to_startup != NULL) {
            confd_trace(CONFD_TRACE, "CALL copy_running_to_startup()");
            ret = db_reply(&dbctx, dx->db_cb.copy_running_to_startup(&dbctx));
        }
        else {
            confd_trace(CONFD_TRACE,
                        "Warn NULL copy_running_to_startup()");
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    case  CONFD_PROTO_RUNNING_CHK_NOT_MODIFIED:
        usid = TUINT(et, 3);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.running_chk_not_modified != NULL) {
            confd_trace(CONFD_TRACE, "CALL running_chk_not_modified()");
            ret = db_reply(&dbctx, dx->db_cb.running_chk_not_modified(&dbctx));
        }
        else {
            confd_trace(CONFD_TRACE,
                        "Warn NULL running_chk_not_modified()");
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    case  CONFD_PROTO_LOCK:
        usid = TUINT(et, 3);
        dbname = (enum confd_dbname) TUINT(et, 4);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.lock != NULL) {
            confd_trace(CONFD_TRACE, "CALL db lock(%s)",
                        dbname2str(dbname));
            ret = db_reply(&dbctx,dx->db_cb.lock(&dbctx, dbname));
        }
        else {
            confd_trace(CONFD_TRACE, "NULL db lock(%s)",
                        dbname2str(dbname));
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;

    case  CONFD_PROTO_UNLOCK:
        usid = TUINT(et, 3);
        dbname = (enum confd_dbname) TUINT(et, 4);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.unlock != NULL) {
            confd_trace(CONFD_TRACE, "CALL db unlock(%s)",
                        dbname2str(dbname));
            ret = db_reply(&dbctx, dx->db_cb.unlock(&dbctx, dbname));
        }
        else {
            confd_trace(CONFD_TRACE, "NULL db unlock(%s)",
                        dbname2str(dbname));
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;

    case  CONFD_PROTO_LOCK_PARTIAL: {
        int lockid;
        ETERM *paths;
        int npaths;
        confd_hkeypath_t *kp;
        int i;

        usid = TUINT(et, 3);
        dbname = (enum confd_dbname) TUINT(et, 4);
        lockid = TINT(et, 5);
        paths = ERL_TUPLE_ELEMENT(et, 6);
        npaths = erl_length(paths);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.lock_partial != NULL) {
            if ((kp = confd_malloc(npaths*sizeof(confd_hkeypath_t))) != NULL) {
                for (i = 0,ret = CONFD_OK; i < npaths && ret == CONFD_OK; i++) {
                    if (!populate_keypath(ERL_CONS_HEAD(paths), &kp[i]))
                        ret = CONFD_ERR;
                    else
                        paths = ERL_CONS_TAIL(paths);
                }
                if (ret == CONFD_OK) {
                    confd_trace(CONFD_TRACE, "CALL db lock_partial(%s, %d)",
                                dbname2str(dbname), lockid);
                    ret = db_reply(&dbctx,
                                   dx->db_cb.lock_partial(&dbctx, dbname,
                                                          lockid, kp, npaths));
                    for (i = 0; i < npaths; i++)
                        confd_free_eterm_keypath(&kp[i]);
                } else {
                    ret = db_reply(&dbctx, CONFD_ERR);
                }
                free(kp);
            } else {
                ret = db_reply(&dbctx, CONFD_ERR);
            }
        }
        else {
            confd_trace(CONFD_TRACE, "NULL db lock_partial(%s, %d)",
                        dbname2str(dbname), lockid);
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    }

    case  CONFD_PROTO_UNLOCK_PARTIAL: {
        int lockid;

        usid = TUINT(et, 3);
        dbname = (enum confd_dbname) TUINT(et, 4);
        lockid = TINT(et, 5);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.unlock_partial != NULL) {
            confd_trace(CONFD_TRACE, "CALL db unlock_partial(%s, %d)",
                        dbname2str(dbname), lockid);
            ret = db_reply(&dbctx, dx->db_cb.unlock_partial(&dbctx, dbname,
                                                            lockid));
        }
        else {
            confd_trace(CONFD_TRACE, "NULL db unlock_partial(%s, %d)",
                        dbname2str(dbname), lockid);
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;
    }

    case  CONFD_PROTO_DELETE_CONFIG:
        usid = TUINT(et, 3);
        dbname = (enum confd_dbname) TUINT(et, 4);

        if (!init_dbctx(&dbctx, dx, et, op, usid))
            ret = db_reply(&dbctx, CONFD_ERR);
        else if (dx->db_cb.delete_config != NULL) {
            confd_trace(CONFD_TRACE, "CALL db delete_config(%s)",
                        dbname2str(dbname));
            ret = db_reply(&dbctx,dx->db_cb.delete_config(&dbctx, dbname));
        }
        else {
            confd_trace(CONFD_TRACE, "Warn NULL db delete_config(%s)",
                        dbname2str(dbname));
            ret = db_reply(&dbctx, CONFD_OK);
        }
        break;

    default:
        ret = confd_internal_error("Unknown callback op %d\n", op);
    }

  doret:
    erl_free_compound(et);
    return ret;
}

/* like (partial) maapi_get_user_session(), only for DP daemons
   with callbacks - undocumented, needed for rt1333 test case */
int confd_get_user_session(struct confd_daemon_ctx *dx,
                           int usid, struct confd_user_info *us)
{
    struct confd_user_info *uinfo;

    if ((uinfo = get_user_session(dx, usid)) == NULL) {
        return ret_err(CONFD_ERR_NOEXISTS, "No such usessid");
    }
    *us = *uinfo;
    put_user_session(dx, uinfo);
    return CONFD_OK;
}

/* strcmp like function */
int confd_svcmp(const char *s, const confd_value_t *v)
{
    int i;
    switch (v->type) {
    case C_STR:
        return strcmp(s, v->val.s);
    case C_BUF:
        if ((i = strncmp(s, (char*)v->val.buf.ptr,  v->val.buf.size)) == 0) {
            i = strlen(s);
            if (i == v->val.buf.size) return 0;
            if (i <  v->val.buf.size) return -1;
            return 1;
        }
        return i;
    default:
        break;
    }
    return -1;
}



void confd_clear_hkeypath(confd_hkeypath_t *hkp)
{
    int i,j;

    for (i=0; i<hkp->len; i++) {
        j = 0;
        while (1) {
            confd_value_t *vp = &hkp->v[i][j++];
            if (vp->type == C_NOEXISTS)
                break;
            confd_free_value(vp);
        }
    }
}

void confd_free_hkeypath(confd_hkeypath_t *hkp)
{

    confd_clear_hkeypath(hkp);
    free(hkp);
}

void confd_free_value(confd_value_t *v)
{
    enum confd_vtype new = C_NOEXISTS;
    int i;
    switch (v->type) {
    case C_BUF:
        free(CONFD_GET_BUFPTR(v));
        break;
    case C_BINARY:
        free(CONFD_GET_BINARY_PTR(v));
        break;
    case C_HEXSTR:
        free(CONFD_GET_HEXSTR_PTR(v));
        break;
    case C_BITBIG:
        free(CONFD_GET_BITBIG_PTR(v));
        break;
    case C_QNAME:
        if (CONFD_GET_QNAME_PREFIX_SIZE(v) > 0)
            free(CONFD_GET_QNAME_PREFIX_PTR(v));
        free(CONFD_GET_QNAME_NAME_PTR(v));
        break;
    case C_LIST:
        for (i=0; i< v->val.list.size; i++)
            confd_free_value(&v->val.list.ptr[i]);
        free(v->val.list.ptr);
        break;
    case C_OBJECTREF: {
        confd_hkeypath_t *hkp = v->val.hkp;
        for (i=0; i<hkp->len; i++) {
            int j = 0;
            confd_value_t *vp = &hkp->v[i][j];
            while (vp->type != C_NOEXISTS) {
                confd_free_value(vp);
                j++;
                vp = &hkp->v[i][j];
            }
        }
        free(hkp);
        break;
    }
    case C_OID:
        free(CONFD_GET_OID(v));
        break;
    default:
        new = v->type;
        break;
    }

    /* The type is not valid if data was freed */
    v->type = new;
}


void confd_free_authorization_info(struct confd_authorization_info *ainfo)
{
    int i;

    if (ainfo != NULL) {
        for (i = 0; i < ainfo->ngroups; i++) {
            if (ainfo->groups[i] != NULL)
                free(ainfo->groups[i]);
        }
        free(ainfo->groups);
        free(ainfo);
    }
}


char *confd_strerror(int code)
{
    switch (code) {

    case CONFD_ERR_NOEXISTS: return "item does not exist";
    case CONFD_ERR_ALREADY_EXISTS: return "item already exists";
    case CONFD_ERR_ACCESS_DENIED: return "access denied";
    case CONFD_ERR_NOT_WRITABLE: return "item is not writable";
    case CONFD_ERR_BADTYPE: return "item has a bad/wrong type";
    case CONFD_ERR_NOTCREATABLE: return "item is not creatable";
    case CONFD_ERR_NOTDELETABLE: return "item is not deletable";
    case CONFD_ERR_BADPATH: return "badly formatted or nonexistent path";
    case CONFD_ERR_NOSTACK: return "cannot pop an empty stack";
    case CONFD_ERR_LOCKED: return "locked";
    case CONFD_ERR_INUSE: return "in use";

/* Error codes from apply and validate */

    case CONFD_ERR_NOTSET: return "notset";
    case CONFD_ERR_NON_UNIQUE: return "non unique";
    case CONFD_ERR_BAD_KEYREF: return "bad keyref";
    case CONFD_ERR_TOO_FEW_ELEMS: return "too few elems";
    case CONFD_ERR_TOO_MANY_ELEMS: return "too many elems";
    case CONFD_ERR_BADSTATE: return "operation in wrong state";

    case CONFD_ERR_INTERNAL: return "internal error";
    case CONFD_ERR_EXTERNAL: return "external error";
    case CONFD_ERR_MALLOC: return "Failed to allocate";
    case CONFD_ERR_PROTOUSAGE:
        return "Bad protocol usage or unexpected retval";
    case CONFD_ERR_NOSESSION:
        return "A session must be established prior to this command";
    case CONFD_ERR_TOOMANYTRANS: return "Too many transactions";
    case CONFD_ERR_OS: return "system call failed";

    case CONFD_ERR_HA_CONNECT: return "Failed to connect to remote HA node";
    case CONFD_ERR_HA_CLOSED: return "Remote HA node closed socket to us";
    case CONFD_ERR_HA_BADFXS:
        return "Remote HA node has incompatible config to us";
    case CONFD_ERR_HA_BADTOKEN: return "Remote HA node has bad credentials";
    case CONFD_ERR_HA_BADNAME: return "remote HA node has other/wrong name";
    case CONFD_ERR_HA_BIND: return "failed to bind HA socket";
    case CONFD_ERR_HA_NOTICK:
        return "Remote HA node doesn't send us any ticks";

    case CONFD_ERR_VALIDATION_WARNING: return "Validation warnings";
    case CONFD_ERR_SUBAGENT_DOWN: return "Subagent down";
    case CONFD_ERR_LIB_NOT_INITIALIZED: return "Library not initalized";
    case CONFD_ERR_TOO_MANY_SESSIONS:
        return "Maximum number of sessions reached";
    case CONFD_ERR_BAD_CONFIG: return "Error in a configuration";

    case CONFD_ERR_RESOURCE_DENIED:
        return "Data provider returned CONFD_ERRCODE_RESOURCE_DENIED";
    case CONFD_ERR_INCONSISTENT_VALUE:
        return "Data provider returned CONFD_ERRCODE_INCONSISTENT_VALUE";
    case CONFD_ERR_APPLICATION_INTERNAL:
        return "Data provider returned CONFD_ERRCODE_APPLICATION_INTERNAL";

    case CONFD_ERR_UNSET_CHOICE: return "No case selected for mandatory choice";
    case CONFD_ERR_MUST_FAILED: return "Unsatisfied must constraint";
    case CONFD_ERR_MISSING_INSTANCE: return "Required instance does not exist";
    case CONFD_ERR_INVALID_INSTANCE:
        return "Instance does not conform to path filters";
    case CONFD_ERR_STALE_INSTANCE:
        return "Required instance does not exist";

    case CONFD_ERR_UNAVAILABLE: return "Unavailable functionality";
    case CONFD_ERR_EOF: return "Lost connection to ConfD";
    case CONFD_ERR_NOTMOVABLE: return "item is not movable";
    case CONFD_ERR_HA_WITH_UPGRADE:
        return "HA slave not allowed during upgrade";
    case CONFD_ERR_TIMEOUT: return "Operation timed out";
    case CONFD_ERR_ABORTED: return "Operation was aborted";
    case CONFD_ERR_XPATH: return "XPath compilation/evaluation failed";
    case CONFD_ERR_NOT_IMPLEMENTED: return "Operation not implemented";
    case CONFD_ERR_HA_BADVSN: return "Remote HA node has incompatible version";
    case CONFD_ERR_POLICY_FAILED: return "Policy expression evaluated to false";
    case CONFD_ERR_POLICY_COMPILATION_FAILED:
         return "Policy XPath expression could not be compiled";
    case CONFD_ERR_POLICY_EVALUATION_FAILED:
        return "Policy expression failed XPath evaluation";
    case CONFD_ERR_START_FAILED:
        return "Failed to proceed to next start phase";
    case CONFD_ERR_DATA_MISSING:
        return "Data provider returned CONFD_ERRCODE_DATA_MISSING";
    case CONFD_ERR_CLI_CMD:
        return "CLI command error";
    case CONFD_ERR_UPGRADE_IN_PROGRESS:
        return "Not allowed during upgrade";
    case CONFD_ERR_NOTRANS:
        return "Transaction not found";
    case CONFD_ERR_NO_MOUNT_ID:
        return "Path is ambiguous due to traversing a mount point";
    }
    return "Unknown error";
}

int confd_notifications_connect2(int sock, const struct sockaddr* srv,
                                 int srv_sz, int mask,
                                 struct confd_notifications_data *data)
{
    int t, ret;
    ETERM *req, *reply;
    ETERM *req_arr[5];
    ETERM *stream_arr[6];
    enum confd_progress_verbosity v;

    if (data == NULL) {
        if ((mask & CONFD_NOTIF_HEARTBEAT) != 0)
            return ret_err(CONFD_ERR_PROTOUSAGE, "Need heartbeat interval");
        if ((mask & CONFD_NOTIF_HEALTH_CHECK) != 0)
            return ret_err(CONFD_ERR_PROTOUSAGE, "Need health check interval");
        if ((mask & CONFD_NOTIF_STREAM_EVENT) != 0)
            return ret_err(CONFD_ERR_PROTOUSAGE,
                           "Need notification stream info");
    }
    if ((mask & CONFD_NOTIF_STREAM_EVENT) != 0 && data->stream_name == NULL)
        return ret_err(CONFD_ERR_PROTOUSAGE, "Need notification stream name");

    if ((ret=confd_do_connect(sock, srv, srv_sz, CLIENT_EVENT_MGR)) != CONFD_OK)
         return ret;
    confd_trace(CONFD_TRACE, "Connected (events) to ConfD\n");

    req_arr[0] = erl_mk_int(mask);
    t = (mask & CONFD_NOTIF_HEARTBEAT) ? data->heartbeat_interval : 0;
    req_arr[1] = erl_mk_int(t);
    t = (mask & CONFD_NOTIF_HEALTH_CHECK) ? data->health_check_interval : 0;
    req_arr[2] = erl_mk_int(t);
    if ((mask & CONFD_NOTIF_STREAM_EVENT) != 0) {
        stream_arr[0] = erl_mk_atom(data->stream_name);
        if (data->start_time.type == C_NOEXISTS) {
            stream_arr[1] = erl_mk_atom("undefined");
            stream_arr[2] = erl_mk_atom("undefined");
        } else {
            if ((stream_arr[1] = val_to_term(&data->start_time)) == NULL)
                return CONFD_ERR;
            if (data->stop_time.type == C_NOEXISTS) {
                stream_arr[2] = erl_mk_atom("undefined");
            } else {
                if ((stream_arr[2] = val_to_term(&data->stop_time)) == NULL)
                    return CONFD_ERR;
            }
        }
        if (data->xpath_filter != NULL)
            stream_arr[3] = erl_mk_binary(data->xpath_filter,
                                          strlen(data->xpath_filter));
        else
            stream_arr[3] = erl_mk_atom("undefined");
        stream_arr[4] = erl_mk_int(data->usid);
        stream_arr[5] = erl_mk_int(0); /* useIKP == false */
        req_arr[3] = erl_mk_tuple(stream_arr, 6);
    } else {
        req_arr[3] = erl_mk_atom("undefined");
    }
    v = ((mask & CONFD_NOTIF_PROGRESS || mask & CONFD_NOTIF_COMMIT_PROGRESS)
         && data != NULL) ?
        data->verbosity : CONFD_VERBOSITY_NORMAL;
    req_arr[4] = erl_mk_int(v);
    req = erl_mk_tuple(req_arr, 5);

    reply = confd_call(sock, req, &ret);
    erl_free_compound(req);
    if (reply == NULL)
        return ret;
    /* reply here is always atom 'ok',
       confd_call() handles {error, Code, Reason} */
    erl_free_compound(reply);
    return CONFD_OK;
}

int confd_notifications_connect(int sock, const struct sockaddr* srv,
                                int srv_sz, int mask)
{
    return confd_notifications_connect2(sock, srv, srv_sz, mask, NULL);
}



static int unpack_ha_node(ETERM *src, struct confd_ha_node *dst);

static void fill_in_oid(struct confd_snmp_oid *oid, ETERM *list) {
    oid->len = 0;
    while (! ERL_IS_EMPTY_LIST(list)) {
        /* prepare for next loop */
        ETERM *hd2 = ERL_CONS_HEAD(list);
        list = ERL_CONS_TAIL(list);
        oid->oid[oid->len++] =  ERL_INT_VALUE(hd2);
    }
}

#define _CLEAN_COMPLETED_RET_CONFD_ERR(TERM, NOTIFP) {          \
        erl_free_compound(TERM);                                \
        free(NOTIFP->completed_services);                       \
        free(NOTIFP->completed_services_completed_devices);     \
        return CONFD_ERR;                                       \
    }
#define _CLEAN_FAILED_RET_CONFD_ERR(TERM, NOTIFP) {             \
        erl_free_compound(TERM);                                \
        free(NOTIFP->failed_services);                          \
        free(NOTIFP->failed_services_completed_devices);        \
        free(NOTIFP->failed_services_failed_devices);           \
        return CONFD_ERR;                                       \
    }

int confd_read_notification(int sock, struct confd_notification *n)
{
    ETERM *e;
    int ret;
    int notification_type;
    if ((e = term_read(sock, &ret, -1)) == NULL)
        return ret;
    notification_type = TUINT(e, 0);
    n->type = notification_type;
    switch (notification_type) {
    case CONFD_NOTIF_HEARTBEAT:
    case CONFD_NOTIF_HEALTH_CHECK:
    case NCS_NOTIF_PACKAGE_RELOAD:
    case CONFD_NOTIF_REOPEN_LOGS:
        erl_free_compound(e);
        return CONFD_OK;
    case CONFD_NOTIF_AUDIT:
        n->n.audit.logno = TUINT(e, 1);
        bin_copy(&n->n.audit.user[0], MAXUSERNAMELEN, TE(e,2));
        n->n.audit.usid = TUINT(e, 3);
        bin_copy(&n->n.audit.msg[0], BUFSIZ, TE(e,4));
        erl_free_compound(e);
        return CONFD_OK;
    case CONFD_NOTIF_DAEMON:
    case CONFD_NOTIF_NETCONF:
    case CONFD_NOTIF_DEVEL:
    case CONFD_NOTIF_JSONRPC:
    case CONFD_NOTIF_WEBUI:
        n->n.syslog.logno = TUINT(e, 1);
        n->n.syslog.prio = TUINT(e, 2);
        bin_copy(&n->n.syslog.msg[0], BUFSIZ, TE(e,3));
        erl_free_compound(e);
        return CONFD_OK;
    case CONFD_NOTIF_COMMIT_SIMPLE: {
        ETERM *utup;

        n->n.commit.database = TUINT(e, 1);
        utup =  ERL_TUPLE_ELEMENT(e, 2);
        n->n.commit.diff_available = TUINT(e, 3);
        n->n.commit.flags = TUINT(e, 4);
        _confd_mk_uinfo(utup, &n->n.commit.uinfo);
        erl_free_compound(e);
        return CONFD_OK;
    }
    case CONFD_NOTIF_COMMIT_DIFF: {
        ETERM *utup;
        int thandle;
        struct confd_trans_ctx *tctx;

        n->n.commit_diff.database = TUINT(e, 1);
        utup =  ERL_TUPLE_ELEMENT(e, 2);
        thandle = TUINT(e, 3);
        n->n.commit_diff.flags = TUINT(e, 4);
        if (ERL_TUPLE_SIZE(e) == 7) {
            bin_copy(&n->n.commit_diff.comment[0], MAX_COMMENT_LEN, TE(e, 5));
            bin_copy(&n->n.commit_diff.label[0], MAX_LABEL_LEN, TE(e, 6));
        } else {
            n->n.commit_diff.comment[0] = '\0';
            n->n.commit_diff.label[0] = '\0';
        }
        _confd_mk_uinfo(utup, &n->n.commit_diff.uinfo);
        if ((tctx = alloc_transaction(NULL, thandle)) == NULL) {
            erl_free_compound(e);
            return CONFD_ERR;
        }
        tctx->mode = CONFD_READ;
        tctx->dbname = n->n.commit_diff.database;
        tctx->uinfo = &n->n.commit_diff.uinfo;
        n->n.commit_diff.tctx = tctx;
        erl_free_compound(e);
        return CONFD_OK;
    }
    case CONFD_NOTIF_CONFIRMED_COMMIT: {
        ETERM *utup;

        n->n.confirm.type = TUINT(e, 1);
        n->n.confirm.timeout = TUINT(e, 2);
        utup =  ERL_TUPLE_ELEMENT(e, 3);
        _confd_mk_uinfo(utup, &n->n.confirm.uinfo);
        erl_free_compound(e);
        return CONFD_OK;
    }
    case CONFD_NOTIF_USER_SESSION: {
        ETERM *utup;

        n->n.user_sess.type = TUINT(e, 1);
        utup =  ERL_TUPLE_ELEMENT(e, 2);
        n->n.user_sess.database = TUINT(e, 3);
        _confd_mk_uinfo(utup, &n->n.user_sess.uinfo);
        erl_free_compound(e);
        return CONFD_OK;
    }
    case CONFD_NOTIF_HA_INFO: {
        ETERM *ee;
        ETERM *data;
        enum confd_ha_info_type type;
        struct confd_ha_notification *hnot = &n->n.hnot;

        ee = TE(e,1);
        type = TUINT(ee, 0);
        data = TE(ee, 1);
        hnot->type = type;
        switch (type) {
        case CONFD_HA_INFO_IS_MASTER:
        case CONFD_HA_INFO_IS_NONE:
            erl_free_compound(e);
            return CONFD_OK;
        case CONFD_HA_INFO_NOMASTER:
            hnot->data.nomaster = ERL_INT_UVALUE(data);
            erl_free_compound(e);
            return CONFD_OK;
        case CONFD_HA_INFO_SLAVE_DIED:
            unpack_ha_node(data, &hnot->data.slave_died);
            erl_free_compound(e);
            return CONFD_OK;
        case CONFD_HA_INFO_SLAVE_ARRIVED:
            unpack_ha_node(data, &hnot->data.slave_arrived);
            erl_free_compound(e);
            return CONFD_OK;
        case CONFD_HA_INFO_SLAVE_INITIALIZED:
            hnot->data.cdb_initialized_by_copy = ERL_INT_UVALUE(data);
            erl_free_compound(e);
            return CONFD_OK;
        case CONFD_HA_INFO_BESLAVE_RESULT:
            hnot->data.beslave_result = ERL_INT_UVALUE(data);
            erl_free_compound(e);
            return CONFD_OK;
        default:
            erl_free_compound(e);
            return CONFD_ERR;
        }
    }
    case CONFD_NOTIF_SUBAGENT_INFO: {
        ETERM *ee = TE(e,1);
        n->n.subagent.type = TUINT(ee, 0);
        bin_copy(&n->n.subagent.name[0], MAXAGENTNAMELEN, TE(ee, 1));
        erl_free_compound(e);
        return CONFD_OK;
    }
    case CONFD_NOTIF_FORWARD_INFO: {
        ETERM *utup;

        n->n.forward.type = TUINT(e, 1);
        bin_copy(&n->n.forward.target[0], MAXTARGETNAMELEN, TE(e, 2));
        utup =  ERL_TUPLE_ELEMENT(e, 3);
        _confd_mk_uinfo(utup, &n->n.forward.uinfo);
        erl_free_compound(e);
        return CONFD_OK;
    }
    case CONFD_NOTIF_COMMIT_FAILED: {
        n->n.cfail.provider =  TUINT(e, 1);
        n->n.cfail.dbname =  TUINT(e, 2);
        if (n->n.cfail.provider == CONFD_DP_NETCONF) {
            /* we also have IP/port to collect */
            ETERM *ipterm = TE(e, 3);
            n->n.cfail.v.nc.port = TINT(e, 4);
            if (ERL_TUPLE_SIZE(ipterm) == 4) {
                n->n.cfail.v.nc.ip.af = AF_INET;
                term_to_ip4(&(n->n.cfail.v.nc.ip.ip.v4), ipterm);
            }
            else {
                n->n.cfail.v.nc.ip.af = AF_INET6;
                term_to_ip6(&(n->n.cfail.v.nc.ip.ip.v6), ipterm);
            }
        }
        else if (n->n.cfail.provider == CONFD_DP_EXTERNAL) {
            /* we must also pick up the daemon name */
            bin_copy(&n->n.cfail.v.daemon_name[0], MAX_DAEMON_NAME_LEN,
                     TE(e,3));
        }
        erl_free_compound(e);
        return CONFD_OK;
    }
    case CONFD_NOTIF_UPGRADE_EVENT: {
        n->n.upgrade.event = TUINT(e, 1);
        erl_free_compound(e);
        return CONFD_OK;
    }
    case CONFD_NOTIF_COMMIT_PROGRESS:
    case CONFD_NOTIF_PROGRESS: {
        ETERM *event = ERL_TUPLE_ELEMENT(e, 1);
#ifdef CONFD_C_PRODUCT_NCS
        assert(ERL_TUPLE_SIZE(event) == 18);
#else
        assert(ERL_TUPLE_SIZE(event) == 11);
#endif
        n->n.progress.type = TUINT(event, 0);
        n->n.progress.timestamp = ERL_LL_UVALUE(TE(event, 1));
        ETERM *duration = TE(event, 2);
        if (ERL_IS_UNSIGNED_LONGLONG(duration)) {
            n->n.progress.duration = ERL_LL_UVALUE(duration);
        } else if (ERL_IS_LONGLONG(duration)) {
            n->n.progress.duration = ERL_LL_UVALUE(duration);
        } else if (ERL_IS_INTEGER(duration)) {
            n->n.progress.duration = ERL_INT_VALUE(duration);
        } else {
            n->n.progress.duration = 0;
        }
        n->n.progress.usid = TUINT(event, 3);
        n->n.progress.tid = TUINT(event, 4);
        n->n.progress.datastore = TUINT(event, 5);
        ETERM *context = TE(event, 6);
        if (ERL_IS_BINARY(context)) {
            n->n.progress.context = bin_dup(context);
        } else {
            n->n.progress.context = NULL;
        }
        ETERM *subsystem = TE(event, 7);
        if (ERL_IS_BINARY(subsystem)) {
            n->n.progress.subsystem = bin_dup(subsystem);
        } else {
            n->n.progress.subsystem = NULL;
        }
        ETERM *phase = TE(event, 8);
        if (ERL_IS_BINARY(phase)) {
            n->n.progress.phase = bin_dup(phase);
        } else {
            n->n.progress.phase = NULL;
        }
        ETERM *msg = TE(event, 9);
        if (ERL_IS_BINARY(msg)) {
            bin_copy(&n->n.progress.msg[0], BUFSIZ, msg);
        }
        ETERM *annotation = TE(event, 10);
        if (ERL_IS_BINARY(annotation)) {
            n->n.progress.annotation = bin_dup(annotation);
        } else {
            n->n.progress.annotation = NULL;
        }
#ifdef CONFD_C_PRODUCT_NCS
        ETERM *service = TE(event, 11);
        if (ERL_IS_BINARY(service)) {
            n->n.progress.service = bin_dup(service);
        } else {
            n->n.progress.service = NULL;
        }
        ETERM *service_phase = TE(event, 12);
        if (ERL_IS_BINARY(service_phase)) {
            n->n.progress.service_phase = bin_dup(service_phase);
        } else {
            n->n.progress.service_phase = NULL;
        }
        ETERM *commit_queue_id = TE(event, 13);
        if (ERL_IS_UNSIGNED_LONGLONG(commit_queue_id)) {
            n->n.progress.commit_queue_id = ERL_LL_UVALUE(commit_queue_id);
        } else if (ERL_IS_LONGLONG(commit_queue_id)) {
            n->n.progress.commit_queue_id = ERL_LL_UVALUE(commit_queue_id);
        } else if (ERL_IS_INTEGER(commit_queue_id)) {
            n->n.progress.commit_queue_id = ERL_INT_UVALUE(commit_queue_id);
        } else {
            n->n.progress.commit_queue_id = 0;
        }
        ETERM *node = TE(event, 14);
        if (ERL_IS_BINARY(node)) {
            n->n.progress.node = bin_dup(node);
        } else {
            n->n.progress.node = NULL;
        }
        ETERM *device = TE(event, 15);
        if (ERL_IS_BINARY(device)) {
            n->n.progress.device = bin_dup(device);
        } else {
            n->n.progress.device = NULL;
        }
        ETERM *device_phase = TE(event, 16);
        if (ERL_IS_BINARY(device_phase)) {
            n->n.progress.device_phase = bin_dup(device_phase);
        } else {
            n->n.progress.device_phase = NULL;
        }
        ETERM *package = TE(event, 17);
        if (ERL_IS_BINARY(package)) {
            n->n.progress.package = bin_dup(package);
        } else {
            n->n.progress.package = NULL;
        }
#endif
        erl_free_compound(e);
        return CONFD_OK;
    }
    case CONFD_NOTIF_SNMPA: {
        struct confd_snmpa_notification *s = &n->n.snmpa;
        ETERM *ipterm;
        ETERM *e2 = ERL_TUPLE_ELEMENT(e, 1);
        s->pdu_type = TINT(e2, 0);
        s->request_id = TINT(e2, 1);
        ipterm = TE(e2, 2);
        if (ERL_TUPLE_SIZE(ipterm) == 4) {
            s->ip.af = AF_INET;
            term_to_ip4(&(s->ip.ip.v4), ipterm);
        }
        else {
            s->ip.af = AF_INET6;
            term_to_ip6(&(s->ip.ip.v6), ipterm);
        }
        s->port = TUINT(e2, 3);
        if (s->pdu_type == CONFD_SNMPA_PDU_V1TRAP) {
            struct confd_v1_trap_info *t = (struct confd_v1_trap_info*)
                confd_malloc(sizeof(struct confd_v1_trap_info));
            s->v1_trap = t;

            t->time_stamp = s->request_id;
            s->request_id = 0;

            t->specific_trap = TINT(e2, 4);
            s->error_index = 0;

            t->generic_trap = TINT(e2, 5);
            s->error_status = 0;

            fill_in_oid(&t->enterprise, ERL_TUPLE_ELEMENT(e2, 9));
        }
        else {
            s->error_status = TINT(e2, 4);
            s->error_index = TINT(e2, 5);
        }
        s->num_variables = TINT(e2, 6);
        if (s->num_variables == 0) {
            s->vb = NULL;
        }
        else {
            ETERM *tl = ERL_TUPLE_ELEMENT(e2, 7);
            struct confd_snmp_varbind *vbp;
            s->vb = (struct confd_snmp_varbind*)
                malloc(s->num_variables * sizeof(struct confd_snmp_varbind));
            vbp = s->vb;
            while (! ERL_IS_EMPTY_LIST(tl)) {
                /* prepare for next loop */
                ETERM *hd0 = ERL_CONS_HEAD(tl);
                /* hd0 is now {VarBind, Value} */
                ETERM *varbind = ERL_TUPLE_ELEMENT(hd0, 0);
                ETERM *varvalue = ERL_TUPLE_ELEMENT(hd0, 1);
                tl = ERL_CONS_TAIL(tl);

                vbp->type = TINT(varbind, 0);
                vbp->vartype = TINT(varbind, 1);
                if (vbp->type == CONFD_SNMP_OID ) {
                    fill_in_oid(&vbp->var.oid, ERL_TUPLE_ELEMENT(varbind, 2));
                }
                else if (vbp->type == CONFD_SNMP_COL_ROW) {
                    fill_in_oid(&vbp->var.cr.rowindex,
                                ERL_TUPLE_ELEMENT(varbind, 2));
                    bin_copy(vbp->var.cr.column, sizeof(vbp->var.cr.column),
                             ERL_TUPLE_ELEMENT(varbind, 3));
                }
                else if (vbp->type == CONFD_SNMP_VARIABLE) {
                    bin_copy(vbp->var.name, sizeof(vbp->var.name),
                             ERL_TUPLE_ELEMENT(varbind, 2));
                }

                /* Now finally fill in the value */
                /* always a string               */
                if (ERL_IS_BINARY(varvalue)) {
                    vbp->val.type = C_BUF;
                    vbp->val.val.buf.size = ERL_BIN_SIZE(varvalue);
                    vbp->val.val.buf.ptr = (unsigned char *)bin_dup(varvalue);
                }
                else { // NULL value
                    vbp->val.type = C_NOEXISTS;
                }
                vbp++;
            }
        }

        erl_free_compound(e);
        return CONFD_OK;
    }
#ifdef CONFD_C_PRODUCT_NCS
    case NCS_NOTIF_CQ_PROGRESS: {
        struct ncs_cq_progress_notification *s = &n->n.cq_progress;
        ETERM *evtype = ERL_TUPLE_ELEMENT(e, 1);
        confd_value_t time;
        int i;

        s->type = ERL_INT_UVALUE(evtype);
        ETERM *dt = ERL_TUPLE_ELEMENT(e, 2);
        if (eterm_to_val(dt, &time) == NULL ||
            time.type != C_DATETIME) {
            erl_free_compound(e);
            return ret_err(CONFD_ERR_INTERNAL,
                           "Bad cq_progress notification time");
        }
        s->timestamp = time.val.datetime;

        ETERM *cqtag = ERL_TUPLE_ELEMENT(e, 3);
        if (ERL_IS_BINARY(cqtag)) {
            s->cq_tag = bin_dup(cqtag);
        } else if (ERL_IS_ATOM(cqtag)) {
            /* undefined */
            s->cq_tag = NULL;
        } else {
            erl_free_compound(e);
            return CONFD_ERR;
        }

        ETERM *cqid = ERL_TUPLE_ELEMENT(e, 4);
        if (ERL_IS_UNSIGNED_LONGLONG(cqid)) {
            s->cq_id = (u_int64_t) ERL_LL_UVALUE(cqid);
        } else if (ERL_IS_LONGLONG(cqid)) {
            s->cq_id = (u_int64_t) ERL_LL_VALUE(cqid);
        } else {
            s->cq_id = (u_int64_t) ERL_INT_UVALUE(cqid);
        }

        ETERM *devterm = ERL_TUPLE_ELEMENT(e, 5);
        if (! ERL_IS_ATOM(devterm)) {
            s->ncompleted_devices = erl_length(devterm);
            s->completed_devices =
                confd_malloc(s->ncompleted_devices * sizeof(char *));
            if (s->completed_devices == NULL) {
                erl_free_compound(e);
                return CONFD_ERR;
            }

            for (i = 0; !ERL_IS_NIL(devterm); i++) {
                if (!ERL_IS_CONS(devterm)) {
                    erl_free_compound(e);
                    free(s->completed_devices);
                    return CONFD_ERR;
                }
                if (i < s->ncompleted_devices) {
                    ETERM *edev = ERL_CONS_HEAD(devterm);
                    if (ERL_IS_BINARY(edev)) {
                        s->completed_devices[i] = bin_dup(edev);
                        if (s->completed_devices[i] == NULL) {
                            erl_free_compound(e);
                            free(s->completed_devices);
                            return CONFD_ERR;
                        }
                    } else {
                        erl_free_compound(e);
                        free(s->completed_devices);
                        return CONFD_ERR;
                    }
                }
                devterm = ERL_CONS_TAIL(devterm);
            }
            if (i != s->ncompleted_devices) {
                erl_free_compound(e);
                free(s->completed_devices);
                return CONFD_ERR;
            }
        } else {
            s->ncompleted_devices = 0;
            s->completed_devices = NULL;
        }

        ETERM *devterm2 = ERL_TUPLE_ELEMENT(e, 6);
        if (! ERL_IS_ATOM(devterm2)) {
            s->ntransient_devices = erl_length(devterm2);
            s->transient_devices =
                confd_malloc(s->ntransient_devices * sizeof(char *));
            if (s->transient_devices == NULL) {
                erl_free_compound(e);
                return CONFD_ERR;
            }

            for (i = 0; !ERL_IS_NIL(devterm2); i++) {
                if (!ERL_IS_CONS(devterm2)) {
                    erl_free_compound(e);
                    free(s->transient_devices);
                    return CONFD_ERR;
                }
                if (i < s->ntransient_devices) {
                    ETERM *edev = ERL_CONS_HEAD(devterm2);
                    if (ERL_IS_BINARY(edev)) {
                        s->transient_devices[i] = bin_dup(edev);
                        if (s->transient_devices[i] == NULL) {
                            erl_free_compound(e);
                            free(s->transient_devices);
                            return CONFD_ERR;
                        }
                    } else {
                        erl_free_compound(e);
                        free(s->transient_devices);
                        return CONFD_ERR;
                    }
                }
                devterm2 = ERL_CONS_TAIL(devterm2);
            }
            if (i != s->ntransient_devices) {
                erl_free_compound(e);
                free(s->transient_devices);
                return CONFD_ERR;
            }
        } else {
            s->ntransient_devices = 0;
            s->transient_devices = NULL;
        }


        ETERM *devterm3 = ERL_TUPLE_ELEMENT(e, 7);
        if (! ERL_IS_ATOM(devterm3)) {
            s->nfailed_devices = erl_length(devterm3);
            s->failed_devices =
                confd_malloc(s->nfailed_devices * sizeof(char *));
            if (s->failed_devices == NULL) {
                erl_free_compound(e);
                return CONFD_ERR;
            }
            s->failed_reasons =
                confd_malloc(s->nfailed_devices * sizeof(char *));
            if (s->failed_devices == NULL) {
                free(s->failed_devices);
                erl_free_compound(e);
                return CONFD_ERR;
            }

            for (i = 0; !ERL_IS_NIL(devterm3); i++) {
                if (!ERL_IS_CONS(devterm3)) {
                    erl_free_compound(e);
                    free(s->failed_devices);
                    free(s->failed_reasons);
                    return CONFD_ERR;
                }
                if (i < s->nfailed_devices) {
                    ETERM *efail = ERL_CONS_HEAD(devterm3);
                    if (ERL_IS_TUPLE(efail)) {
                        ETERM *edev = ERL_TUPLE_ELEMENT(efail, 0);
                        ETERM *ereason = ERL_TUPLE_ELEMENT(efail, 1);
                        if (ERL_IS_BINARY(edev)) {
                            s->failed_devices[i] = bin_dup(edev);
                            if (s->failed_devices[i] == NULL) {
                                erl_free_compound(e);
                                free(s->failed_devices);
                                free(s->failed_reasons);
                                return CONFD_ERR;
                            }
                        } else {
                            erl_free_compound(e);
                            free(s->failed_devices);
                            free(s->failed_reasons);
                            return CONFD_ERR;
                        }
                        if (ERL_IS_BINARY(ereason)) {
                            s->failed_reasons[i] = bin_dup(ereason);
                            if (s->failed_reasons[i] == NULL) {
                                erl_free_compound(e);
                                free(s->failed_devices);
                                free(s->failed_reasons);
                                return CONFD_ERR;
                            }
                        }
                    } else {
                        erl_free_compound(e);
                        free(s->failed_devices);
                        free(s->failed_reasons);
                        return CONFD_ERR;
                    }
                }
                devterm3 = ERL_CONS_TAIL(devterm3);
            }
            if (i != s->nfailed_devices) {
                erl_free_compound(e);
                free(s->failed_devices);
                free(s->failed_reasons);
                return CONFD_ERR;
            }
        } else {
            s->nfailed_devices = 0;
            s->failed_devices = NULL;
            s->failed_reasons = NULL;
        }

        ETERM *devterm4 = ERL_TUPLE_ELEMENT(e, 8);
        if (! ERL_IS_ATOM(devterm4)) {
            s->ncompleted_services = erl_length(devterm4);
            s->completed_services_completed_devices = NULL;
            s->completed_services =
                confd_malloc(s->ncompleted_services * sizeof(char *));
            if (s->completed_services == NULL) {
                _CLEAN_COMPLETED_RET_CONFD_ERR(e, s);
            }
            s->completed_services_completed_devices =
                confd_malloc(s->ncompleted_services * sizeof(confd_value_t *));
            if (s->completed_services_completed_devices == NULL) {
                _CLEAN_COMPLETED_RET_CONFD_ERR(e, s);
            }

            for (i = 0; !ERL_IS_NIL(devterm4); i++) {
                if (!ERL_IS_CONS(devterm4)) {
                    _CLEAN_COMPLETED_RET_CONFD_ERR(e, s);
                }
                if (i < s->ncompleted_services) {
                    ETERM *ecompserv = ERL_CONS_HEAD(devterm4);
                    if (ERL_IS_TUPLE(ecompserv)) {
                        ETERM *eservice = ERL_TUPLE_ELEMENT(ecompserv, 0);
                        ETERM *ecompdevs1 = ERL_TUPLE_ELEMENT(ecompserv, 1);
                        if (ERL_IS_BINARY(eservice)) {
                            s->completed_services[i] = bin_dup(eservice);
                            if (s->completed_services[i] == NULL) {
                                _CLEAN_COMPLETED_RET_CONFD_ERR(e, s);
                            }
                        } else {
                            _CLEAN_COMPLETED_RET_CONFD_ERR(e, s);
                        }
                        if (ERL_IS_LIST(ecompdevs1)) {
                            confd_value_t tmpval;
                            if (eterm_to_val(ecompdevs1, &tmpval) == NULL) {
                                _CLEAN_COMPLETED_RET_CONFD_ERR(e, s);
                            }
                            if ((s->completed_services_completed_devices[i] =
                                 confd_value_dup(&tmpval)) == NULL) {
                                confd_free_eterm_val(&tmpval);
                                _CLEAN_COMPLETED_RET_CONFD_ERR(e, s);
                            }
                            confd_free_eterm_val(&tmpval);
                        } else {
                            _CLEAN_COMPLETED_RET_CONFD_ERR(e, s);
                        }
                    } else {
                        _CLEAN_COMPLETED_RET_CONFD_ERR(e, s);
                    }
                }
                devterm4 = ERL_CONS_TAIL(devterm4);
            }
            if (i != s->ncompleted_services) {
                _CLEAN_COMPLETED_RET_CONFD_ERR(e, s);
            }
        } else {
            s->ncompleted_services = 0;
            s->completed_services = NULL;
            s->completed_services_completed_devices = NULL;
        }

        ETERM *devterm5 = ERL_TUPLE_ELEMENT(e, 9);
        if (! ERL_IS_ATOM(devterm5)) {
            s->nfailed_services = erl_length(devterm5);
            s->failed_services_completed_devices = NULL;
            s->failed_services_failed_devices = NULL;
            s->failed_services =
                confd_malloc(s->nfailed_services * sizeof(char *));
            if (s->failed_services == NULL) {
                _CLEAN_FAILED_RET_CONFD_ERR(e, s);
            }
            s->failed_services_completed_devices =
                confd_malloc(s->nfailed_services * sizeof(confd_value_t *));
            if (s->failed_services_completed_devices == NULL) {
                _CLEAN_FAILED_RET_CONFD_ERR(e, s);
            }
            s->failed_services_failed_devices =
                confd_malloc(s->nfailed_services * sizeof(confd_value_t *));
            if (s->failed_services_failed_devices == NULL) {
                _CLEAN_FAILED_RET_CONFD_ERR(e, s);
            }

            for (i = 0; !ERL_IS_NIL(devterm5); i++) {
                if (!ERL_IS_CONS(devterm5)) {
                    _CLEAN_FAILED_RET_CONFD_ERR(e, s);
                }
                if (i < s->nfailed_services) {
                    ETERM *efailserv = ERL_CONS_HEAD(devterm5);
                    if (ERL_IS_TUPLE(efailserv)) {
                        ETERM *efservice = ERL_TUPLE_ELEMENT(efailserv, 0);
                        ETERM *efserv_compdevs= ERL_TUPLE_ELEMENT(efailserv, 1);
                        ETERM *efserv_faildevs= ERL_TUPLE_ELEMENT(efailserv, 2);
                        if (ERL_IS_BINARY(efservice)) {
                            s->failed_services[i] = bin_dup(efservice);
                            if (s->failed_services[i] == NULL) {
                                _CLEAN_FAILED_RET_CONFD_ERR(e, s);
                            }
                        } else {
                            _CLEAN_FAILED_RET_CONFD_ERR(e, s);
                        }
                        if (ERL_IS_LIST(efserv_compdevs)) {
                            confd_value_t tmpv1;
                            if (eterm_to_val(efserv_compdevs, &tmpv1) == NULL) {
                                _CLEAN_FAILED_RET_CONFD_ERR(e, s);
                            }
                            if ((s->failed_services_completed_devices[i] =
                                 confd_value_dup(&tmpv1)) == NULL) {
                                confd_free_eterm_val(&tmpv1);
                                _CLEAN_FAILED_RET_CONFD_ERR(e, s);
                            }
                            confd_free_eterm_val(&tmpv1);
                        } else {
                            _CLEAN_FAILED_RET_CONFD_ERR(e, s);
                        }
                        if (ERL_IS_LIST(efserv_faildevs)) {
                            confd_value_t tmpv2;
                            if (eterm_to_val(efserv_faildevs, &tmpv2) == NULL) {
                                _CLEAN_FAILED_RET_CONFD_ERR(e, s);
                            }
                            if ((s->failed_services_failed_devices[i] =
                                 confd_value_dup(&tmpv2)) == NULL) {
                                confd_free_eterm_val(&tmpv2);
                                _CLEAN_FAILED_RET_CONFD_ERR(e, s);
                            }
                            confd_free_eterm_val(&tmpv2);
                        } else {
                            _CLEAN_FAILED_RET_CONFD_ERR(e, s);
                        }
                    } else {
                        _CLEAN_FAILED_RET_CONFD_ERR(e, s);
                    }
                }
                devterm5 = ERL_CONS_TAIL(devterm5);
            }
            if (i != s->nfailed_services) {
                _CLEAN_FAILED_RET_CONFD_ERR(e, s);
            }
        } else {
            s->nfailed_services = 0;
            s->failed_services = NULL;
            s->failed_services_completed_devices = NULL;
            s->failed_services_failed_devices = NULL;
        }
        erl_free_compound(e);
        return CONFD_OK;
    }
    case NCS_NOTIF_CALL_HOME_INFO: {
        n->n.call_home.type = TUINT(e, 1);
        ETERM *ipterm = TE(e, 2);
        n->n.call_home.port = TINT(e, 3);
        n->n.call_home.ssh_host_key = bin_dup(TE(e, 4));
        n->n.call_home.ssh_key_alg = TINT(e, 5);
        if (ERL_TUPLE_SIZE(ipterm) == 4) {
            n->n.call_home.ip.af = AF_INET;
            term_to_ip4(&(n->n.call_home.ip.ip.v4), ipterm);
        } else {
            n->n.call_home.ip.af = AF_INET6;
            term_to_ip6(&(n->n.call_home.ip.ip.v6), ipterm);
        }
        if (n->n.call_home.type == CALL_HOME_DEVICE_CONNECTED) {
            n->n.call_home.device = bin_dup(TE(e, 6));
        }
        erl_free_compound(e);
        return CONFD_OK;
    }
#endif
    case CONFD_NOTIF_STREAM_EVENT: {
        struct confd_stream_notification *s = &n->n.stream;
        ETERM *event = ERL_TUPLE_ELEMENT(e, 1);
        s->type = 0;
        if (ERL_IS_ATOM(event)) {
            if (bin_eq(event, "replay_complete"))
                s->type = CONFD_STREAM_REPLAY_COMPLETE;
            else
                s->type = CONFD_STREAM_NOTIFICATION_COMPLETE;
        } else if (ERL_IS_TUPLE(event) && ERL_IS_ATOM(TE(event, 0))) {
            s->type = CONFD_STREAM_REPLAY_FAILED;
            s->replay_error = bin_dup(TE(event, 1));
        } else {
            confd_value_t time;
            int i;
            if (eterm_to_val(TE(event, 0), &time) == NULL ||
                time.type != C_DATETIME) {
                erl_free_compound(e);
                return ret_err(CONFD_ERR_INTERNAL,
                               "Bad stream notification time");
            }
            s->event_time = time.val.datetime;
            s->nvalues = erl_length(TE(event, 1));
            s->values = confd_malloc(s->nvalues * sizeof(confd_tag_value_t));
            if (s->values == NULL) {
                erl_free_compound(e);
                return CONFD_ERR;
            }
            if (etermlist_to_tag_vals(TE(event, 1), s->values, s->nvalues) !=
                s->nvalues) {
                erl_free_compound(e);
                free(s->values);
                return CONFD_ERR;
            }
            for (i = 0; i < s->nvalues; i++) {
                if (confd_dup_value(CONFD_GET_TAG_VALUE(&s->values[i])) ==
                    CONFD_ERR) {
                    erl_free_compound(e);
                    free(s->values);
                    return CONFD_ERR;
                }
            }
            s->type = CONFD_STREAM_NOTIFICATION_EVENT;
        }
        erl_free_compound(e);
        return CONFD_OK;
    }
    }
    n->type = -1;
    return ret_err(CONFD_ERR_INTERNAL, "Bad notification struct");
}


void confd_free_notification(struct confd_notification *n) {
    if (n->type == CONFD_NOTIF_SNMPA) {
        struct confd_snmpa_notification *snmpa = &n->n.snmpa;
        if (snmpa->num_variables != 0) {
            int i;
            for(i=0; i<snmpa->num_variables; i++) {
                struct confd_snmp_varbind *vb = &snmpa->vb[i];
                confd_free_value(&vb->val);
            }
            free(snmpa->vb);
        }
        if (snmpa->pdu_type == CONFD_SNMPA_PDU_V1TRAP) {
            free(snmpa->v1_trap);
        }
#ifdef CONFD_C_PRODUCT_NCS
    } else if (n->type == NCS_NOTIF_CQ_PROGRESS) {
        struct ncs_cq_progress_notification *s = &n->n.cq_progress;
        if (s->ncompleted_devices > 0) {
            int i;
            for (i=0; i<s->ncompleted_devices; i++) {
                free(s->completed_devices[i]);
            }
            free(s->completed_devices);
        }
        if (s->ntransient_devices > 0) {
            int i;
            for (i=0; i<s->ntransient_devices; i++) {
                free(s->transient_devices[i]);
            }
            free(s->transient_devices);
        }
        if (s->nfailed_devices > 0) {
            int i;
            for (i=0; i<s->nfailed_devices; i++) {
                free(s->failed_devices[i]);
                free(s->failed_reasons[i]);
            }
            free(s->failed_devices);
            free(s->failed_reasons);
        }
        if (s->ncompleted_services > 0) {
            int i;
            for (i=0; i<s->ncompleted_services; i++) {
                free(s->completed_services[i]);
                confd_free_dup_value(
                    s->completed_services_completed_devices[i]);
            }
            free(s->completed_services);
            free(s->completed_services_completed_devices);
        }
        if (s->nfailed_services > 0) {
            int i;
            for (i=0; i<s->nfailed_services; i++) {
                free(s->failed_services[i]);
                confd_free_dup_value(s->failed_services_completed_devices[i]);
                confd_free_dup_value(s->failed_services_failed_devices[i]);
            }
            free(s->failed_services);
            free(s->failed_services_completed_devices);
            free(s->failed_services_failed_devices);
        }
#endif
    } else if (n->type == CONFD_NOTIF_STREAM_EVENT) {
        struct confd_stream_notification *stream = &n->n.stream;
        if (stream->type == CONFD_STREAM_NOTIFICATION_EVENT &&
            stream->values != NULL) {
            int i;
            for (i = 0; i < stream->nvalues; i++)
                confd_free_value(CONFD_GET_TAG_VALUE(&stream->values[i]));
            free(stream->values);
        } else if (stream->type == CONFD_STREAM_REPLAY_FAILED &&
                   stream->replay_error != NULL) {
            free(stream->replay_error);
        }
    }
}


int confd_diff_notification_done(int sock, struct confd_trans_ctx  *tctx)
{
    ETERM *reply; ;
    reply = erl_format("{~i, ~a}", tctx->thandle, "done");
    tctx_free(tctx);
    if (term_write(sock, reply, -1 , -1) < 0) {
        erl_free_compound(reply);
        return CONFD_ERR;
    }
    erl_free_compound(reply);
    return CONFD_OK;
}

int confd_sync_audit_notification(int sock, int usid)
{
    ETERM *reply; ;
    reply = erl_format("{~i, ~a}", usid, "synced");
    if (term_write(sock, reply, -1 , -1) < 0) {
        erl_free_compound(reply);
        return CONFD_ERR;
    }
    erl_free_compound(reply);
    return CONFD_OK;
}

int confd_sync_ha_notification(int sock)
{
    ETERM *reply; ;
    reply = erl_mk_atom("ha_synced");
    if (term_write(sock, reply, -1 , -1) < 0) {
        erl_free_compound(reply);
        return CONFD_ERR;
    }
    erl_free_compound(reply);
    return CONFD_OK;
}



/* ha interface code */

int confd_ha_connect(int sock, const struct sockaddr* srv,
                     int srv_sz, const char *token)
{
    int len = strlen(token);
    unsigned char data[len+4];
    int ret;

    if ((ret = confd_do_connect(sock, srv, srv_sz, CLIENT_HA)) != CONFD_OK)
        return ret;
    confd_trace(CONFD_TRACE, "Connected (ha) to ConfD\n");
    put_int32(len, data);
    memcpy(&data[4], token, len);
    if ((ret = confd_write(sock, data, len+4)) != CONFD_OK)
        return ret;
    return CONFD_OK;
}


static ETERM *pack_ha_node(struct confd_ha_node *n)
{
    ETERM *tup[2];

    if ((tup[0] = val_to_term(&n->nodeid)) == NULL)
        return NULL;
    switch (n->af) {
    case AF_INET:
        tup[1] = ip4_to_term(&n->addr.ip4);
        break;
    case AF_INET6:
        tup[1] = ip6_to_term(&n->addr.ip6);
        break;
    case AF_UNSPEC:
        tup[1] = erl_mk_binary(n->addr.str, strlen(n->addr.str));
        break;
    default:
        erl_free_compound(tup[0]);
        return NULL;
    }
    return erl_mk_tuple(tup, 2);
}


/* {NodeId, Addr} */
static int unpack_ha_node(ETERM *src, struct confd_ha_node *dst)
{
    ETERM *eaddr = TE(src, 1);
    if (eterm_to_val(TE(src,0), &dst->nodeid) == NULL)
        return CONFD_ERR;
    if (dst->nodeid.type == C_BUF) {
        int sz = dst->nodeid.val.buf.size;
        if (sz >= sizeof(dst->buf))
            sz = sizeof(dst->buf) - 1;
        memcpy(&dst->buf[0], dst->nodeid.val.buf.ptr, sz);
        dst->buf[sz] = '\0';
        dst->nodeid.val.buf.ptr = (unsigned char*) &dst->buf[0];
        dst->nodeid.val.buf.size = sz;
    }
    if (ERL_IS_TUPLE(eaddr)) {
        if (ERL_TUPLE_SIZE(eaddr) == 4) {
            dst->af = AF_INET;
            term_to_ip4(&dst->addr.ip4, eaddr);
        } else {
            dst->af = AF_INET6;
            term_to_ip6(&dst->addr.ip6, eaddr);
        }
    } else {
        dst->af = AF_UNSPEC;
        if (ERL_IS_BINARY(eaddr)) {
            bin_copy(&dst->addr_buf[0], sizeof(dst->addr_buf), eaddr);
            dst->addr.str = &dst->addr_buf[0];
        } else {
            dst->addr.str = NULL;
        }
    }
    return CONFD_OK;
}




static int ha_read_reply(int sock)
{
    int r;
    ETERM *reply;
    if ((reply = term_read(sock, &r, -1)) == NULL)
        return r;
    if (ERL_IS_ATOM(reply))
        r = CONFD_OK;
    else {
        r = CONFD_ERR;
        confd_set_errno(TINT(reply, 1));
    }
    erl_free_compound(reply);
    return r;
}

static int ha_order_node(int sock, enum confd_ha_order_type ot,
                         confd_value_t *nodeid)
{
    ETERM *otup[4];
    ETERM *eorder;
    int r;
    int  sz = 0;
    clr_confd_err();
    otup[sz++] = erl_mk_int(ot);
    if ((otup[sz++] = val_to_term(nodeid)) == NULL)
        return CONFD_ERR;
    eorder = erl_mk_tuple(otup, sz);
    r = term_write(sock, eorder, -1,-1);
    erl_free_compound(eorder);
    if (r != CONFD_OK) return r;
    return ha_read_reply(sock);
}


int confd_ha_bemaster(int sock, confd_value_t *mynodeid)
{
    return ha_order_node(sock, CONFD_HA_ORDER_BEMASTER, mynodeid);
}

int confd_ha_slave_dead(int sock, confd_value_t *nodeid)
{
    return ha_order_node(sock, CONFD_HA_ORDER_SLAVE_DEAD, nodeid);
}

int confd_ha_beslave(int sock, confd_value_t *mynodeid,
                     struct confd_ha_node *master, int waitreply)
{

    ETERM *otup[4];
    ETERM *eorder;
    int r;
    int  sz = 0;

    otup[sz++] = erl_mk_int(CONFD_HA_ORDER_BESLAVE);
    if ((otup[sz++] = val_to_term(mynodeid)) == NULL)
        return CONFD_ERR;
    otup[sz++]  = pack_ha_node(master);
    otup[sz++] = erl_mk_int(waitreply);

    eorder = erl_mk_tuple(otup, sz);
    r = term_write(sock, eorder, -1,-1);
    erl_free_compound(eorder);
    if (!waitreply || r != CONFD_OK) return r;
    return ha_read_reply(sock);
}


static int ha_order(int sock, enum confd_ha_order_type ot)
{
    ETERM *otup[4];
    ETERM *eorder;
    int r;
    int  sz = 0;

    otup[sz++] = erl_mk_int(ot);
    eorder = erl_mk_tuple(otup, sz);
    r = term_write(sock, eorder, -1,-1);
    erl_free_compound(eorder);
    if (r != CONFD_OK) return r;
    return ha_read_reply(sock);
}

int confd_ha_benone(int sock)
{
    return ha_order(sock, CONFD_HA_ORDER_BENONE);
}

int confd_ha_berelay(int sock)
{
    return ha_order(sock, CONFD_HA_ORDER_BERELAY);
}

int confd_ha_get_status(int sock, struct confd_ha_status *stat)
{
    ETERM *otup[4];
    ETERM *eorder;
    int r,i;
    int  sz = 0;
    ETERM *data, *hd, *tl;

    otup[sz++] = erl_mk_int(CONFD_HA_ORDER_GETSTATUS);
    eorder = erl_mk_tuple(otup, sz);
    r = term_write(sock, eorder, -1,-1);
    erl_free_compound(eorder);
    if (r != CONFD_OK) return r;
    if ((data = term_read(sock, &r, -1)) == NULL)
        return r;
    tl = TE(data, 1);
    i = 0;
    stat->num_nodes = 0;
    stat->state = TUINT(data, 0);
    while (! ERL_IS_EMPTY_LIST(tl)) {
        int tmp;
        /* prepare for next loop */
        hd = ERL_CONS_HEAD(tl);
        tl = ERL_CONS_TAIL(tl);
        if ((tmp = unpack_ha_node(hd, &stat->nodes[i++])) != CONFD_OK)
            return tmp;
    }
    stat->num_nodes = i;
    erl_free_compound(data);
    return CONFD_OK;
}

static int get_maapi_sock(const struct sockaddr* srv, int srv_sz, int *sock)
{
    int ret;

    if ((*sock = socket(srv->sa_family, SOCK_STREAM, 0)) < 0 )
        return ret_err(CONFD_ERR_OS, "Failed to create maapi socket: %s",
                       strerror(errno));
    if ((ret = maapi_connect(*sock, srv, srv_sz)) != CONFD_OK)
        close(*sock);
    return ret;
}

int confd_load_schemas(const struct sockaddr* srv, int srv_sz)
{
    int sock, ret;

    if ((ret = get_maapi_sock(srv, srv_sz, &sock)) != CONFD_OK)
        return ret;
    ret = maapi_load_schemas(sock);
    close(sock);
    return ret;
}

int confd_load_schemas_list(const struct sockaddr* srv, int srv_sz,
                            int flags,
                            const u_int32_t *nshash, const int *nsflags,
                            int num_ns)
{
    int sock, ret;

    if ((ret = get_maapi_sock(srv, srv_sz, &sock)) != CONFD_OK)
        return ret;
    ret = maapi_load_schemas_list(sock, flags, nshash, nsflags, num_ns);
    close(sock);
    return ret;
}



int confd_stream_connect(int sock, const struct sockaddr* srv,
                         int srv_sz, int id, int flags)
{
    unsigned char buf[12];
    int ret;

    if ((ret = confd_do_connect(sock, srv, srv_sz, CLIENT_STREAM)) != CONFD_OK)
        return ret;
    confd_trace(CONFD_TRACE, "Connected (stream) to ConfD\n");

    put_int32(id, buf);
    put_int32(flags, buf+4);
    if ((ret = confd_write(sock, buf, 8)) != CONFD_OK)
        return ret;
    return CONFD_OK;
}
