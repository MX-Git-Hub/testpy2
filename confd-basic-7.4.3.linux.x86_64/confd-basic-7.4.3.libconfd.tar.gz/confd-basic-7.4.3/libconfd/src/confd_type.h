#ifndef _CONFD_TYPE_H_
#define _CONFD_TYPE_H_

#if HAVE_REGEX_H
#include <regex.h>
#else
#define regex_t unsigned int
#endif

#include <inttypes.h>

/* initializes the type handling */
extern void confd_type_init(void);

/* initializes a type. MUST be called before a new type is used */
extern void confd_type_init_type(struct confd_type *type);

/* locate a built-in type by name */
extern struct confd_type *confd_find_type(const char *str);

/* locate a built-in type by confd_value_t type */
extern struct confd_type *confd_find_vtype_type(enum confd_vtype vtype);

/* utility function which parses an 32-bit unisgned int */
extern enum confd_bool confd_parse_uint32(const char *str, const char *str_end,
                                      uint32_t *val);

/*
 * structs and callbacks for enumeration types
 */

struct confd_type_enum {
    const char *name;
    unsigned int len;
    int32_t val;
};

/* use as opaque for enumeration types */
struct confd_type_enums {
    struct confd_type_enum *enm;
    unsigned int enm_len;
};

/* use as str_to_val for enumeration types */
extern int confd_enum_str_to_val(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const char *str, unsigned int len,
                               struct confd_value *v);

/* use as val_to_str for enumeration types */
extern int confd_enum_val_to_str(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const struct confd_value *v,
                               char *str, unsigned int len,
                               const char **strp);

/* use as validate for enumeration types */
extern int confd_enum_validate(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const confd_value_t *v);

/*
 * structs and callbacks for identityref types
 */

struct confd_type_idref {
    const char *qname;
    const char *name;   /* points into qname */
    struct confd_identityref idref;
};

/* use as opaque for identityref types */
struct confd_type_idrefs {
    struct confd_type_idref *idr;
    unsigned int idr_len;
};

/* use as str_to_val for identityref types */
extern int confd_idref_str_to_val(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const char *str, unsigned int len,
                               struct confd_value *v);

/* use as val_to_str for identityref types */
extern int confd_idref_val_to_str(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const struct confd_value *v,
                               char *str, unsigned int len,
                               const char **strp);

/* use as validate for identityref types */
extern int confd_idref_validate(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const confd_value_t *v);

/*
 * structs and callbacks for bits types
 */

struct confd_type_bit {
    const char *name;
    unsigned int len;
    uint64_t value; // (1 << pos for width 32/64, otherwise pos)
};

/* use as opaque for bits types */
struct confd_type_bits {
    struct confd_type_bit *bit;
    unsigned int bit_len;
    unsigned int width;
};

/* use as str_to_val for bits types */
extern int confd_bits_str_to_val(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const char *str, unsigned int len,
                               struct confd_value *v);

/* use as val_to_str for bits types */
extern int confd_bits_val_to_str(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const struct confd_value *v,
                               char *str, unsigned int len,
                               const char **strp);

/* use as validate for bits types */
extern int confd_bits_validate(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const confd_value_t *v);

/*
 * structs and callbacks for union types
 */

struct confd_type_member_type {
    struct confd_type *type;
};

/* use as opaque for union types */
struct confd_type_union {
    struct confd_type_member_type *member_type;
    unsigned int member_type_len;
};

/* use as str_to_val for union types */
extern int confd_union_str_to_val(struct confd_type *self,
                                struct confd_type_ctx *ctx,
                                const char *str, unsigned int len,
                                struct confd_value *v);

/* use as val_to_str for union types */
extern int confd_union_val_to_str(struct confd_type *self,
                                struct confd_type_ctx *ctx,
                                const struct confd_value *v,
                                char *str, unsigned int len,
                                const char **strp);

/* use as validate for union types */
extern int confd_union_validate(struct confd_type *self,
                              struct confd_type_ctx *ctx,
                              const confd_value_t *v);

/*
 * structs and callbacks for list types
 */

/* use as opaque for list types */
struct confd_type_list {
    struct confd_type *type;
};


/* use as str_to_val for list types */
extern int confd_list_str_to_val(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const char *str, unsigned int len,
                               struct confd_value *v);

/* use as val_to_str for list types */
extern int confd_list_val_to_str(struct confd_type *self,
                               struct confd_type_ctx *ctx,
                               const struct confd_value *v,
                               char *str, unsigned int len,
                               const char **strp);


/* use as validate for list types */
extern int confd_list_validate(struct confd_type *self,
                             struct confd_type_ctx *ctx,
                             const confd_value_t *v);


/*
 * structs and callbacks for number (*int*, double, and decimal64) restrictions
 */

#define CONFD_RANGE_MIN_INCLUSIVE (1 << 0)
#define CONFD_RANGE_MIN_EXCLUSIVE (1 << 1)
#define CONFD_RANGE_MAX_INCLUSIVE (1 << 2)
#define CONFD_RANGE_MAX_EXCLUSIVE (1 << 3)

struct confd_range {
    confd_value_t lo;
    confd_value_t hi;
    /* one of CONFD_RANGE_* */
    char flags;
};

/* use as opaque for number types with restrictions */
struct confd_type_number_restriction {
    struct confd_range *range;
    unsigned int range_len;
};

/* use as validate for derived types from numbers */
extern int confd_type_validate_number_restriction(struct confd_type *self,
                                                struct confd_type_ctx *ctx,
                                                const confd_value_t *v);

/*
 * structs and callbacks for string restrictions
 */

struct confd_length {
    confd_value_t lo;
    confd_value_t hi;
};

/* use as opaque for string types with restrictions */
struct confd_type_string_restriction {
    struct confd_length *length;
    unsigned int length_len;
    union {
        regex_t compiled; // has_pattern == 1: compiled regexp, set up by __init
        char *text;       // has_pattern == 2: text regexp
    } pattern;
    char has_pattern;
};

/* use as validate for derived types from strings */
extern int confd_type_validate_string_restriction(struct confd_type *self,
                                                struct confd_type_ctx *ctx,
                                                const confd_value_t *v);

/*
 * structs and callbacks for list restrictions
 */

/* use as opaque for list types with restrictions */
struct confd_type_list_restriction {
    struct confd_length *length;
    unsigned int length_len;
};

/* use as validate for derived types from lists */
extern int confd_type_validate_list_restriction(struct confd_type *self,
                                              struct confd_type_ctx *ctx,
                                              const confd_value_t *v);

/*
 * structs and callbacks for binary types with display_hint given in opaque
 */

/* use as opaque for types with display_hint encodings */
struct confd_type_display_hint {
    char repeat;
    unsigned int length;
    char format;
    char seperator;
    char terminator;
    struct confd_type_display_hint *next;
};

/* use as str_to_val for display_hint types */
extern int confd_display_hint_str_to_val(struct confd_type *self,
                                         struct confd_type_ctx *ctx,
                                         const char *str, unsigned int len,
                                         struct confd_value *v);

/* use as val_to_str for display_hint types */
extern int confd_display_hint_val_to_str(struct confd_type *self,
                                         struct confd_type_ctx *ctx,
                                         const struct confd_value *v,
                                         char *str, unsigned int len,
                                         const char **strp);


/* use as validate for derived types from display_hint */
extern int confd_type_validate_display_hint(struct confd_type *self,
                                            struct confd_type_ctx *ctx,
                                            const confd_value_t *v);


/*
 * structs and callbacks for decimal64 types
 */

/* decimal64 *always* has at least a fraction_digits restriction, hence
   the restricted type is actually the "base" type, similar to enums
   - but it may also have a number restriction                       */

/* use as opaque for decimal64 types */
struct confd_type_decimal64 {
    unsigned int fraction_digits;
    struct confd_type_number_restriction nr;
};

/* use as str_to_val for decimal64 types */
extern int confd_decimal64_str_to_val(struct confd_type *self,
                                    struct confd_type_ctx *ctx,
                                    const char *str, unsigned int len,
                                    struct confd_value *v);

/* use as val_to_str for decimal64 types */
extern int confd_decimal64_val_to_str(struct confd_type *self,
                                    struct confd_type_ctx *ctx,
                                    const struct confd_value *v,
                                    char *str, unsigned int len,
                                    const char **strp);

/* use as validate for decimal64 types */
extern int confd_decimal64_validate(struct confd_type *self,
                                  struct confd_type_ctx *ctx,
                                  const confd_value_t *v);

/* extra utility function for decimal64 types */
extern int confd_pp_decimal64_value(struct confd_decimal64 *d64,
                                  char *str, unsigned int size);


/* use as opaque for user-defined type */
#define CONFD_TYPE_USER 1

#endif
