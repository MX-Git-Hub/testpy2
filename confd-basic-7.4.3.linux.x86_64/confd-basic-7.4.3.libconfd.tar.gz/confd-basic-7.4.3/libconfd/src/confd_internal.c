/*
 * Copyright 2005-2007 Tail-F Systems AB
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <syslog.h>
#include <inttypes.h>
#include <time.h>
#include <sys/time.h>

#include "erl_interface.h"
#include "ei.h"
#include "confd_lib.h"
#include "confd_internal.h"
#include "confd_util.h"
#include "confd_cdb.h"
#include "confd_type.h"
#include "confd_proto.h"
#include "maapi_proto.h"
#include "cdb_proto.h"
#include "confd_ipc_access.h"
#include "hash/hashtable.h"


struct hashtable *hash2str_tab = NULL;
struct hashtable *str2hash_tab = NULL;
int confd_hashtables_mmapped = 0;

FILE *confd_debug_stream = NULL;
enum confd_debug_level confd_debug_level = CONFD_DEBUG;
char confd_daemon_name[64];
int confd_version;
int confd_maxdepth;
int confd_maxkeylen;
unsigned char *confd_ipc_access_secret = NULL;
static char *month2string[] = {
    /* tm_mon in struct tm is 0..11 */
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
};

void *confd_malloc(size_t sz)
{
    void *r;
    if (sz == 0) {
        /* alloc a dummy byte to keep Electric Fence happy */
        sz = 1;
    }
    if ((r = malloc(sz)) == NULL)  {
        confd_report_err(CONFD_DEBUG,
                         "libconfd failed to malloc %" PRIuMAX " bytes\n",
                         (uintmax_t)sz);
        confd_set_errno(CONFD_ERR_MALLOC);
    }
    return r;
}

/* 8-Aug-2014::11:15:53.818 13851/7fa7f4653700/42 SEND
   date        time         pid   thread       fd op
   timestamp format as per ConfD/NCS log files
   (a pthread_t can be anything, but the assumption of "pointer or
   integer with size <= pointer" below covers all cases we've seen) */
static void print_proto_start(FILE *fp, char *prefix, int fd, char *op)
{
    struct timeval tv;
    struct tm tm;

    gettimeofday(&tv, NULL);
    /* cast needed for old FreeBSD where tv_sec is a long */
    localtime_r((time_t *)&tv.tv_sec, &tm);
    fprintf(fp, "%s %d-%s-%d::%.2d:%.2d:%.2d.%.3d %lu/%" PRIxPTR "/%d %s ",
            prefix,
            tm.tm_mday, month2string[tm.tm_mon], 1900 + tm.tm_year,
            tm.tm_hour, tm.tm_min, tm.tm_sec, (int)(tv.tv_usec / 1000),
            (unsigned long)getpid(), (uintptr_t)PTHREAD_SELF(), fd,
            op);
}

void term_to_ip4(struct in_addr *ip, const ETERM *term)
{
    ip->s_addr = htonl(
        (ERL_INT_UVALUE(ERL_TUPLE_ELEMENT(term, 0)) << 24) |
        (ERL_INT_UVALUE(ERL_TUPLE_ELEMENT(term, 1)) << 16) |
        (ERL_INT_UVALUE(ERL_TUPLE_ELEMENT(term, 2)) <<  8) |
        (ERL_INT_UVALUE(ERL_TUPLE_ELEMENT(term, 3))));
}

ETERM *ip4_to_term(const struct in_addr *ip)
{
    uint32_t iv = ntohl(ip->s_addr);
    ETERM *tup[4];

    tup[0] = erl_mk_uint((iv >> 24) & 0xff);
    tup[1] = erl_mk_uint((iv >> 16) & 0xff);
    tup[2] = erl_mk_uint((iv >> 8)  & 0xff);
    tup[3] = erl_mk_uint((iv)       & 0xff);
    return erl_mk_tuple(tup, 4);
}

void term_to_ip6(struct in6_addr *ip6, const ETERM *term)
{
    int i;
    for (i=0; i<8; i++) {
        unsigned int tmp = ERL_INT_UVALUE(ERL_TUPLE_ELEMENT(term, i));
        ip6->s6_addr[(2*i) + 1] = tmp & 0xff;
        ip6->s6_addr[(2*i)] = (tmp >> 8) & 0xff;
    }
}

ETERM *ip6_to_term(const struct in6_addr *ip6)
{
    int i;
    ETERM *tup[8];

    for (i=0; i<8; i++) {
        tup[i] = erl_mk_uint(ip6->s6_addr[(2*i)+1] |
                             ((ip6->s6_addr[2*i]) << 8));
    }
    return erl_mk_tuple(tup, 8);
}


/* Take a value term {TypeEnum, Value} and fill */
/* in a confd_value_t pointer                   */
/* Return NULL on  failure */
confd_value_t *eterm_to_val(const ETERM *term, confd_value_t *v)
{
    if (ERL_IS_INTEGER(term)) {
        v->type = C_INT32;
        v->val.i32 = (int32_t) ERL_INT_VALUE(term);
    }
    else if (ERL_IS_BINARY(term)) {
        v->type = C_BUF;
        v->val.buf.size = ERL_BIN_SIZE(term);
        v->val.buf.ptr = ERL_BIN_PTR(term);
    }
    else if (ERL_IS_ATOM(term)) {
        if (bin_eq(term, "true")) {
            v->type = C_BOOL;
            v->val.boolean = 1;
        }
        else if (bin_eq(term, "false")) {
            v->type = C_BOOL;
            v->val.boolean = 0;
        }
        else if (bin_eq(term, "not_found")) {
            v->type = C_NOEXISTS;
        }
        else if (bin_eq(term, "default")) {
            v->type = C_DEFAULT;
        }
        else {
            v->type = C_BUF;
            v->val.buf.size = ERL_ATOM_SIZE(term);
            v->val.buf.ptr = (unsigned char *)ERL_ATOM_PTR(term);
        }
    }
    else if (ERL_IS_TUPLE(term)) {
        switch (ERL_TUPLE_SIZE(term)) {
        case 2:  {
            int tag = ERL_INT_VALUE(ERL_TUPLE_ELEMENT(term, 0));
            ETERM *vtup = ERL_TUPLE_ELEMENT(term, 1);

            v->type = 0;
            switch((enum confd_vtype)tag) {
            case C_INT8:
                v->type = tag;
                v->val.i8 = (int8_t) ERL_INT_VALUE(vtup);
                break;
            case C_INT16:
                v->type = tag;
                v->val.i16 = (int16_t)  ERL_INT_VALUE(vtup);
                break;
            case C_INT32:
                v->type = tag;
                v->val.i32 = (int32_t)  ERL_INT_VALUE(vtup);
                break;
            case C_INT64:
                v->type = tag;
                switch (ERL_TYPE(vtup)) {
                case ERL_INTEGER:
                    v->val.i64 = (int64_t) ERL_INT_VALUE(vtup);
                    break;
                case ERL_U_INTEGER:
                    v->val.i64 = (int64_t) ERL_INT_UVALUE(vtup);
                    break;
                case ERL_LONGLONG:
                    /* Note: ERL_U_LONGLONG is too big to fit in int64_t,
                    ** hence it is a badterm in this case */
                    v->val.i64 = (int64_t)  ERL_LL_VALUE(vtup);
                    break;
                default:
                    goto badterm;
                }
                break;
            case C_UINT8:
                v->type = tag;
                v->val.u8 = (u_int8_t)  ERL_INT_UVALUE(vtup);
                break;
            case C_UINT16:
                v->type = tag;
                v->val.u16 = (u_int16_t) ERL_INT_UVALUE(vtup);
                break;
            case C_UINT32:
                v->type = tag;
                v->val.u32 = (u_int32_t)  ERL_INT_UVALUE(vtup);
                break;
            case C_UINT64:
            case C_BIT64:
                v->type = tag;
                switch (ERL_TYPE(vtup)) {
                case ERL_INTEGER:
                    v->val.u64 = (u_int64_t) ERL_INT_VALUE(vtup);
                    break;
                case ERL_U_INTEGER:
                    v->val.u64 = (u_int64_t) ERL_INT_UVALUE(vtup);
                    break;
                case ERL_LONGLONG:
                    v->val.u64 = (u_int64_t)  ERL_LL_VALUE(vtup);
                    break;
                case ERL_U_LONGLONG:
                    v->val.u64 = (u_int64_t)  ERL_LL_UVALUE(vtup);
                    break;
                default:
                    goto badterm;
                }
                break;
            case C_QNAME: {
                ETERM *prefix = ERL_TUPLE_ELEMENT(vtup, 0);
                ETERM *name   = ERL_TUPLE_ELEMENT(vtup, 1);
                int plen = ERL_ATOM_SIZE(prefix);
                int nlen = ERL_ATOM_SIZE(name);

                v->type = tag;
                if (bin_eq(prefix, "undefined")) {
                    v->val.qname.prefix.ptr  = NULL;
                    v->val.qname.prefix.size = 0;
                } else {
                    v->val.qname.prefix.ptr  =
                        (unsigned char *)ERL_ATOM_PTR(prefix);
                    v->val.qname.prefix.size = plen;
                }
                v->val.qname.name.ptr  = (unsigned char *)ERL_ATOM_PTR(name);
                v->val.qname.name.size = nlen;
                break;
            }
            case C_DATETIME:
                v->type = tag;
                v->val.datetime.year = TINT(vtup,0);
                v->val.datetime.month = TUINT(vtup,1);
                v->val.datetime.day = TUINT(vtup,2);
                v->val.datetime.hour = TUINT(vtup,3);
                v->val.datetime.min = TUINT(vtup,4);
                v->val.datetime.sec = TUINT(vtup,5);
                v->val.datetime.micro = TUINT(vtup,6);
                v->val.datetime.timezone = TZONE(vtup,7);
                v->val.datetime.timezone_minutes = TUINT(vtup,8);
                break;
            case C_DATE:
                v->type = tag;
                v->val.date.year = TINT(vtup,0);
                v->val.date.month = TUINT(vtup,1);
                v->val.date.day = TUINT(vtup,2);
                v->val.date.timezone = TZONE(vtup,3);
                v->val.date.timezone_minutes = TUINT(vtup,4);
                break;
            case C_TIME:
                v->type = tag;
                v->val.time.hour = TUINT(vtup,0);
                v->val.time.min = TUINT(vtup,1);
                v->val.time.sec = TUINT(vtup,2);
                v->val.time.micro = TUINT(vtup,3);
                v->val.time.timezone = TZONE(vtup,4);
                v->val.time.timezone_minutes = TUINT(vtup,5);
                break;
            case C_DURATION:
                v->type = tag;
                v->val.duration.years = TUINT(vtup,0);
                v->val.duration.months = TUINT(vtup,1);
                v->val.duration.days = TUINT(vtup,2);
                v->val.duration.hours = TUINT(vtup,3);
                v->val.duration.mins = TUINT(vtup,4);
                v->val.duration.secs = TUINT(vtup,5);
                v->val.duration.micros = TUINT(vtup,6);
                break;
            case C_ENUM_HASH:
                v->type = tag;
                v->val.enumhash = (int32_t) ERL_INT_VALUE(vtup);
                break;
            case C_BIT32:
                v->type = tag;
                v->val.b32 = (u_int32_t) ERL_INT_VALUE(vtup);
                break;
            case C_OBJECTREF:
                v->type = tag;
                if ((v->val.hkp=confd_malloc(sizeof (confd_hkeypath_t)))==NULL)
                    return NULL;
                if (!populate_keypath(vtup, v->val.hkp))
                    return NULL;
                break;
            case C_OID: {
                unsigned char *ptr = ERL_BIN_PTR(vtup);
                int i;

                v->type = tag;
                if ((v->val.oidp =
                     confd_malloc(sizeof(struct confd_snmp_oid))) == NULL)
                    return NULL;
                v->val.oidp->len = ERL_BIN_SIZE(vtup) / 4;
                for (i = 0; i < v->val.oidp->len; i++)
                    v->val.oidp->oid[i] = get_int32(&ptr[4*i]);
                break;
            }
            case C_BINARY:
            case C_HEXSTR:
            case C_BITBIG:
                v->type = tag;
                v->val.buf.size = ERL_BIN_SIZE(vtup);
                v->val.buf.ptr = ERL_BIN_PTR(vtup);
                break;
            case C_IPV4PREFIX:
                v->type = tag;
                term_to_ip4(&v->val.ipv4prefix.ip, ERL_TUPLE_ELEMENT(vtup, 0));
                v->val.ipv4prefix.len =
                    (u_int8_t) ERL_INT_VALUE(ERL_TUPLE_ELEMENT(vtup, 1));
                break;
            case C_IPV6PREFIX:
                v->type = tag;
                term_to_ip6(&v->val.ipv6prefix.ip6, ERL_TUPLE_ELEMENT(vtup, 0));
                v->val.ipv6prefix.len =
                    (u_int8_t) ERL_INT_VALUE(ERL_TUPLE_ELEMENT(vtup, 1));
                break;
            case C_DECIMAL64: {
                ETERM *val = ERL_TUPLE_ELEMENT(vtup, 0);
                ETERM *fd  = ERL_TUPLE_ELEMENT(vtup, 1);

                v->type = tag;
                switch (ERL_TYPE(val)) {
                case ERL_INTEGER:
                    v->val.d64.value = (int64_t) ERL_INT_VALUE(val);
                    break;
                case ERL_U_INTEGER:
                    v->val.d64.value = (int64_t) ERL_INT_UVALUE(val);
                    break;
                case ERL_LONGLONG:
                    /* Note: ERL_U_LONGLONG is too big to fit in int64_t,
                    ** hence it is a badterm in this case */
                    v->val.d64.value = (int64_t)  ERL_LL_VALUE(val);
                    break;
                default:
                    goto badterm;
                }
                v->val.d64.fraction_digits = (u_int8_t) ERL_INT_UVALUE(fd);
                break;
            }
            case C_IDENTITYREF:
                v->type = tag;
                v->val.idref.ns = TUINT(vtup,0);
                v->val.idref.id = TUINT(vtup,1);
                break;
            case C_IPV4_AND_PLEN:
                v->type = tag;
                term_to_ip4(&v->val.ipv4prefix.ip, ERL_TUPLE_ELEMENT(vtup, 0));
                v->val.ipv4prefix.len =
                    (u_int8_t) ERL_INT_VALUE(ERL_TUPLE_ELEMENT(vtup, 1));
                break;
            case C_IPV6_AND_PLEN:
                v->type = tag;
                term_to_ip6(&v->val.ipv6prefix.ip6, ERL_TUPLE_ELEMENT(vtup, 0));
                v->val.ipv6prefix.len =
                    (u_int8_t) ERL_INT_VALUE(ERL_TUPLE_ELEMENT(vtup, 1));
                break;
            case C_DQUAD:
                v->type = tag;
                memcpy(v->val.dquad.quad, ERL_BIN_PTR(vtup), 4);
                break;
            case C_NOEXISTS:
            case C_XMLTAG:
            case C_SYMBOL:
            case C_STR:
            case C_BUF:
            case C_DOUBLE:
            case C_IPV4:
            case C_IPV6:
            case C_BOOL:
            case C_LIST:
            case C_XMLBEGIN:
            case C_XMLEND:
            case C_UNION:
            case C_PTR:
            case C_CDBBEGIN:
            case C_XMLBEGINDEL:
            case C_MAXTYPE:
            case C_DEFAULT:
            case C_XMLMOVEFIRST:
            case C_XMLMOVEAFTER:
                goto badterm;
            }
            if (v->type == 0)
                goto badterm;
            break;
        }
        case 4:  /* implicit IP v4 address */
            v->type = C_IPV4;
            term_to_ip4(&v->val.ip, term);
            break;
        case 8:  /* implicit ip V6 addr */
            v->type = C_IPV6;
            term_to_ip6(&v->val.ip6, term);
            break;
        default:
            goto badterm;
        }
    }
    else if (ERL_IS_FLOAT(term)) {
        v->type = C_DOUBLE;
        v->val.d = ERL_FLOAT_VALUE(term);
    }
    else if (ERL_IS_CONS(term) &&
             IS_INTEGER_OR_UNSIGNED_INTEGER(ERL_CONS_TAIL(term))) {
        v->type = C_XMLTAG;
        v->val.xmltag.ns = ERL_INT_UVALUE(ERL_CONS_HEAD(term));
        v->val.xmltag.tag = ERL_INT_UVALUE(ERL_CONS_TAIL(term));
    }
    else if (ERL_IS_LIST(term)) {
        int i=0;
        const ETERM *hd, *tl;
        v->type = C_LIST;
        v->val.list.ptr = confd_malloc(sizeof(confd_value_t)*erl_length(term));
        if (v->val.list.ptr == NULL) return NULL;
        v->val.list.size = 0;
        tl = term;
        while (! ERL_IS_EMPTY_LIST(tl)) {
            /* prepare for next loop */
            hd = ERL_CONS_HEAD(tl);
            tl = ERL_CONS_TAIL(tl);
            if (eterm_to_val(hd, &v->val.list.ptr[i++]) == NULL)
                return NULL;
            v->val.list.size++;
        }
    }
    else {
        goto badterm;
    }
    return v;

  badterm:
    if (confd_debug_level > 0 && confd_debug_stream) {
        fprintf(confd_debug_stream, "BADTERM: ");
        erl_print_term(confd_debug_stream, term);
        fprintf(confd_debug_stream, "\n");
    }
    confd_internal_error("Internal error, Bad term value");
    return NULL;
}

/* return total # of elems or CONFD_ERR on malloc error */
int etermlist_to_vals(ETERM *list, confd_value_t *vp, int n)
{
    int i;

    for (i = 0; !ERL_IS_NIL(list); i++) {
        if (!ERL_IS_CONS(list))
            return confd_internal_error("Internal error, bad value list\n");
        if (i < n) {
            if (eterm_to_val(ERL_CONS_HEAD(list), &vp[i]) == NULL)
                return CONFD_ERR;
        }
        list = ERL_CONS_TAIL(list);
    }
    return i;
}


confd_tag_value_t *eterm_to_tag_val(const ETERM *term, confd_tag_value_t *tv,
                                    int allow_unqualified)
{
    ETERM *tag = ERL_TUPLE_ELEMENT(term, 0);
    ETERM *value = ERL_TUPLE_ELEMENT(term, 1);

    if (ERL_IS_LIST(tag)) {
        tv->tag.ns = ERL_INT_UVALUE(ERL_CONS_HEAD(tag));
        tv->tag.tag = ERL_INT_UVALUE(ERL_CONS_TAIL(tag));
    } else if (allow_unqualified && IS_INTEGER_OR_UNSIGNED_INTEGER(tag)) {
        tv->tag.ns = 0;
        tv->tag.tag = ERL_INT_UVALUE(tag);
    } else {
        confd_internal_error("Internal error, bad tag element\n");
        return NULL;
    }
    if (ERL_IS_ATOM(value)) {
        if (bin_eq(value, "start")) {
            tv->v.type = C_XMLBEGIN;
            tv->v.val.xmltag = tv->tag;
        } else if (bin_eq(value, "delete")) {
            tv->v.type = C_XMLBEGINDEL;
            tv->v.val.xmltag = tv->tag;
        } else if (bin_eq(value, "stop")) {
            tv->v.type = C_XMLEND;
            tv->v.val.xmltag = tv->tag;
        } else if (bin_eq(value, "leaf")) {
            tv->v.type = C_XMLTAG;
            tv->v.val.xmltag = tv->tag;
        } else if (bin_eq(value, "move_first")) {
          tv->v.type = C_XMLMOVEFIRST;
          tv->v.val.xmltag = tv->tag;
        } else if (bin_eq(value, "move_after")) {
          tv->v.type = C_XMLMOVEAFTER;
          tv->v.val.xmltag = tv->tag;
        } else if (eterm_to_val(value, &tv->v) == NULL) {
            return NULL;
        }
    } else if (eterm_to_val(value, &tv->v) == NULL) {
        return NULL;
    }
    return tv;
}

/* return total # of elems or CONFD_ERR on malloc error */
int etermlist_to_tag_vals(ETERM *list, confd_tag_value_t *tvp, int n)
{
    int i;

    for (i = 0; !ERL_IS_NIL(list); i++) {
        if (!ERL_IS_CONS(list)) {
            confd_internal_error("Internal error, bad tag value list\n");
            return -1;
        }
        if (i < n) {
            if (eterm_to_tag_val(ERL_CONS_HEAD(list), &tvp[i], 0) == NULL)
                return CONFD_ERR;
        }
        list = ERL_CONS_TAIL(list);
    }
    return i;
}


/* Use this function to free "internal" allocation in value
   from  eterm_to_val(), i.e. w/o any dup function applied */
/* (C_BUF, C_BINARY, C_HEXSTR, C_BITBIG, and C_QNAME
   point into the Erlang term) */
void confd_free_eterm_val(confd_value_t *v)
{
    switch (v->type) {
    case C_LIST: {
        int i;
        /* We can have a list of C_OID... */
        for (i = 0; i < v->val.list.size; i++)
            confd_free_eterm_val(&v->val.list.ptr[i]);
        free(v->val.list.ptr);
        break;
    }
    case C_OBJECTREF:
        /* We can have C_OID keys... */
        confd_free_eterm_keypath(v->val.hkp);
        free(v->val.hkp);
        break;
    case C_OID:
        free(v->val.oidp);
        break;
    default:
        break;
    }
}

/* As above for keypaths - C_OID keys need it */
void confd_free_eterm_keypath(confd_hkeypath_t *kp)
{
    int i, j;

    for (i = 0; i < kp->len; i++) {
        if (kp->v[i][0].type != C_XMLTAG) {
            for (j = 0; kp->v[i][j].type != C_NOEXISTS; j++)
                confd_free_eterm_val(&kp->v[i][j]);
        }
    }
}


/* Take [Tag1, {K}, Tag2, Tag3, {K2,3} ..] and populate args
 * TagN = uint32
 */
int populate_keypath(const ETERM *kp, confd_hkeypath_t *args)
{
    const ETERM *hd, *tl;
    int i, j, last_marker;

    last_marker = 0;
    j = 0;
    tl = kp;
    while (! ERL_IS_EMPTY_LIST(tl)) {
        int sz;
        i = 0;
        /* prepare for next loop */
        hd = ERL_CONS_HEAD(tl);
        tl = ERL_CONS_TAIL(tl);

        if (ERL_IS_LIST(hd)) {
            /* we have a namespace marked xmltag        */
            /* patch all previous C_XMLTAG items        */

            ETERM *ns, *tag;
            int n;
            ns = ERL_CONS_HEAD(hd);
            tag = ERL_CONS_TAIL(hd);
            args->v[j][0].type = C_XMLTAG;
            args->v[j][0].val.xmltag.tag = ERL_INT_UVALUE(tag);
            args->v[j][1].type = C_NOEXISTS;
            for (n=last_marker; n < (j+1); n++) {
                if (args->v[n][0].type == C_XMLTAG) {
                    args->v[n][0].val.xmltag.ns = ERL_INT_UVALUE(ns);
                }
            }
            last_marker = ++j;
        }
        else if (IS_INTEGER_OR_UNSIGNED_INTEGER(hd)) {
            /* this is an xmltag, we don't yet know the */
            /* namespace, it will come later */
            args->v[j][0].type = C_XMLTAG;
            args->v[j][0].val.xmltag.tag = ERL_INT_UVALUE(hd);
            args->v[j][1].type = C_NOEXISTS;
            j++;
        }
        else if (ERL_IS_TUPLE(hd)) {
            /* this is a key element */

            sz = ERL_TUPLE_SIZE(hd);
            for (i=0; i<sz; i++) {
                confd_value_t *vptr;
                if (i == MAXKEYLEN) {
                    confd_internal_error(
                        "Max num keys (%d) of config tree overrun", MAXKEYLEN);
                    return 0;
                }
                vptr = &args->v[j][i];
                if (eterm_to_val(ERL_TUPLE_ELEMENT(hd,i), vptr)==NULL) {
                    return 0;
                }
            }
            args->v[j][i].type = C_NOEXISTS;  /* end marker */
            j++;
        }
        else {
            confd_internal_error("Bad keypath value\n");
            return 0;
        }
        if (j == MAXDEPTH) {
            confd_internal_error("Maxdepth (%d) of config tree overrun",
                                 MAXDEPTH);
            return 0;
        }
    }
    args->v[j][0].type = C_NOEXISTS;
    args->len  = j;
    return 1;
}


void v_confd_trace(int syslogprio, enum confd_debug_level level,
                   const char  *fmt, va_list args)
{
    char buf[BUFSIZ];
    char *bufptr = &buf[0];
    int buflen = sizeof(buf);
    char *s, *e;
    char *mbuf = NULL;
    int len, elen, printlen, mlen;
    va_list args2;

    if (level <= confd_debug_level) {
        s = "TRACE "; e = "";
        if (level == CONFD_DEBUG) {
            s = "DEBUG ";
            e = "\n";
        }
        len = strlen(s);
        elen = strlen(e);

        va_copy(args2, args);
        snprintf(bufptr, buflen, "%s ", s);
        printlen = vsnprintf(&bufptr[len], buflen - len, fmt, args);
        if (printlen + elen >= buflen - len) {
            mlen = len + printlen + elen + 1;
            if ((mbuf = malloc(mlen)) != NULL) { /* otherwise truncate */
                bufptr = mbuf;
                buflen = mlen;
                snprintf(bufptr, buflen, "%s ",s);
                vsnprintf(&bufptr[len], buflen - len, fmt, args2);
            }
        }
        len = strlen(bufptr);
        snprintf(&bufptr[len], buflen - len, "%s", e);
        confd_printf(syslogprio, "%s", bufptr);
        if (mbuf != NULL)
            free(mbuf);
    }
}

extern PTHREAD_KEY_T confd_syslog_buf_key;

void confd_vprintf(int syslogprio, const char  *fmt, va_list args)
{
    va_list args2;

    if(confd_debug_stream != NULL)  {
        va_copy(args2, args);
        vfprintf(confd_debug_stream, fmt, args2);
    }
    if (confd_lib_use_syslog != 0) {
        char *sbuf;
        int sofar;
        int written;

        if ((sbuf = (char*)PTHREAD_GETSPECIFIC(confd_syslog_buf_key))
            == NULL) {
            sbuf = malloc(1024);
            sbuf[0] = 0;
            PTHREAD_SETSPECIFIC(confd_syslog_buf_key, (void*) sbuf);
        }
        sofar = strlen(sbuf);
        va_copy(args2, args);
        written = vsnprintf(&sbuf[sofar], 1024-sofar, fmt, args2);
        if (((written + sofar) >= 1024) ||
            (sbuf[sofar+written-1] == '\n'))  {
            syslog(syslogprio, "%s", sbuf);
            sbuf[0] = 0;
        }
    }
    if (confd_user_log_hook != NULL) {
        va_copy(args2, args);
        confd_user_log_hook(syslogprio, fmt, args2);
    }
}

void confd_printf(int syslogprio, const char  *fmt, ...)
{
     va_list args;

     va_start(args, fmt);
     confd_vprintf(syslogprio, fmt, args);
     va_end(args);
}


void confd_trace_printf(const char  *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    confd_vprintf(LOG_DEBUG, fmt, args);
    va_end(args);
}



void confd_trace(enum confd_debug_level level,const char  *fmt, ...)
{
    int syslog_level;
    va_list args;
    va_start(args, fmt);
    if (level == CONFD_TRACE)
        syslog_level = LOG_DEBUG;
    else
        syslog_level = LOG_ERR;
    v_confd_trace(syslog_level, level, fmt, args);
    va_end(args);
}


void confd_report_err(enum confd_debug_level level,const char  *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    v_confd_trace(LOG_ERR, level, fmt, args);
    va_end(args);
}


static int ret_eof(const char *fmt, ...);

int confd_do_connect(int sock, const struct sockaddr *srv, int srv_sz, int id)
{
    unsigned char buf[10];
    unsigned char reply[10];
    int ret;
    int do_access = confd_ipc_access_secret != NULL;
    int one = 1;

    if (confd_check_init() != CONFD_OK)
        return CONFD_ERR;
    clr_confd_err();
    if ((ret = connect(sock, srv, srv_sz)) < 0)
        return ret_err(CONFD_ERR_OS, "Failed to connect to ConfD: %s",
                       strerror(errno));
    if ((srv->sa_family == AF_INET || srv->sa_family == AF_INET6) &&
        id != CLIENT_STREAM)
        (void)setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
    buf[0] = id;
    if (do_access)
        buf[0] |= IPC_PROTO_WANT_CHALLENGE;
    put_int16(CONFD_LIB_PROTO_VSN, &buf[1]);
    put_int32(CONFD_LIB_VSN, &buf[3]);
    buf[7] = MAXDEPTH;
    buf[8] = MAXKEYLEN;
    if ((ret = confd_write(sock, buf, 9)) != CONFD_OK)
        return ret;
    if (do_access) {
        switch (confd_ipc_access_check(sock, confd_ipc_access_secret)) {
        case 1:  /* success */
            break;
        case 0:
            return ret_err(CONFD_ERR_PROTOUSAGE, "Access denied");
        default:
            return ret_err(CONFD_ERR_PROTOUSAGE, "Access check failed");
        }
    }
    if ((ret = read_fill(sock, reply, 9)) != 9) {
        return ret;
    }
    switch (reply[0]) {
    case IPC_PROTO_OK:
        confd_version = get_int32(&reply[3]);
        confd_maxdepth = reply[7];
        confd_maxkeylen = reply[8];
        return CONFD_OK;
    case IPC_PROTO_BAD_VSN:
        return ret_err(CONFD_ERR_PROTOUSAGE, "Library protocol version (%d) "
                       "is not compatible with ConfD protocol version (%d)",
                       CONFD_LIB_PROTO_VSN, get_int16(&reply[1]));
    case IPC_PROTO_BAD_SIZES:
        confd_maxdepth = reply[7];
        confd_maxkeylen = reply[8];
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Library MAXDEPTH/MAXKEYLEN %d/%d for confd_hkeypath_t "
                       "are too small, ConfD needs %d/%d",
                       MAXDEPTH, MAXKEYLEN, confd_maxdepth, confd_maxkeylen);
    }
    return confd_internal_error("Failed to decode data");
}

int read_fill(int fd, unsigned char *buf, int len)
{
    int i;
    unsigned int got = 0;

    do {
        if ((i = read(fd, buf+got, len-got)) <= 0) {
            if (i == 0 || (i < 0 && errno == ECONNRESET)) {
                return ret_eof("EOF on socket to ConfD");
            }
            if (errno != EINTR) {
                return ret_err(CONFD_ERR_OS,
                               "Failed to read %d bytes from ConfD: %s",
                               len,strerror(errno));
            }
            i = 0;
        }
        got += i;
    } while (got < len);
    return (len);
}



int write_fill(int fd, const unsigned char *buf, int len)
{
    int i;
    unsigned int done = 0;

    do {
        if ((i = write(fd, (char *)(buf+done), len-done)) < 0) {
            if (errno == EPIPE || errno == ECONNRESET) {
                return ret_eof("Socket to ConfD is closed");
            }

#ifdef __APPLE__
            /*
              In Yosemite and later, there is an undocumented feature
              where if the socket is being taken down while you do a
              sendto, or write, it can return EPROTOTYPE. If you retry the
              sendto you will get the EPIPE.

              The bug report can be found at:
              http://openradar.appspot.com/19012087
            */
            if (errno == EPROTOTYPE) {
                return ret_eof("Socket to ConfD is closed");
            }
#endif

            if (errno != EINTR)
                return ret_err(CONFD_ERR_OS,
                               "Failed to write %d bytes to ConfD: %s",
                               len-done, strerror(errno));
            i = 0;
        }
        done += i;
    } while (done < len);
    return (len);
}


int confd_write(int socket, const unsigned char *buf, int len)
{
    int rval;

    if ((rval = write_fill(socket, buf, len)) != len)
        return rval;
    return CONFD_OK;
}


/* Print junk to stderr and die */
void confd_fatal(const char *fmt, ...)
{
    va_list args;

    if (strlen(fmt) > 0) {
        va_start(args,fmt);
        vfprintf(stderr,fmt,args);
        va_end(args);
    }
    exit(1);
}


int confd_internal_error(const char *fmt, ...)
{
    char buf[BUFSIZ];
    FILE *fp = confd_debug_stream;
    va_list args;

    if (strlen(fmt) > 0) {
        va_start(args, fmt);
        vsnprintf(buf, sizeof(buf), fmt, args);
        va_end(args);
        if (fp == NULL)
            fp = stderr;
        fprintf(fp, "INTERNAL ERROR: %s\n", buf);
        if (confd_lib_use_syslog)
            syslog(LOG_CRIT, "INTERNAL ERROR: %s", buf);
        if (confd_user_log_hook != NULL) {
            va_start(args, fmt);
            confd_user_log_hook(LOG_CRIT, fmt, args);
            va_end(args);
        }
        confd_set_lasterr("%s", buf);
    }
    confd_set_errno(CONFD_ERR_INTERNAL);
    return CONFD_ERR;
}



int ret_err(int ecode, const char *fmt, ...)
{
    va_list args;
    int saved_errno = errno;

    va_start(args,fmt);
    confd_vset_lasterr(fmt, args);
    va_end(args);
    va_start(args,fmt);
    v_confd_trace(LOG_ERR, CONFD_DEBUG, fmt, args);
    va_end(args);
    confd_set_errno(ecode);
    errno = saved_errno;
    return CONFD_ERR;
}


void *ret_null(const char *fmt, ...)
{
    va_list args;
    int saved_errno = errno;

    va_start(args,fmt);
    confd_vset_lasterr(fmt, args);
    va_end(args);
    va_start(args,fmt);
    v_confd_trace(LOG_ERR, CONFD_DEBUG, fmt, args);
    va_end(args);
    errno = saved_errno;
    return NULL;
}


static int ret_eof(const char *fmt, ...)
{
    va_list args;
    va_start(args,fmt);
    confd_vset_lasterr(fmt, args);
    va_end(args);
    va_start(args,fmt);
    v_confd_trace(LOG_ERR, CONFD_DEBUG, fmt, args);
    va_end(args);
    confd_set_errno(CONFD_ERR_EOF);
    return CONFD_EOF;
}


int op_write(int socket, unsigned int op, int thandle)
{
    int len;
    unsigned char buf[12];
    int ret;

    put_int32(op, buf+4);
    if (thandle == -1) {
        put_int32(4, buf);
        len = 8;
    }
    else {
        put_int32(8, buf);
        len = 12;
        put_int32(thandle, &buf[8]);
    }
    if ((ret = confd_write(socket, buf, len)) != CONFD_OK)
        return ret;
    return CONFD_OK;
}

/* writes OP + xlen bytes from xbuf */
int op_write_buf(int socket,unsigned int op, const char *xbuf,
                 int xlen, int thandle)
{
    int len;
    unsigned char buf[12];
    int ret;

    put_int32(op, buf+4);
    if (thandle == -1) {
        put_int32(4 + xlen, buf);
        len = 8;
    }
    else {
        put_int32(8 + xlen, buf);
        len = 12;
        put_int32(thandle, &buf[8]);
    }
    /* First length bytes + OP */
    if ((ret = confd_write(socket, buf, len)) != CONFD_OK)
        return ret;
    /* Then xbuf... */
    if ((ret = confd_write(socket,(unsigned char *)xbuf, xlen)) != CONFD_OK)
        return ret;
    return CONFD_OK;
}


int term_write(int socket, const ETERM *term, unsigned int cdbop, int thandle)

{
    unsigned char *buf;
    unsigned char *encode_pos;
    int termlen = erl_term_len((ETERM*)term);
    int len = termlen;
    int ret;

    if (cdbop == -1 && thandle == -1) {
        if ((buf = (unsigned char*) confd_malloc(len+4)) == NULL)
            return CONFD_ERR;
        encode_pos = buf+4;
    }
    else if (thandle == -1) { /* cdb or maapi call */
        if ((buf = (unsigned char*) confd_malloc(len+8)) == NULL)
            return CONFD_ERR;
        put_int32(cdbop, buf+4);
        len += 4;
        encode_pos = buf+8;
    }
    else { /* maapi call containing tid */
        if ((buf = (unsigned char*) confd_malloc(len+12)) == NULL)
            return CONFD_ERR;
        put_int32(cdbop, buf+4);
        put_int32(thandle, buf+8);
        len += 8;
        encode_pos = buf+12;
    }

    if (erl_encode((ETERM*)term, encode_pos) == 0) {
        free(buf);
        return confd_internal_error("failed to encode");
    }
    put_int32(len, &buf[0]);
    ret = confd_write(socket, buf, len+4);
    free(buf);
    if (ret != CONFD_OK)
        return ret;
    if ((confd_debug_level == CONFD_PROTO_TRACE) &&
        (confd_debug_stream != NULL)) {
        print_proto_start(confd_debug_stream, "\n", socket, "SEND");
        if (cdbop != -1) {
            fprintf(confd_debug_stream, "op=%d isrel=%d th=%d ",
                    CDB_OP(cdbop), CDB_IS_REL(cdbop), thandle);
        }
        erl_print_term(confd_debug_stream, term);
        fprintf(confd_debug_stream, "\n");
    }
    return CONFD_OK;
}



/* Read an ETERM on a socket */
ETERM *term_read(int socket, int *ret, unsigned int cdbop)
{
    ETERM *res = NULL;
    unsigned char *buf;
    unsigned char lb[4];
    int len, rval;
    confd_value_t tag;

    *ret = CONFD_OK;
    if ((rval = read_fill(socket, &lb[0], 4)) != 4) {
        *ret = rval;
        return NULL;
    }
    len = get_int32(lb);
    if ((buf = (unsigned char*) confd_malloc(len)) ==  NULL) {
        *ret = CONFD_ERR;
        return NULL;
    }

    if ((rval = read_fill(socket, buf, len)) != len) {
        free(buf);
        *ret = rval;
        return NULL;
    }
    if (cdbop == -1) { /* call is ext db  */
        if ((res = erl_decode(buf)) == NULL) {
            free(buf);
            *ret = confd_internal_error("Failed to decode data");
            return NULL;
        }
    } else { /* call is from CDB or maapi */
        int recop = get_int32(buf);
        if (recop == cdbop && len != 4) {
            if ((res = erl_decode(buf+4)) == NULL) {
                *ret = confd_internal_error("Failed to decode data\n");
                free(buf);
                return NULL;
            }
        }
        else if (recop == cdbop) {
            *ret = CONFD_OK;
            free(buf);
            return NULL;
        }
        else {
            int ecode;
            if (CDB_REPLY_IS_ERROR(recop) && CDB_OP(recop) == cdbop) {
                confd_lasterr()[0] = 0;
                CONFD_SET_XMLTAG(&tag, 0, 0);
                *confd_last_error_apptag() = tag.val.xmltag;
                if (len == 8) { /* we got plain error */
                    *ret = CONFD_ERR;
                    ecode = get_int32(buf+4);
                    confd_set_errno(ecode);
                    confd_report_err(CONFD_DEBUG,"Op returned error\n");
                    free(buf);
                    return NULL;
                }
                else {
                    ecode = get_int32(buf+4);
                    confd_set_errno(ecode);
                    if ((res = erl_decode(buf+8)) == NULL) {
                        *ret = confd_internal_error("Failed to decode data\n");
                        free(buf);
                        return NULL;
                    }
                    if (ERL_IS_BINARY(res)) {
                        confd_set_lasterr("%s", ERL_BIN_PTR(res));
                    } else {
                        /* {Str::binary(), Tag::[integer()|integer()]} */
                        confd_set_lasterr("%s", ERL_BIN_PTR(TE(res, 0)));
                        if (eterm_to_val(TE(res, 1), &tag) != NULL
                            && tag.type == C_XMLTAG) {
                            *confd_last_error_apptag() = tag.val.xmltag;
                        }
                    }
                    confd_report_err(CONFD_DEBUG,"%s - %s",
                                     confd_strerror(ecode), confd_lasterr());
                    erl_free_compound(res);
                    free(buf);
                    *ret = CONFD_ERR;
                    return NULL;
                }
            }
            else {
                free(buf);
                *ret = confd_internal_error(
                    "Unexpected data on socket! %d %d\n", cdbop, recop);
                return NULL;
            }
        }
    }
    if ((confd_debug_level >= CONFD_PROTO_TRACE) &&
        (confd_debug_stream != NULL)) {
        print_proto_start(confd_debug_stream, "", socket, "GOT");
        if (res) {
            erl_print_term(confd_debug_stream, res);
            fprintf(confd_debug_stream, "\n");
        }
        else {
            fprintf(confd_debug_stream, "NULL\n");
        }
    }
    *ret = CONFD_OK;
    free(buf);
    return res;
}



static char *ret2str(int ret)
{
    switch(ret) {
    case CONFD_OK: return "CONFD_OK";
    case CONFD_ERR: return "CONFD_ERR";
    case CONFD_EOF: return "CONFD_EOF";
    default: return "UNKNOWN";
    }
}

static void cdb_ret_trace(int ret, ETERM *val)
{
    if (confd_debug_level >= CONFD_TRACE)
        confd_trace_printf(" --> %s\n", ret2str(ret));
}

ETERM *confd_call(int socket, const ETERM *term, int *status)
{
    ETERM *reply;

    if ((*status = term_write(socket, term, -1, -1)) < 0)
        return NULL;
    if ((reply = term_read(socket, status, -1)) == NULL)
        return NULL;
    if (ERL_IS_TUPLE(reply) && (ERL_TUPLE_SIZE(reply) == 3) &&
        ERL_IS_ATOM(TE(reply, 0)) && bin_eq(TE(reply, 0), "error")) {
        /* {error, Code, Reason} */
        *status = ret_err(TINT(reply, 1), "%s",
                          (char *)ERL_BIN_PTR(TE(reply, 2)));
        erl_free_compound(reply);
        return NULL;
    }
    return reply;
}



unsigned char *confd_memdup(const unsigned char* p, int n)
{
    unsigned char *r = (unsigned char *)confd_malloc(n+1);

    if (r) {
        r[n] = 0;
        return (unsigned char *)memcpy(r, p, (size_t)n);
    }
    return NULL;
}

#define INVALID_TERM_IF(exp) \
    if (exp) { \
        return confd_internal_error("Invalid term to format_path()\n"); \
    }

static int format_path_keys(ETERM *tuple, char *buf, int bufsiz)
{
    int n = 0;
    int i;

    for (i = 0; i < ERL_TUPLE_SIZE(tuple); i++) {
        ETERM *term = ERL_TUPLE_ELEMENT(tuple, i);
        INVALID_TERM_IF(bufsiz < 2);
        if (i > 0) {
            buf[n++] = ' ';
            bufsiz--;
        }
        if (ERL_IS_BINARY(term)) {
            INVALID_TERM_IF(bufsiz <= ERL_BIN_SIZE(term));
            memcpy(&buf[n], ERL_BIN_PTR(term), ERL_BIN_SIZE(term));
            n += ERL_BIN_SIZE(term);
            bufsiz -= ERL_BIN_SIZE(term);
        } else {
            /* this is a bit heavy... */
            confd_value_t v;
            int tmp;
            if (eterm_to_val(term, &v) == NULL) {
                return confd_internal_error(
                    "Unexpected term to format_path_keys()\n");
            }
            tmp = confd_pp_value(&buf[n], bufsiz, &v);
            confd_free_eterm_val(&v);
            INVALID_TERM_IF(tmp >= bufsiz);
            n += tmp;
            bufsiz -= tmp;
        }
        buf[n] = 0;
    }
    return n;
}

#define MAYBE_SLASH(buf, n, slash) if (slash) buf[n++] = '/';

static int format_path_term(ETERM *term, int slash, char *buf, int bufsiz)
{
    int n = 0;

    if (ERL_IS_BINARY(term)) {
        n = confd_strncpy(buf, bufsiz, ERL_BIN_PTR(term), ERL_BIN_SIZE(term));
        INVALID_TERM_IF(n < ERL_BIN_SIZE(term));
        return n;
    }

    /* the result of /foo[55] */
    if (ERL_IS_LIST(term) && ERL_IS_NIL(ERL_CONS_TAIL(term))) {
        n = confd_snprintf(buf, bufsiz, "[%d]",
                           ERL_INT_VALUE(ERL_CONS_HEAD(term)));
        INVALID_TERM_IF(n >= bufsiz);
        return n;
    }

    /* [ns|tag] pair - atoms or integers */
    if (ERL_IS_LIST(term)) {
        ETERM *ns = ERL_CONS_HEAD(term);
        ETERM *tag = ERL_CONS_TAIL(term);
        if (ERL_IS_ATOM(ns)) {
            int isiz = ERL_ATOM_SIZE(ns) + ERL_ATOM_SIZE(tag) + slash
                + 2; /* +2 = ':' + <null> */
            INVALID_TERM_IF(bufsiz < isiz);
            MAYBE_SLASH(buf, n, slash);
            memcpy(&buf[n], ERL_ATOM_PTR(ns), ERL_ATOM_SIZE(ns));
            n += ERL_ATOM_SIZE(ns);
            buf[n++] = ':';
            memcpy(&buf[n], ERL_ATOM_PTR(tag), ERL_ATOM_SIZE(tag));
            n += ERL_ATOM_SIZE(tag);
            buf[n] = 0;
        } else {
            char *s;
            INVALID_TERM_IF(bufsiz < slash + 4); /* +4 = x:x<null> */
            MAYBE_SLASH(buf, n, slash);
            if ((s = confd_ns2prefix(ERL_INT_UVALUE(ns))) != NULL) {
                n += confd_snprintf(&buf[n], bufsiz - n, "%s:", s);
            } else {
                n += confd_snprintf(&buf[n], bufsiz - n, "<%u>:",
                                    ERL_INT_UVALUE(ns));
            }
            INVALID_TERM_IF(n >= bufsiz);
            if ((s = confd_hash2str(ERL_INT_UVALUE(tag))) != NULL) {
                n += confd_snprintf(&buf[n], bufsiz - n, "%s", s);
            } else {
                n += confd_snprintf(&buf[n], bufsiz - n, "<%u>",
                                    ERL_INT_UVALUE(tag));
            }
            INVALID_TERM_IF(n >= bufsiz);
        }
        return n;
    }

    if (ERL_IS_ATOM(term)) {
        int isiz = ERL_ATOM_SIZE(term) + slash + 1; /* +1 = NULL */
        INVALID_TERM_IF(isiz > bufsiz);
        MAYBE_SLASH(buf, n, slash);
        n += confd_strncpy(&buf[n], bufsiz - n, ERL_ATOM_PTR(term),
                           ERL_ATOM_SIZE(term));
        return n;
    }

    if (IS_INTEGER_OR_UNSIGNED_INTEGER(term)) {
        char *s;
        INVALID_TERM_IF(bufsiz < 2 + slash);
        MAYBE_SLASH(buf, n, slash);
        if ((s = confd_hash2str(ERL_INT_UVALUE(term))) != NULL) {
            n += confd_snprintf(&buf[n], bufsiz - n, "%s", s);
        } else {
            n += confd_snprintf(&buf[n], bufsiz - n, "<%u>",
                                ERL_INT_UVALUE(term));
        }
        INVALID_TERM_IF(n >= bufsiz);
        return n;
    }

    if (ERL_IS_TUPLE(term)) {
        int tmp;
        INVALID_TERM_IF(bufsiz < 3);
        buf[n++] = '{';
        if ((tmp = format_path_keys(term, &buf[n], bufsiz - n)) == CONFD_ERR) {
            return CONFD_ERR;
        }
        n += tmp;
        INVALID_TERM_IF(bufsiz - n < 2);
        buf[n++] = '}';
        buf[n] = 0;
        return n;
    }

    return confd_internal_error("Unexpected term to format_path()\n");
}

char *format_path(int isrel, const ETERM *path)
{
    static char buf[BUFSIZ]; /* FIXME not thread safe */
    int n = 0;
    int tmp;
    int slash = 0;
    ETERM *hd;

    buf[0] = 0;
    if (!isrel)
        buf[n++] = '/';
    if (path == NULL) return "";
    if (! ERL_IS_LIST(path)) return "";
    while (! ERL_IS_EMPTY_LIST(path)) {
         hd = ERL_CONS_HEAD(path);
         if ((tmp = format_path_term(hd, slash, &buf[n], sizeof(buf) - n)) ==
             CONFD_ERR) {
             return NULL;
         }
         path = ERL_CONS_TAIL(path);
         slash = 1;
         n += tmp;
    }
    return &buf[0];
}

#if 0 /* not needed w new parse_path() - remove later */
static char *tok(const char **s)
{
    int n = 0;
    char buf[BUFSIZ];
    const char *ptr = *s;
    if (*ptr == '}')
        return NULL;
    while (1) {
        if (*ptr == ' ') {
            while (*ptr == ' ')
                ptr++;
            *s = ptr;
            buf[n] = 0;
            return strdup(buf);
        }
        else if (*ptr == '"') {
            buf[n++] = *ptr++;
            while (*ptr != '"') {
                if (*ptr == '\\')
                    buf[n++] = *ptr++;
                if (*ptr == '\0') {
                    *s = ptr;
                    return NULL;
                }
                buf[n++] = *ptr++;
            }
            buf[n++] = *ptr++;
        }
        else if (*ptr == '}') {
            buf[n] = 0;
            *s = ptr;
            return strdup(buf);
        }
        else if (*ptr == '\0') {
            *s = ptr;
            return NULL;
        }
        else {
            buf[n++] = *ptr++;
        }
    }
}
#endif

static int get_leaf_list_type(struct confd_cs_node *node,
                              struct confd_type **type_ret)
{
    *type_ret = NULL;

    if (! (node->info.flags & CS_NODE_IS_LEAF_LIST)) {
        return CONFD_ERR_PROTOUSAGE;
    }

    struct confd_type *type;
    for (type = node->info.type; type != NULL; type = type->parent) {
        if (type->validate == confd_list_validate) {
            struct confd_type_list *l = type->opaque;
            *type_ret = l->type;
            return CONFD_OK;
        }
    }
    return CONFD_ERR_UNAVAILABLE;
}

struct confd_type *confd_get_leaf_list_type(struct confd_cs_node *node)
{
    int err;
    struct confd_type *type;

    err = get_leaf_list_type(node, &type);
    if (err == CONFD_ERR_UNAVAILABLE) {
        ret_err(CONFD_ERR_UNAVAILABLE, "Type information not loaded");
    } else if (err == CONFD_ERR_PROTOUSAGE) {
        ret_err(CONFD_ERR_PROTOUSAGE, "Not a leaf-list");
    } else if (err != CONFD_OK) {
        ret_err(err, "Unknown error");
    }
    return type;
}

int pp_keyval(char *buf, int n, const confd_value_t *v, int ns)
{
    char *s;
    int len;
    int nquot, nesc, qlen;
    int i, j;

    switch (v->type) {
    case C_STR:
        s = v->val.s;
        len = strlen(s);
        break;
    case C_BUF:
        s = (char *)CONFD_GET_BUFPTR(v);
        len = CONFD_GET_BUFSIZE(v);
        break;
    default:
        return confd_pp_value(buf, n, v);
    }

    /* need quoting if it's a null string, or if there are
       spaces, right-braces, quotes, or backslashes - if quoting,
       need to backslash-escape quotes and backslashes */
    if (len == 0) {
        qlen = 2;
    } else {
        for (i = 0, nquot = 0, nesc = 0; i < len; i++) {
            switch (s[i]) {
            case ' ': case '}': case '\t': case '\r':
            case '\n': case '\f': case '\v': case '\b':
                nquot++; break;
            case '"': case '\\':
                nesc++; break;
            }
        }
        if (nquot + nesc == 0)
            qlen = len;
        else
            qlen = len + 2 + nesc;
    }
    if (qlen == len) {
        confd_strncpy(buf, n, s, len);
        return len;
    }
    i = j = 0;
    if (j < n - 1)
        buf[j++] = '"';
    while (i < len && j < n - 1) {
        if (s[i] == '"' || s[i] == '\\')
            buf[j++] = '\\';
        if (j < n - 1)
            buf[j++] = s[i++];
    }
    if (j < n - 1)
        buf[j++] = '"';
    if (j < n)
        buf[j] = '\0';
    return qlen;
}


static int format_ip4(char *buf, int dstsz, struct in_addr *ip)
{
    char tmp[INET_ADDRSTRLEN];
    memset(tmp, 0, INET_ADDRSTRLEN);
    inet_ntop(AF_INET, ip, &tmp[0], INET_ADDRSTRLEN);
    return confd_snprintf(buf, dstsz, "%s", tmp);
}


static int format_ip6(char *buf, int dstsz, struct in6_addr *ip)
{
    char dst[INET6_ADDRSTRLEN];
    inet_ntop(AF_INET6, ip, &dst[0], INET6_ADDRSTRLEN);
    return confd_snprintf(buf, dstsz, "%s", dst);
}

static int format_x(char *buf, int dstsz, confd_value_t *vv, int inbraces)
{
    if (inbraces)
        return pp_keyval(buf, dstsz, vv, 0);
    else
        return confd_pp_value(buf, dstsz, vv);
}


#define W() do {                               \
        if (wmode) {*dst++ = *src++; dstsz--;} \
        else {src++; dst++; dstsz--;}          \
    } while (0)

int substitute_percent(const char *src, char *dst, int dstsz, va_list args,
                       int skip_keys)
{
    int wmode = 1;   /* are we writing */
    int n;
    int inbracks = 0;
    int inbraces = 0;
    char *orig_dst = dst;
    while (1) {
        char c = *src;
        if (dstsz <= 1) {
            wmode = 0;
            if (dstsz == 1) {
                *dst = 0; /* add final 0 before bailing out */
            }
        }
        switch (c) {
        case '[':
            inbracks = 1;
            W();
            break;
        case ']':
            inbracks = 0;
            W();
            break;
        case '{':
            inbraces = 1;
            W();
            break;
        case '}':
            inbraces = 0;
            W();
            break;
        case 0:
            *dst = 0;
            return (dst - orig_dst);
        case '%':
            if (inbracks && *(src+1) == 'd') {
                int i = va_arg(args, int);
                src += 2;
                inbracks = 0;
                if (!skip_keys) {
                    n = confd_snprintf(dst, dstsz, "%d", i);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (inbracks) {
                return 0;
            }
            else if (*(src+1) == 's') {
                char *s = va_arg(args, char*);
                src += 2;
                if (!skip_keys || !inbraces) {
                    n = confd_snprintf(dst, dstsz, "%s", s);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (*(src+1) == 'd') {
                int i = va_arg(args, int);
                src += 2;
                if (!skip_keys || !inbraces) {
                    n = confd_snprintf(dst, dstsz, "%d", i);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (*(src+1) == 'u') {
                n = confd_snprintf(dst, dstsz, "%u", va_arg(args,unsigned int));
                dst += n;
                src += 2;
                dstsz -= n;
            }
            else if (*(src+1) == 'x') {
                confd_value_t *v = va_arg(args, confd_value_t*);
                src += 2;
                if (!skip_keys || !inbraces) {
                    n = format_x(dst, dstsz, v, inbraces);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (*(src+1) == '*' && *(src+2) == 'x') {
                int i, nvals = va_arg(args, int);
                confd_value_t *v = va_arg(args, confd_value_t*);
                src += 3;
                if (!skip_keys || !inbraces) {
                    for (i = 0; i < nvals; i++) {
                        if (i > 0) {
                            n = confd_snprintf(dst, dstsz, " ");
                            dst += n;
                            dstsz -= n;
                        }
                        n = format_x(dst, dstsz, v, inbraces);
                        dst += n;
                        dstsz -= n;
                    }
                }
            }
            else if (dst == orig_dst && *(src+1) == 'h') {
                confd_hkeypath_t *kp = va_arg(args, confd_hkeypath_t*);
                src += 2;
                if (!skip_keys || !inbraces) {
                    n = confd_pp_kpath(dst, dstsz, kp);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (dst == orig_dst && *(src+1) == '*' && *(src+2) == 'h') {
                int len = va_arg(args, int);
                confd_hkeypath_t *kp = va_arg(args, confd_hkeypath_t*);
                src += 3;
                if (!skip_keys || !inbraces) {
                    n = confd_pp_kpath_len(dst, dstsz, kp, len);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (strncmp(src, "%ip4", 4) == 0) {
                struct in_addr *ip = va_arg(args, struct in_addr*);
                src += 4;
                if (!skip_keys || !inbraces) {
                    n = format_ip4(dst, dstsz, ip);
                    dst += n;
                    dstsz -= n;
                }
            }
            else if (strncmp(src, "%ip6", 4) == 0) {
                struct in6_addr *ip6 = va_arg(args, struct in6_addr*);
                src += 4;
                if (!skip_keys || !inbraces) {
                    n = format_ip6(dst, dstsz, ip6);
                    dst += n;
                    dstsz -= n;
                }
            }
            else {
                W();
            }
            break;
        default:
            W();
        }
    }
}

#undef W


static ETERM *mk_tag_elem(ETERM *ns, const char *tagstr, int taglen)
{
    ETERM *tag;

    tag = erl_mk_eatom(tagstr, taglen);
    if (ns == NULL)
        return tag;
    return erl_cons(ns, tag);
}

ETERM *mk_tag_elem2(const char *tagstr)
{
    char *p = strchr(tagstr, ':');
    ETERM *ns, *tag;

    if (p != NULL) {
        ns =  erl_mk_eatom(tagstr, p - tagstr);
        tag = erl_mk_atom(++p);
        return erl_cons(ns, tag);
    } else {
        tag = erl_mk_atom(tagstr);
        return tag;
    }
}

ETERM *mk_str_key(char *beg, char *end)
{
    char *bp = beg;
    char *ep = end;

    while (bp < end && isspace(*bp)) bp++;
    while (ep > bp && isspace(*(ep-1))) ep--;
    if (bp == ep)
        return NULL;
    return erl_mk_binary(bp, ep-bp);
}

static int hkeypath_to_eterm_arr(confd_hkeypath_t *hkp, ETERM **arr,
                                 int len, int reverse);

ETERM *parse_path(int *isrel, const char *fmt, va_list args)
{
    int n;
    int rel = -1;
    ETERM *result[256];
    int nelem = 0;
    ETERM *keytup[MAXKEYLEN+2];
    int nkeys = 0;
    const char *fp = fmt;
    char dst[BUFSIZ];
    char *dp = dst;
    int dstsz = sizeof(dst);
    char *s = dst;
    char *beg = dst;
    ETERM *ns = NULL;
    char *lbrack = NULL;
    char *keybeg = NULL;
    int got_key = 0;
    int in_quote = 0;
    confd_value_t *vp;
    confd_hkeypath_t *kp;

    if ((fp == NULL) || (*fp == '\000')) {
        *isrel = 1;
        result[0] = erl_mk_atom(".");
        return erl_mk_list(result, 1);
    }

    while (isspace(*fp)) fp++;

    while (*fp != '\0') {

        /* expand % substition or copy one char from fmt */

        if (*fp == '%') {

            if (*(fp+1) == 'd') {
                fp += 2;
                n = confd_snprintf(dp, dstsz, "%d", va_arg(args, int));
                dp += n;
                dstsz -= n;
            }
            else if (*(fp+1) == 'u') {
                fp += 2;
                n = confd_snprintf(dp, dstsz, "%u", va_arg(args, unsigned int));
                dp += n;
                dstsz -= n;
            }
            else if (*(fp+1) == 's') {
                fp += 2;
                n = confd_snprintf(dp, dstsz, "%s", va_arg(args, char *));
                dp += n;
                dstsz -= n;
            }
            else if (strncmp(fp, "%ip4", 4) == 0) {
                fp += 4;
                n = format_ip4(dp, dstsz, va_arg(args, struct in_addr *));
                dp += n;
                dstsz -= n;
            }
            else if (strncmp(fp, "%ip6", 4) == 0) {
                fp += 4;
                n = format_ip6(dp, dstsz, va_arg(args, struct in6_addr *));
                dp += n;
                dstsz -= n;
            }
            else if (*(fp+1) == 'x' || strncmp(fp, "%*x", 3) == 0) {
                int nxkeys, i;
                if (*(fp+1) == 'x') {
                    fp += 2;
                    nxkeys = 1;
                } else {
                    fp += 3;
                    nxkeys = va_arg(args, int);
                }
                vp = va_arg(args, confd_value_t *);
                for (i = 0; i < nxkeys; i++, vp++) {
                    /* string type keys must always be sent in string form */
                    if (keybeg != NULL &&
                        vp->type != C_BUF && vp->type != C_STR) {
                        /* add string-form key(s) to tuple before value-key */
                        if ((keytup[nkeys] = mk_str_key(keybeg+1, dp)) != NULL)
                            nkeys++;
                        keybeg = dp - 1;
                        if ((keytup[nkeys] = val_to_term(vp)) == NULL)
                            goto badret;
                        nkeys++;
                        if (nkeys >= MAXKEYLEN)
                            goto badret;
                    } else {
                        if (i > 0) {
                            n = confd_snprintf(dp, dstsz, " ");
                            dp += n;
                            dstsz -= n;
                        }
                        n = format_x(dp, dstsz, vp, keybeg != NULL);
                        dp += n;
                        dstsz -= n;
                    }
                }
            }
            else if (dp == dst && *(fp+1) == 'h') {
                fp += 2;
                rel = 0;
                kp = va_arg(args, confd_hkeypath_t *);
                if (hkeypath_to_eterm_arr(kp, &result[nelem], kp->len, 1) !=
                    kp->len)
                    goto badret;
                nelem += kp->len;
                if (ERL_IS_TUPLE(result[nelem-1]))
                    got_key = 2;
            }
            else if (dp == dst && strncmp(fp, "%*h", 3) == 0) {
                int kp_len = va_arg(args, int);
                fp += 3;
                rel = 0;
                kp = va_arg(args, confd_hkeypath_t *);
                if (hkeypath_to_eterm_arr(kp, &result[nelem], kp_len, 1) !=
                    kp_len)
                    goto badret;
                nelem += kp_len;
                if (ERL_IS_TUPLE(result[nelem-1]))
                    got_key = 2;
            }
            else {
                *dp++ = *fp++;
                dstsz--;
            }

        } else {

            *dp++ = *fp++;
            dstsz--;

        }

        if (dstsz <= 0)
            goto badret;

        if (rel == -1) {
            if (*s == '/') {
                rel = 0;
                s++;
                beg = s;
            } else {
                rel = 1;
            }
        }

        /* parse the result produced so far */

        while (s < dp) {

            if (got_key == 2) {
                /* slash after [N] or {key(s)} is (required and) consumed */
                if (*s != '/')
                    goto badret;
                got_key = 1;
                s++;
                beg = s;
                continue;
            }
            else if (lbrack != NULL) {
                /* collecting [N] */
                if (*s == ']') {
                    char *p;
                    char ibuf[64];
                    int ibufsz = 0;
                    ETERM *dlist[1];

                    p = lbrack + 1;
                    while (isspace(*p)) p++;
                    if (!isdigit(*p))
                        goto badret;

                    while (isdigit(*p)) {
                        if (ibufsz >= sizeof(ibuf) - 1)
                            goto badret;
                        ibuf[ibufsz++] = *p++;
                    }
                    ibuf[ibufsz] = 0;
                    dlist[0] = erl_mk_int(atoi(ibuf));
                    result[nelem++] = erl_mk_list(dlist, 1);
                    while (p < s) {
                        if (!isspace(*p))
                            goto badret;
                        p++;
                    }
                    lbrack = NULL;
                    got_key = 2;
                }
                s++;
                continue;
            }
            else if (keybeg != NULL) {
                /* collecting {key(s)} */
                switch (in_quote) {
                case 0:       /* no quote - look for '}' or double quote */
                    switch (*s) {
                    case '}':
                        if ((keytup[nkeys] = mk_str_key(keybeg+1, s)) != NULL)
                            nkeys++;
                        if (nkeys >= MAXKEYLEN)
                            goto badret;
                        keybeg = NULL;
                        if (nkeys == 0) /* no keys */
                            goto badret;
                        result[nelem++] = erl_mk_tuple(keytup, nkeys);
                        nkeys = 0;
                        got_key = 2;
                        break;
                    case '"':
                        in_quote = 1;
                        break;
                    }
                    break;
                case 1:       /* in double quote - look for end or backslash */
                    switch (*s) {
                    case '"':
                        in_quote = 0;
                        break;
                    case '\\':
                        in_quote = 2;
                        break;
                    }
                    break;
                case 2:       /* in backslash quote - don't look */
                    in_quote = 1;
                    break;
                }
                s++;
                continue;
            }
            else {
                /* parsing elems */
                switch (*s) {
                case ':':
                    if (beg != NULL) {
                        if (s == beg) /* empty prefix */
                            goto badret;
                        ns = erl_mk_eatom(beg, s - beg);
                    }
                    beg = s + 1;
                    break;
                case '/':
                    if (beg != NULL) {
                        if (s == beg && ns != NULL) /* prefix w/o elem */
                            goto badret;
                        if (s > beg)
                            result[nelem++] = mk_tag_elem(ns, beg, s - beg);
                    }
                    ns = NULL;
                    beg = s + 1;
                    break;
                case '[':
                    if (got_key)
                        goto badret;
                    if (beg != NULL) {
                        if (s == beg && ns != NULL) /* prefix w/o elem */
                            goto badret;
                        if (s > beg)
                            result[nelem++] = mk_tag_elem(ns, beg, s - beg);
                    }
                    ns = NULL;
                    beg = NULL;
                    lbrack = s;
                    break;
                case '{':
                    if (got_key)
                        goto badret;
                    if (beg != NULL) {
                        if (s == beg && ns != NULL) /* prefix w/o elem */
                            goto badret;
                        if (s > beg)
                            result[nelem++] = mk_tag_elem(ns, beg, s - beg);
                    }
                    ns = NULL;
                    beg = NULL;
                    keybeg = s;
                    break;
                }
                got_key = 0;
                s++;
                continue;
            }

        }

    }

    if (lbrack != NULL || keybeg != NULL) /* premature end */
        goto badret;

    if (beg != NULL && s - beg > 0) {
        result[nelem++] = mk_tag_elem(ns, beg, s - beg);
    } else if (ns != NULL) {
        /* trailing prefix - formally an error, but ignore for now
           must be freed since it isn't included in the path though */
        erl_free_compound(ns);
    }
    *isrel = rel;
    return erl_mk_list(result, nelem);

  badret:
    for (nkeys--; nkeys >= 0; nkeys--) {
        if (keytup[nkeys] != NULL)
            erl_free_compound(keytup[nkeys]);
    }
    if (ns != NULL)
        erl_free_compound(ns);
    for (nelem--; nelem >= 0; nelem--)
        erl_free_compound(result[nelem]);
    confd_set_errno(CONFD_ERR_BADPATH);
    return NULL;
}

ETERM *_confd_parse_choice_path(const char *path)
{
    const char *p = path, *q, *r;
    ETERM *list[256], *ns, *res;
    int i = 0;

    if (*p == '/') {
        ret_err(CONFD_ERR_BADPATH, "Choice path cannot start with '/'");
        return NULL;
    }
    do {
        if ((q = strchr(p, '/')) == NULL)
            q = strchr(p, '\0');
        if ((r = strchr(p, ':')) != NULL && r < q) {
            if ((ns = erl_mk_eatom(p, r - p)) == NULL)
                goto bad;
            p = r + 1;
        } else {
            ns = NULL;
        }
        if ((list[i] = mk_tag_elem(ns, p, q - p)) == NULL)
            goto bad;
        i++;
        p = q + 1;
    } while (i < 256 && *q != '\0');
    if ((res = erl_mk_list(list, i)) == NULL)
        goto bad;
    return res;

  bad:
    while (i > 0) {
        erl_free_compound(list[i]);
        i--;
    }
    ret_err(CONFD_ERR_MALLOC, "Cannot allocate");
    return NULL;
}

/* FIXME merge with pp_keyval to avoid code duplication */
int keyval2str(struct confd_type *type, const confd_value_t *v,
               char *buf, int n)
{
    int len = CONFD_ERR;
    char *s = buf;
    struct confd_type_ctx ctx = {NULL, 0, NULL};
    int nquot, nesc, qlen;
    int i, j;

    /* Don't try to convert C_BUF or C_STR values, causes bogus error with
       STRINGSONLY - return CONFD_ERR to make caller fall back to pp_keyval() */
    /* Use type->val_to_str() directly to avoid error msg from confd_val2str()
       if schema not loaded or user-defined type not registered */
    if (v->type != C_BUF && v->type != C_STR)
        len = type->val_to_str(type, &ctx, v, buf, n < 0 ? 0 : n, NULL);
    if (len < 0)
        return len;

    {
        char tmpbuf[len+1];

        if (len >= n) {
            /* need the full string to determine quoted length */
            confd_val2str(type, v, tmpbuf, sizeof(tmpbuf));
            s = tmpbuf;
        }

        /* need quoting if it's a null string, or if there is
           whitespace, right-braces, quotes, or backslashes - if quoting,
           need to backslash-escape quotes and backslashes */
        if (len == 0) {
            qlen = 2;
        } else {
            for (i = 0, nquot = 0, nesc = 0; i < len; i++) {
                switch (s[i]) {
                case ' ': case '}': case '\t': case '\r':
                case '\n': case '\f': case '\v': case '\b':
                    nquot++; break;
                case '"': case '\\':
                    nesc++; break;
                }
            }
            if (nquot + nesc == 0)
                qlen = len;
            else
                qlen = len + 2 + nesc;
        }
        /* normal case */
        if (qlen == len)
            return len;

        if (s != tmpbuf) {
            /* need a copy since we will write to buf */
            memcpy(tmpbuf, buf, len);
        }
        i = j = 0;
        if (j < n - 1)
            buf[j++] = '"';
        while (i < len && j < n - 1) {
            if (tmpbuf[i] == '"' || tmpbuf[i] == '\\')
                buf[j++] = '\\';
            if (j < n - 1)
                buf[j++] = tmpbuf[i++];
        }
        if (j < n - 1)
            buf[j++] = '"';
        if (j < n)
            buf[j] = '\0';
    }

    return qlen;
}

/* pretty-print the initial 'len' elements of a hkeypath to buf */
/* returns int as snprinf() */
int confd_pp_kpath_len(char *buf, int n, const confd_hkeypath_t *hkeypath,
                       int kp_len)
{
    int tmplen = 0;
    int pos;
    int ns = -1;
    int len = 0;
    const confd_value_t *v;

    if (n < 0)
        n = 0;

    if (kp_len == 0)
        return confd_snprintf(buf, n, "/");

    /* Find the ns for the hkeypath */
    for (pos=hkeypath->len-1 ; pos >= 0 ; pos--) {
        v = &(hkeypath->v[pos][0]);
        if (v->type == C_XMLTAG && v->val.xmltag.ns != 0 ) {
            ns = v->val.xmltag.ns;
            break;
        }
    }

    for (pos=hkeypath->len-1; pos >= hkeypath->len - kp_len ; pos--) {
        const confd_value_t *v = &(hkeypath->v[pos][0]);
        if (v->type == C_XMLTAG) {
            if (v->val.xmltag.ns != 0 && v->val.xmltag.ns != ns)
                ns = v->val.xmltag.ns;
            tmplen = confd_snprintf(buf, n, "/");
            len += tmplen;
            buf += tmplen;
            n -= tmplen;
            tmplen = confd_pp_value(buf, n, v);
            len += tmplen;
            buf += tmplen;
            n -= tmplen;
        }
        else if (v->type == C_NOEXISTS) {
            /* empty key value (for chk_data_access() callback) */
            tmplen = confd_snprintf(buf, n, "{}");
            len += tmplen;
            buf += tmplen;
            n -= tmplen;
        }
        else {
            /* it's a key value */
            int i = 0;
            struct confd_cs_node *node;
            struct confd_cs_node *key = NULL;

            tmplen = confd_snprintf(buf, n, "{");
            len += tmplen;
            buf += tmplen;
            n -= tmplen;
            node = confd_find_cs_node(hkeypath, hkeypath->len - pos);

            if (node != NULL && node->info.keys != NULL)
                key = node->children;
            while (1) {
                tmplen = -1;
                if (key != NULL) {
                    if (key->info.type != NULL) {
                        tmplen = keyval2str(key->info.type, v, buf, n);
                    }
                    key = key->next;
                } else if (node != NULL &&
                           node->info.flags & CS_NODE_IS_LEAF_LIST) {
                    struct confd_type *type;
                    get_leaf_list_type(node, &type);
                    if (type != NULL) {
                        tmplen = keyval2str(type, v, buf, n);
                    }
                }

                /* fall back to non-schema-aware method */
                if (tmplen < 0) {
                    tmplen = pp_keyval(buf, n, v, ns);
                }

                len += tmplen;
                buf += tmplen;
                n -= tmplen;

                v = &(hkeypath->v[pos][++i]);
                if (v->type == C_NOEXISTS)
                    break;
                tmplen = confd_snprintf(buf, n, " ");
                len += tmplen;
                buf += tmplen;
                n -= tmplen;

            }
            tmplen = confd_snprintf(buf, n, "}");
            len += tmplen;
            buf += tmplen;
            n -= tmplen;
        }
    }
    return len;
}

static int xpath_keyval2str(struct confd_type *type, const confd_value_t *v,
                            char *buf, int n)
{
    int len, tmplen;
    char *s, *start_q = n > 0 ? buf : NULL;

    /* start quote, replace with ' if value contains " */
    confd_snprintf(buf, n, "\"");
    buf += 1; n -= 1;

    if (v->type == C_STR) {
        s = v->val.s;
        len = strlen(s);
        confd_strncpy(buf, n, v->val.s, len);
    } else if (v->type == C_BUF) {
        s = (char *)CONFD_GET_BUFPTR(v);
        len = CONFD_GET_BUFSIZE(v);
        confd_strncpy(buf, n, s, len);
    } else {
        s = buf;
        struct confd_type_ctx ctx = {NULL, 0, NULL};
        if (type == NULL) {
            /* fall back to non-schema-aware method */
            len = confd_pp_value(buf, n, v);
        } else {
            len = type->val_to_str(type, &ctx, v, buf, n < 0 ? 0 : n, NULL);
            if (len < 0) {
                /* fall back to non-schema-aware method */
                len = confd_pp_value(buf, n, v);
            }
        }
    }
    tmplen = n > len ? len : n;
    buf += len; n -= len;

    if (tmplen < 0 || memchr(s, '"', tmplen) == NULL) {
        confd_snprintf(buf, n, "\"");
    } else {
        if (start_q != NULL) {
            *start_q = '\'';
        }
        confd_snprintf(buf, n, "'");
    }

    return len + 2;
}

/* returns int as snprinf() */
int confd_xpath_pp_kpath(char *obuf, int n, u_int32_t ns,
                         const confd_hkeypath_t *hkeypath)
{
    char *buf = obuf;
    int tmplen = 0;
    int pos;
    int newns, oldns = 0;
    char *prefix;
    int j = 1;

    if (n < 0)
        n = 0;

    /* Find the ns for the hkeypath if not given */
    if (ns == 0) {
        const confd_value_t *v;
        for (pos=hkeypath->len-1; pos >= 0 && n > 0; pos--) {
            v = &(hkeypath->v[pos][0]);
            if (v->type == C_XMLTAG && v->val.xmltag.ns != 0 ) {
                ns = v->val.xmltag.ns;
                break;
            }
        }
    }

    /* traverse the keypath backwards */
    for (pos=hkeypath->len-1; pos >= 0; pos--, j++) {
        const confd_value_t *v = &(hkeypath->v[pos][0]);
        if (v->type == C_XMLTAG) {
            /* print ns prefix if (possibly) needed */
            if ((newns = CONFD_GET_XMLTAG_NS(v)) != 0) {
                if (newns != oldns && (prefix = confd_ns2prefix(newns)) != NULL)
                    tmplen = confd_snprintf(buf, n, "/%s:", prefix);
                else
                    tmplen = confd_snprintf(buf, n, "/");
                ns = oldns = newns;
            } else {
                tmplen = confd_snprintf(buf, n, "/");
            }
            buf += tmplen; n -= tmplen;
            tmplen = confd_pp_value(buf, n, v);
            buf += tmplen; n -= tmplen;
        }
        else if (v->type != C_NOEXISTS) { /* skip empty key elem */
            /* it's maybe a key value, we need to figure out the */
            /* name of the xml elem */
            int i = 0;
            uint32_t *keys;
            struct confd_cs_node *p;
            struct confd_cs_node *key = NULL;

            if ((p = confd_find_cs_node(hkeypath, j)) == NULL) {
                /* No such namespace schema loaded" */
                tmplen = confd_snprintf(buf, n, "[NONAMESPACELOADED]");
                buf += tmplen; n -= tmplen;
                continue;
            }

            tmplen = confd_snprintf(buf, n,
                                    (p->info.flags & CS_NODE_IS_LEAF_LIST)
                                    ? "[.=" : "[");
            buf += tmplen; n -= tmplen;

            keys = p->info.keys;
            if (keys == NULL) {
                if (p->info.flags & CS_NODE_IS_LEAF_LIST) {
                    struct confd_type *type;
                    get_leaf_list_type(p, &type);
                    tmplen = xpath_keyval2str(type, v, buf, n);
                } else {
                    /* assume keyless oper list (should have C_INT64 key) */
                    tmplen = confd_pp_value(buf, n, v);
                }
                buf += tmplen; n -= tmplen;
            } else {
                key = p->children;
                while (1) {
                    struct confd_type *type =
                        key == NULL ? NULL : key->info.type;
                    char *elemname = confd_hash2str(*keys++);
                    tmplen = confd_snprintf(buf, n, "%s=", elemname);
                    buf += tmplen; n -= tmplen;
                    tmplen = xpath_keyval2str(type, v, buf, n);
                    buf += tmplen; n -= tmplen;
                    if (key != NULL)
                        key = key->next;
                    v = &(hkeypath->v[pos][++i]);
                    if (v->type == C_NOEXISTS)
                        break;
                    tmplen = confd_snprintf(buf, n, "][");
                    buf += tmplen; n -= tmplen;
                }
            }

            tmplen = confd_snprintf(buf, n, "]");
            buf += tmplen; n -= tmplen;
        }
    }
    return (buf - obuf);
}


#define W() do {                             \
        if (wmode) {*dp++ = *fp++; dstsz--;} \
        else {dp++; fp++; dstsz--;}          \
    } while (0)

#define CD() do {                                                       \
        if (beg != NULL && s > beg && (*beg == '/' || node != NULL)) {  \
            char c = *s;                                                \
            *s = '\0';                                                  \
            node = confd_cs_node_cd(node, beg);                         \
            *s = c;                                                     \
        }                                                               \
    } while (0)

/* like substitute_percent, but do proper val2str() on keys if possible */
int confd_vformat_keypath(char *buf, int bufsiz, const char *fmt, va_list args)
{
    int wmode = 1;   /* are we writing */
    int n;
    const char *fp = fmt;
    char *dp = buf;
    int dstsz = bufsiz;
    char *s = buf;
    char *beg = buf;
    char *lbrack = NULL;
    char *keybeg = NULL;
    int in_key = 0;
    int in_quote = 0;
    confd_value_t *vp;
    confd_hkeypath_t *kp;
    struct confd_cs_node *node = NULL, *key = NULL;

    if ((fp == NULL) || (*fp == '\0')) {
        if (dstsz > 0) {
            *dp = '\0';
        }
        return 0;
    }

    while (*fp != '\0') {

        if (dstsz <= 1) {
            wmode = 0;
            if (dstsz == 1) {
                *dp = '\0'; /* add final '\0' before bailing out */
            }
        }

        /* expand % substition or copy one char from fmt */

        if (*fp == '%') {

            if (*(fp+1) == 'd') {
                fp += 2;
                n = confd_snprintf(dp, dstsz, "%d", va_arg(args, int));
                dp += n;
                dstsz -= n;
            }
            else if (*(fp+1) == 'u') {
                fp += 2;
                n = confd_snprintf(dp, dstsz, "%u", va_arg(args, unsigned int));
                dp += n;
                dstsz -= n;
            }
            else if (*(fp+1) == 's') {
                fp += 2;
                n = confd_snprintf(dp, dstsz, "%s", va_arg(args, char *));
                dp += n;
                dstsz -= n;
            }
            else if (strncmp(fp, "%ip4", 4) == 0) {
                fp += 4;
                n = format_ip4(dp, dstsz, va_arg(args, struct in_addr *));
                dp += n;
                dstsz -= n;
            }
            else if (strncmp(fp, "%ip6", 4) == 0) {
                fp += 4;
                n = format_ip6(dp, dstsz, va_arg(args, struct in6_addr *));
                dp += n;
                dstsz -= n;
            }
            else if (*(fp+1) == 'x' || strncmp(fp, "%*x", 3) == 0) {
                int nxkeys, i;
                if (*(fp+1) == 'x') {
                    fp += 2;
                    nxkeys = 1;
                } else {
                    fp += 3;
                    nxkeys = va_arg(args, int);
                }
                vp = va_arg(args, confd_value_t *);
                for (i = 0; i < nxkeys; i++, vp++) {
                    n = -1;
                    if (key != NULL) {
                        if (key->info.type != NULL) {
                            n = keyval2str(key->info.type, vp, dp, dstsz);
                        }
                        key = key->next;
                    } else if (node != NULL &&
                               node->info.flags & CS_NODE_IS_LEAF_LIST) {
                        struct confd_type *type;
                        get_leaf_list_type(node, &type);
                        n = keyval2str(type, vp, dp, dstsz);
                    }

                    /* fall back to non-schema-aware method */
                    if (n < 0) {
                        n = pp_keyval(dp, dstsz, vp, 0);
                    }
                    dp += n;
                    dstsz -= n;
                    if (i < nxkeys - 1) {
                        n = confd_snprintf(dp, dstsz, " ");
                        dp += n;
                        dstsz -= n;
                    }
                }
                in_key = 0;
                s = dp;
            }
            else if (fp == fmt && *(fp+1) == 'h') {
                fp += 2;
                kp = va_arg(args, confd_hkeypath_t *);
                n = confd_pp_kpath(dp, dstsz, kp);
                node = confd_find_cs_node(kp, kp->len);
                dp += n;
                dstsz -= n;
                in_key = 0;
                beg = NULL;
                s = dp;
            }
            else if (fp == fmt && strncmp(fp, "%*h", 3) == 0) {
                int kp_len = va_arg(args, int);
                fp += 3;
                kp = va_arg(args, confd_hkeypath_t *);
                n = confd_pp_kpath_len(dp, dstsz, kp, kp_len);
                node = confd_find_cs_node(kp, kp_len);
                dp += n;
                dstsz -= n;
                in_key = 0;
                beg = NULL;
                s = dp;
            }
            else {
                W();
            }

        } else {

            W();

        }

        if (dstsz <= 0) {
            continue;
        }

        if (s == buf && *s == '/')
            s++;

        /* parse the result produced so far */

        while (s < dp) {

            if (lbrack != NULL) {
                /* collecting [N] */
                if (*s == ']') {
                    lbrack = NULL;
                }
                s++;
                continue;
            }
            else if (keybeg != NULL) {
                /* collecting {key(s)} */
                switch (in_quote) {
                case 0:         /* no quote - look for anything */
                    switch (*s) {
                    case ' ':
                        if (in_key && key != NULL) {
                            key = key->next;
                        }
                        in_key = 0;
                        break;
                    case '}':
                        keybeg = NULL;
                        key = NULL;
                        in_key = 0;
                        break;
                    case '"':
                        in_key = 1;
                        in_quote = 1;
                        break;
                    default:
                        in_key = 1;
                        break;
                    }
                    break;
                case 1:       /* in double quote - look for end or backslash */
                    switch (*s) {
                    case '"':
                        in_quote = 0;
                        break;
                    case '\\':
                        in_quote = 2;
                        break;
                    }
                    break;
                case 2:       /* in backslash quote - don't look */
                    in_quote = 1;
                    break;
                }
                s++;
                continue;
            }
            else {
                /* parsing elems */
                switch (*s) {
                case '/':
                    if (beg != NULL && s - beg == 1 && *beg == '/') {
                        /* repeated leading '/' */
                        beg = s;
                    } else {
                        CD();
                        beg = s + 1;
                    }
                    break;
                case '[':
                    CD();
                    beg = NULL;
                    lbrack = s;
                    break;
                case '{':
                    CD();
                    beg = NULL;
                    keybeg = s;
                    if (node != NULL && node->info.keys != NULL) {
                        key = node->children;
                    }
                    break;
                }
                s++;
                continue;
            }

        }

    }

    if (dstsz > 0) {
        *dp = '\0';
    }
    return dp - buf;

}

#undef W
#undef CD



static void cdb_trace(int isrel, int op, const ETERM *arg) {
    if (confd_debug_level >= CONFD_TRACE) {
        const ETERM *path = NULL;
        char *argstr = NULL;
        switch (op) {

            /* path in tuple elem 0 */
        case MAAPI_MOVE:
        case MAAPI_MOVE_ORDERED:
        case MAAPI_CLEAR_OPCACHE:
        case CDB_OP_GET_OBJECTS:
            path = TE(arg,0);
            break;

            /* path in tuple elem 1 */
        case MAAPI_GET_NEXT:
        case MAAPI_SET_ELEM:
        case MAAPI_SET_ELEM2:
        case MAAPI_GET_CASE:
        case MAAPI_SET_OBJECT:
        case MAAPI_GET_ATTRS:
        case MAAPI_SET_ATTR:
        case MAAPI_REQUEST_ACTION:
        case MAAPI_REQUEST_ACTION_TH:
        case MAAPI_AAA_RELOAD_PATH:
        case MAAPI_COPY_PATH:
        case CDB_OP_SET_ELEM:
        case CDB_OP_SET_ELEM2:
        case CDB_OP_SET_OBJECT:
        case CDB_OP_SET_VALUES:
        case CDB_OP_GET_VALUES:
        case CDB_OP_OPER_SUBSCRIBE:
        case CDB_OP_GET_CASE:
        case CDB_OP_SET_CASE:
            path = TE(arg,1);
            break;

            /* path in tuple elem 2 */
        case CDB_OP_SUBSCRIBE:
            path = TE(arg,2);
            break;

            /* no path but list arg */
        case MAAPI_START_USER_SESSION:
        case CDB_OP_TRIGGER_SUBS:
            path = NULL;
            break;

        case CDB_OP_SYNC_SUB:
            switch (ERL_IS_TUPLE(arg) ?
                    ERL_INT_VALUE(ERL_TUPLE_ELEMENT(arg,0)) :
                    ERL_INT_VALUE(arg)) {
            case CDB_DONE_PRIORITY: argstr = "CDB_DONE_PRIORITY"; break;
            case CDB_DONE_SOCKET: argstr = "CDB_DONE_SOCKET"; break;
            case CDB_DONE_TRANSACTION: argstr = "CDB_DONE_TRANSACTION"; break;
            case CDB_DONE_OPERATIONAL: argstr = "CDB_DONE_OPERATIONAL"; break;
            case 5: argstr = "CDB_ABORT"; break;
            default: argstr = "?"; break;
            }
            break;

        default:
            if (arg != NULL && !ERL_IS_LIST(arg))
                /* not a path */
                path = NULL;
            else
                /* arg is a path or NULL */
                path = arg;
        }
        confd_trace_printf("TRACE %s %s", _confd_op2str(op),
                           (path ? format_path(isrel, path) :
                            (argstr ? argstr : "")));
    }
}



ETERM  *op_request_term2(int sock, int op, int thandle, int isrel,
                         const ETERM *arg, int *status, int clr_err)
{
    unsigned int op2 = op;
    ETERM *ret;
    if (clr_err) {
        clr_confd_err();
    }
    if (isrel)
        op2 |= CDB_REL_FLAG_MASK;
    cdb_trace(isrel, op, arg);
    if (arg == NULL) {
        if ((*status = op_write(sock, op2, thandle)) != CONFD_OK) {
            cdb_ret_trace(*status, NULL);
            return NULL;
        }
    }
    else if ((*status = term_write(sock, arg, op2, thandle)) != CONFD_OK) {
        cdb_ret_trace(*status, NULL);
        return NULL;
    }
    ret = term_read(sock, status, op);
    if (ret != NULL && *status == CONFD_ERR) {
         unsigned char *estr = ERL_BIN_PTR(ret);
         cdb_ret_trace(CONFD_ERR, ret);
         confd_report_err(CONFD_DEBUG, "error: %s\n", estr);
         erl_free_compound(ret);
         return NULL;
    }
    cdb_ret_trace(*status, ret);
    return ret;
}

/* Convert initial 'len' elements of a hkeypath to Erlang terms
   in 'arr'. 'format_h' is for use with %h/%*h in CDB/MAAPI paths:
   elements in 'arr' should be in "forward order" and string type
   keys must be converted to string form (to get the right quoting) */
static int hkeypath_to_eterm_arr(confd_hkeypath_t *hkp, ETERM **arr,
                                  int len, int format_h)
{
    int i, j;
    confd_value_t *vptr;
    u_int32_t ns = 0, newns;

    /* traverse the keypath backwards */
    for(i=hkp->len-1; i>=hkp->len-len; i--) {
        j = format_h ? hkp->len - i - 1 : i;
        vptr = &hkp->v[i][0];
        if (vptr->type == C_XMLTAG) {
            newns = CONFD_GET_XMLTAG_NS(vptr);
            if (newns != 0 && newns != ns) {
                ns = newns;
                arr[j] = erl_cons(
                    erl_mk_uint(ns),
                    erl_mk_uint(CONFD_GET_XMLTAG(vptr)));
            } else {
                arr[j] = erl_mk_uint(CONFD_GET_XMLTAG(vptr));
            }
        }
        else { /* its a key */
            int klen = 0;
            while (hkp->v[i][klen].type != C_NOEXISTS)
                klen++;
            {
                ETERM *ktup[klen];
                klen = 0;
                while (hkp->v[i][klen].type != C_NOEXISTS) {
                    confd_value_t *vp = &hkp->v[i][klen];
                    if (format_h && (vp->type == C_BUF || vp->type == C_STR)) {
                        char buf[256], *bp = buf;
                        int sz = pp_keyval(bp, sizeof(buf), vp, ns);
                        if (sz >= sizeof(buf)) {
                            if ((bp = confd_malloc(sz+1)) == NULL)
                                return -1;
                            pp_keyval(bp, sz+1, vp, ns);
                        }
                        ktup[klen] = erl_mk_binary(bp, sz);
                        if (bp != buf)
                            free(bp);
                    } else {
                        if ((ktup[klen] = val_to_term(vp))==NULL)
                            return -1;
                    }
                    klen++;
                }
                arr[j] = erl_mk_tuple(ktup, klen);
            }
        }
    }
    return len;
}

ETERM *hkeypath_to_eterm(confd_hkeypath_t *hkp)
{
    ETERM *hlist[hkp->len];

    if (hkeypath_to_eterm_arr(hkp, hlist, hkp->len, 0) != hkp->len)
        return NULL;
    return erl_mk_list(hlist, hkp->len);
}

/* Internal dup */
int confd_dup_value(confd_value_t *v)
{
    int i, sz=0;
    unsigned char *ptmp;
    switch (v->type) {
    case C_BUF:
    case C_BINARY:
    case C_HEXSTR:
    case C_BITBIG: {
        ptmp = confd_memdup(v->val.buf.ptr, sz = v->val.buf.size + 1);
        if (ptmp == NULL) goto noalloc;
        v->val.buf.ptr = ptmp;
        break;
    }
    case C_QNAME: {
        unsigned char *ntmp = NULL;
        ptmp = NULL;
        if (v->val.qname.prefix.size > 0) {
            ptmp = confd_memdup(v->val.qname.prefix.ptr,
                                sz = v->val.qname.prefix.size+1);
            if (ptmp == NULL) goto noalloc;
        }
        ntmp = confd_memdup(v->val.qname.name.ptr, sz=v->val.qname.name.size+1);
        if (ntmp == NULL) {
            if (ptmp) free(ptmp);
            goto noalloc;
        }
        v->val.qname.prefix.ptr = ptmp;
        v->val.qname.name.ptr = ntmp;
        break;
    }
    case C_LIST: {
        for (i=0; i<v->val.list.size; i++) {
            confd_value_t *vp = &v->val.list.ptr[i];
            if (confd_dup_value(vp) == CONFD_ERR)
                return CONFD_ERR;
        }
        break;
    }
    case C_OBJECTREF: {
        confd_hkeypath_t *hkp = v->val.hkp;  /* already allocated !!*/
        for (i=0; i<hkp->len; i++) {
            int j = 0;
            confd_value_t *vp = &hkp->v[i][j];
            while (vp->type != C_NOEXISTS) {
                if (confd_dup_value(vp) == CONFD_ERR)
                    return CONFD_ERR;
                j++;
                vp = &hkp->v[i][j];
            }
        }
    }
    default:
        break;
    }
    return CONFD_OK;

  noalloc:
    confd_report_err(CONFD_DEBUG,
                     "failed to malloc() %d bytes", sz);
    return CONFD_ERR;
}



void arg_request(int sock, unsigned int op, int thandle, int *status,
                 int isrel, confd_value_t *v, const ETERM *arg)
{

    ETERM *result;
    result = op_request_term(sock, op, thandle, isrel, arg, status);
    if (arg != NULL) {
        erl_free_compound((ETERM*)arg);
    }
    if (result == NULL) {
        return;
    }
    if (eterm_to_val(result, v) == NULL) {
        erl_free_compound(result);
        *status = CONFD_ERR;
        return;
    }
    if (confd_dup_value(v) == CONFD_ERR) {
         erl_free_compound(result);
         *status = CONFD_ERR;
         return;
    }
    erl_free_compound(result);
    return;
}



void request_v(int sock, unsigned int op, int thandle,
              int *status, confd_value_t *v, const char *fmt, va_list args)
{
    int isrel;
    ETERM *epath;
    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL) {
        *status = CONFD_ERR;
        ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
        return;
    }
    arg_request(sock, op, thandle, status, isrel, v, epath);
}



int fmt_request(int sock, unsigned int op, int thandle,
                const char *fmt, va_list args)
{
    int status;
    confd_value_t v;
    request_v(sock, op, thandle, &status, &v, fmt, args);
    return status;
}

int request_int(int sock, unsigned int op, int thandle,
                const char *fmt, va_list args)
{
    int status;
    confd_value_t v;

    request_v(sock, op, thandle, &status, &v, fmt, args);
    if (status == CONFD_OK)
        return CONFD_GET_INT32(&v);
    return status;
}

/* copy a binary|atom to a char* and NUL terminate */
/* n is the maxsize of buf */
int bin_copy(char *buf, int n, const ETERM *b)
{
    int sz;
    void *ptr;

    assert(n > 0);

    if (ERL_IS_BINARY(b)) {
        sz =  ERL_BIN_SIZE(b);
        ptr = ERL_BIN_PTR(b);
    } else if (ERL_IS_ATOM(b)) {
        sz = ERL_ATOM_SIZE(b);
        ptr = ERL_ATOM_PTR(b);
    } else {
        sz = 0;
        ptr = NULL;
    }

    int write_sz = sz >= n ? n - 1 : sz;
    memcpy(buf, ptr, write_sz);
    buf[write_sz] = 0;

    return write_sz;
}


/* compare a binary|atom to a NUL-terminated char* */
/* return 1 if equal, 0 if not */
int bin_eq(const ETERM *b, char *s2)
{
    int i, sz;
    char *s1;

    if (ERL_IS_BINARY(b)) {
        sz = ERL_BIN_SIZE(b);
        s1 = (char *)ERL_BIN_PTR(b);
    } else if (ERL_IS_ATOM(b)) {
        sz = ERL_ATOM_SIZE(b);
        s1 = (char *)ERL_ATOM_PTR(b);
    } else {
        return 0;
    }

    for (i = 0; i < sz; i++) {
        if (*s1++ != *s2++)
            return 0;
    }
    if (*s2 == '\0')
        return 1;
    return 0;
}

/* copy a binary|atom to an allocated NUL-terminated string */
char *bin_dup(const ETERM *b)
{
    int sz = 0;
    void *ptr;
    char *buf;

    if (ERL_IS_BINARY(b)) {
        sz =  ERL_BIN_SIZE(b);
        ptr = ERL_BIN_PTR(b);
    }
    else if (ERL_IS_ATOM(b)) {
        sz = ERL_ATOM_SIZE(b);
        ptr = ERL_ATOM_PTR(b);
    } else {
        return NULL;
    }

    if ((buf = confd_malloc(sz + 1)) == NULL)
        return NULL;
    memcpy(buf, ptr, sz);
    buf[sz] = 0;
    return buf;
}

int _confd_iterate_send_reply(int sock, enum confd_iter_ret uret)
{
    int ret;
    unsigned char buf[8];

    put_int32(4, buf);
    switch (uret) {
    case ITER_STOP:
    case ITER_RECURSE:
    case ITER_CONTINUE:
    case ITER_UP:
        put_int32(uret, buf+4);
        if ((ret = confd_write(sock, buf, 8)) != CONFD_OK)
            return ret;
        break;
    default:
        put_int32(ITER_STOP, buf+4);
        if ((ret = confd_write(sock, buf, 8)) != CONFD_OK)
            return ret;
        confd_report_err(CONFD_DEBUG, "Bad return value: %d\n", uret);
        confd_set_errno(CONFD_ERR_PROTOUSAGE);
        return CONFD_ERR;
    }
    return CONFD_OK;
}

/* before calling you must have issued the op to ConfD */
int _confd_iterate(int sock, void *iter_function, void *initstate)
{
    while (1) {
        ETERM *e; int ret;
        ETERM *ekp;
        confd_hkeypath_t kp;
        int uret;

        if ((e = term_read(sock, &ret, -1)) == NULL)
            return ret;
        ekp = TE(e, 0);
        if (ERL_IS_ATOM(ekp)  &&
            (strncmp("return", (char *)ERL_ATOM_PTR(ekp), 6) == 0)) {
            erl_free_compound(e);
            return CONFD_OK;
        }
        if (ERL_IS_ATOM(ekp)  &&
            (strncmp("error", (char *)ERL_ATOM_PTR(ekp), 5) == 0)) {
            if (ERL_TUPLE_SIZE(e) == 2)
                confd_set_lasterr("%s", ERL_BIN_PTR(TE(e, 1)));
            erl_free_compound(e);
            confd_set_errno(CONFD_ERR_NOEXISTS);
            return CONFD_ERR;
        }
        if (ERL_IS_ATOM(ekp)  &&
            (strncmp("badstate", (char *)ERL_ATOM_PTR(ekp), 8) == 0)) {
            if (ERL_TUPLE_SIZE(e) == 2)
                confd_set_lasterr("%s", ERL_BIN_PTR(TE(e, 1)));
            erl_free_compound(e);
            confd_set_errno(CONFD_ERR_BADSTATE);
            return CONFD_ERR;
        }

        if (!populate_keypath(ekp, &kp))
            return CONFD_ERR;

        if (ERL_TUPLE_SIZE(e) >= 4) {
            /* diff_iterate */
            ETERM *ovalue, *nvalue;
            int op;
            confd_value_t oldv, *oldvp = NULL;
            confd_value_t newv, *newvp = NULL;
            int vlen = 0;

            op = TINT(e, 1);
            ovalue = TE(e, 2);
            nvalue = TE(e, 3);

            if (!bin_eq(ovalue, "undefined")) {
                if (eterm_to_val(ovalue, &oldv) == NULL)
                    return CONFD_ERR;
                oldvp = &oldv;
            }

            if (!bin_eq(nvalue, "undefined")) {
                if (op == MOP_MOVED_AFTER || op == MOP_ATTR_SET) {
                    /* nvalue is a tuple, handled below to avoid malloc */
                    vlen = ERL_TUPLE_SIZE(nvalue);
                } else {
                    /* nvalue is a single value */
                    if (eterm_to_val(nvalue, &newv) == NULL)
                        return CONFD_ERR;
                    newvp = &newv;
                }
            }

            {
                confd_value_t vals[vlen+1];
                int i;

                if (vlen > 0) {
                    if (op == MOP_MOVED_AFTER) {
                        /* key tuple */
                        for (i = 0; i < vlen; i++) {
                            if (eterm_to_val(TE(nvalue, i), &vals[i]) == NULL)
                                return CONFD_ERR;
                        }
                        CONFD_SET_NOEXISTS(&vals[vlen]);
                    } else {
                        /* MOP_ATTR_SET - {attr, value} */
                        CONFD_SET_UINT32(&vals[0], TUINT(nvalue, 0));
                        if (eterm_to_val(TE(nvalue, 1), &vals[1]) == NULL)
                            return CONFD_ERR;
                    }
                    newvp = &vals[0];
                }
                {
                    confd_diff_iter_function_t *iter = iter_function;
                    uret = iter(&kp, (enum confd_iter_op) op,
                                oldvp, newvp, initstate);
                }
                if (oldvp != NULL)
                    confd_free_eterm_val(oldvp);
                if (newvp != NULL) {
                    if (vlen > 0) {
                        if (op == MOP_MOVED_AFTER) {
                            for (i = 0; i < vlen; i++)
                                confd_free_eterm_val(&vals[i]);
                        } else {
                            confd_free_eterm_val(&vals[1]);
                        }
                    } else {
                        confd_free_eterm_val(newvp);
                    }
                }
            }

        } else {
            /* iterate */
            ETERM *value, *attrl;
            confd_value_t v, *vp = NULL;
            confd_attr_value_t *avp = NULL;
            int num_attr_vals = 0;
            confd_iter_function_t *iter = iter_function;

            value = TE(e, 1);
            attrl = TE(e, 2);

            if (!bin_eq(value, "undefined")) {
                if (eterm_to_val(value, &v) == NULL)
                    return CONFD_ERR;
                vp = &v;
            }

            if (!bin_eq(attrl, "undefined")) {
                /* attrl is a list of tuples, handled below to avoid malloc */
                num_attr_vals = erl_length(attrl);
            }

            {
                confd_attr_value_t attr_vals[num_attr_vals+1];
                int i;

                if (num_attr_vals > 0) {
                    for (i = 0; i < num_attr_vals; i++) {
                        ETERM *attr = ERL_CONS_HEAD(attrl);
                        attr_vals[i].attr = ERL_INT_UVALUE(TE(attr, 0));
                        if (eterm_to_val(TE(attr, 1), &attr_vals[i].v) == NULL)
                            return CONFD_ERR;
                        attrl = ERL_CONS_TAIL(attrl);
                    }
                    avp = &attr_vals[0];
                }
                uret = iter(&kp, vp, avp, num_attr_vals, initstate);
                if (vp != NULL)
                    confd_free_eterm_val(vp);
                for (i = 0; i < num_attr_vals; i++)
                    confd_free_eterm_val(&attr_vals[i].v);
            }

        }

        confd_free_eterm_keypath(&kp);
        erl_free_compound(e);
        if (uret == ITER_SUSPEND) {
            return CONFD_OK;
        }
        if ((ret = _confd_iterate_send_reply(sock, uret)) != CONFD_OK) {
            return ret;
        }
        if (uret == ITER_STOP)
            return CONFD_OK;
    }
    /* never reach */
    return CONFD_OK;
}

int _confd_iterate_resume(int sock, enum confd_iter_ret reply,
                          void *iter_function, void *resumestate,
                          char *trace)
{
    int ret;

    if (reply == ITER_SUSPEND) {
        return CONFD_OK;
    }

    ret = _confd_iterate_send_reply(sock, reply);

    if (confd_debug_level >= CONFD_TRACE) {
        confd_trace_printf("TRACE %s\n", trace);
    }

    if ((ret == CONFD_OK) && (reply != ITER_STOP)) {
        return _confd_iterate(sock, iter_function, resumestate);
    } else {
        return ret;
    }
}


/* from INA - move to confd_lib.c and export? */
int confd_val_num_cmp(const confd_value_t *v1, const confd_value_t *v2)
{
    switch (v1->type) {
#define CMP(E) (v1->val.E < v2->val.E) ? -1 : !(v1->val.E == v2->val.E)
    case C_INT8:
        return CMP(i8);
    case C_INT16:
        return CMP(i16);
    case C_INT32:
        return CMP(i32);
    case C_INT64:
        return CMP(i64);
    case C_UINT8:
        return CMP(u8);
    case C_UINT16:
        return CMP(u16);
    case C_UINT32:
        return CMP(u32);
    case C_UINT64:
        return CMP(u64);
    case C_DOUBLE:
        return CMP(d);
    case C_DECIMAL64:
        return CMP(d64.value);
    default:
        return 0;
#undef CMP
    }
}
